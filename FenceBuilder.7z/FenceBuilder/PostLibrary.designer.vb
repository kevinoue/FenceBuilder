﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class PostLibrary
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(PostLibrary))
        Me.Label5 = New System.Windows.Forms.Label()
        Me.PoRad = New System.Windows.Forms.TextBox()
        Me.PoID = New System.Windows.Forms.ComboBox()
        Me.ShowPoLib = New System.Windows.Forms.Button()
        Me.DeletePostLibrary = New System.Windows.Forms.Button()
        Me.PostLibraryUpdate = New System.Windows.Forms.Button()
        Me.PostLibraryInsert = New System.Windows.Forms.Button()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.PoThick = New System.Windows.Forms.TextBox()
        Me.PoWidth = New System.Windows.Forms.TextBox()
        Me.PoHeight = New System.Windows.Forms.TextBox()
        Me.PostLibraryExit = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.PostsDBDataSet = New FenceBuilderRootNmspc.PostsDBDataSet()
        Me.PoLibBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.PoLibTableAdapter = New FenceBuilderRootNmspc.PostsDBDataSetTableAdapters.PoLibTableAdapter()
        CType(Me.PostsDBDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PoLibBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(49, 130)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(40, 13)
        Me.Label5.TabIndex = 41
        Me.Label5.Text = "Radius"
        '
        'PoRad
        '
        Me.PoRad.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.PoRad.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.PoLibBindingSource, "Radius", True))
        Me.PoRad.Location = New System.Drawing.Point(93, 126)
        Me.PoRad.Name = "PoRad"
        Me.PoRad.Size = New System.Drawing.Size(121, 20)
        Me.PoRad.TabIndex = 5
        '
        'PoID
        '
        Me.PoID.DataSource = Me.PoLibBindingSource
        Me.PoID.DisplayMember = "ID"
        Me.PoID.FormattingEnabled = True
        Me.PoID.Location = New System.Drawing.Point(93, 13)
        Me.PoID.Name = "PoID"
        Me.PoID.Size = New System.Drawing.Size(121, 21)
        Me.PoID.TabIndex = 1
        '
        'ShowPoLib
        '
        Me.ShowPoLib.Location = New System.Drawing.Point(253, 13)
        Me.ShowPoLib.Name = "ShowPoLib"
        Me.ShowPoLib.Size = New System.Drawing.Size(75, 23)
        Me.ShowPoLib.TabIndex = 8
        Me.ShowPoLib.Text = "Show Data"
        Me.ShowPoLib.UseVisualStyleBackColor = True
        '
        'DeletePostLibrary
        '
        Me.DeletePostLibrary.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.DeletePostLibrary.Location = New System.Drawing.Point(253, 50)
        Me.DeletePostLibrary.Name = "DeletePostLibrary"
        Me.DeletePostLibrary.Size = New System.Drawing.Size(75, 23)
        Me.DeletePostLibrary.TabIndex = 9
        Me.DeletePostLibrary.Text = "Delete"
        Me.DeletePostLibrary.UseVisualStyleBackColor = True
        '
        'PostLibraryUpdate
        '
        Me.PostLibraryUpdate.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.PostLibraryUpdate.Location = New System.Drawing.Point(136, 159)
        Me.PostLibraryUpdate.Name = "PostLibraryUpdate"
        Me.PostLibraryUpdate.Size = New System.Drawing.Size(75, 23)
        Me.PostLibraryUpdate.TabIndex = 7
        Me.PostLibraryUpdate.Text = "Update"
        Me.PostLibraryUpdate.UseVisualStyleBackColor = True
        '
        'PostLibraryInsert
        '
        Me.PostLibraryInsert.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.PostLibraryInsert.Location = New System.Drawing.Point(58, 159)
        Me.PostLibraryInsert.Name = "PostLibraryInsert"
        Me.PostLibraryInsert.Size = New System.Drawing.Size(75, 23)
        Me.PostLibraryInsert.TabIndex = 6
        Me.PostLibraryInsert.Text = "Insert"
        Me.PostLibraryInsert.UseVisualStyleBackColor = True
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(33, 102)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(56, 13)
        Me.Label4.TabIndex = 37
        Me.Label4.Text = "Thickness"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(54, 74)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(35, 13)
        Me.Label3.TabIndex = 36
        Me.Label3.Text = "Width"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(51, 47)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(38, 13)
        Me.Label2.TabIndex = 35
        Me.Label2.Text = "Height"
        '
        'PoThick
        '
        Me.PoThick.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.PoThick.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.PoLibBindingSource, "Thickness", True))
        Me.PoThick.Location = New System.Drawing.Point(93, 98)
        Me.PoThick.Name = "PoThick"
        Me.PoThick.Size = New System.Drawing.Size(121, 20)
        Me.PoThick.TabIndex = 4
        '
        'PoWidth
        '
        Me.PoWidth.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.PoWidth.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.PoLibBindingSource, "Width", True))
        Me.PoWidth.Location = New System.Drawing.Point(93, 71)
        Me.PoWidth.Name = "PoWidth"
        Me.PoWidth.Size = New System.Drawing.Size(121, 20)
        Me.PoWidth.TabIndex = 3
        '
        'PoHeight
        '
        Me.PoHeight.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.PoHeight.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.PoLibBindingSource, "Height", True))
        Me.PoHeight.Location = New System.Drawing.Point(93, 43)
        Me.PoHeight.Name = "PoHeight"
        Me.PoHeight.Size = New System.Drawing.Size(121, 20)
        Me.PoHeight.TabIndex = 2
        '
        'PostLibraryExit
        '
        Me.PostLibraryExit.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.PostLibraryExit.Location = New System.Drawing.Point(253, 159)
        Me.PostLibraryExit.Name = "PostLibraryExit"
        Me.PostLibraryExit.Size = New System.Drawing.Size(75, 23)
        Me.PostLibraryExit.TabIndex = 10
        Me.PostLibraryExit.Text = "Exit"
        Me.PostLibraryExit.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(18, 17)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(71, 13)
        Me.Label1.TabIndex = 33
        Me.Label1.Text = "Material Type"
        '
        'PostsDBDataSet
        '
        Me.PostsDBDataSet.DataSetName = "PostsDBDataSet"
        Me.PostsDBDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'PoLibBindingSource
        '
        Me.PoLibBindingSource.DataMember = "PoLib"
        Me.PoLibBindingSource.DataSource = Me.PostsDBDataSet
        '
        'PoLibTableAdapter
        '
        Me.PoLibTableAdapter.ClearBeforeFill = True
        '
        'PostLibrary
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(345, 202)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.PoRad)
        Me.Controls.Add(Me.PoID)
        Me.Controls.Add(Me.ShowPoLib)
        Me.Controls.Add(Me.DeletePostLibrary)
        Me.Controls.Add(Me.PostLibraryUpdate)
        Me.Controls.Add(Me.PostLibraryInsert)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.PoThick)
        Me.Controls.Add(Me.PoWidth)
        Me.Controls.Add(Me.PoHeight)
        Me.Controls.Add(Me.PostLibraryExit)
        Me.Controls.Add(Me.Label1)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "PostLibrary"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Post Library"
        CType(Me.PostsDBDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PoLibBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label5 As Label
    Friend WithEvents PoRad As TextBox
    Friend WithEvents PoID As ComboBox
    Friend WithEvents ShowPoLib As Button
    Friend WithEvents DeletePostLibrary As Button
    Friend WithEvents PostLibraryUpdate As Button
    Friend WithEvents PostLibraryInsert As Button
    Friend WithEvents Label4 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents PoThick As TextBox
    Friend WithEvents PoWidth As TextBox
    Friend WithEvents PoHeight As TextBox
    Friend WithEvents PostLibraryExit As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents PostsDBDataSet As PostsDBDataSet
    Friend WithEvents PoLibBindingSource As BindingSource
    Friend WithEvents PoLibTableAdapter As PostsDBDataSetTableAdapters.PoLibTableAdapter
    'Friend WithEvents PoLibTableAdapter As PostsDBDataSetTableAdapters.PoLibTableAdapter
End Class
