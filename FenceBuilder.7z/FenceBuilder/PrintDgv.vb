﻿'Original from:
'http://www.codeproject.com/Articles/16670/DataGridView-Printing-by-Selecting-Columns-and-Row

' Original extensively modified to meet specific needs
Imports System.Collections.Generic
Imports System.Drawing.Graphics

Public Class PrintDGV

    'Set parameters - not all of these are used in this project
    Private Shared StrFormat As StringFormat     ' Holds content of a TextBox Cell to write by DrawString
    Private Shared TotalWidth As Int16           ' Summation of Columns widths
    Private Shared RowPos As Int16               ' Position of currently printing row 
    Private Shared NewPage As Boolean            ' Indicates if a new page reached 
    Private Shared PageNo As Int16               ' Number of pages to print 
    Private Shared ColumnLefts As New ArrayList  ' Left Coordinate of Columns
    Private Shared ColumnWidths As New ArrayList ' Width of Columns from DataGridView on FormMain
    Private Shared ColumnTypes As New ArrayList  ' DataType of Columns - Not needed in this project
    Private Shared CellHeight As Int16           ' Height of DataGrid Cell
    Private Shared RowsPerPage As Int16          ' Number of Rows per Page 
    Private Shared WithEvents PrintDoc As New System.Drawing.Printing.PrintDocument ' PrintDocumnet Object used for printing
    Private Shared dgv As DataGridView                     ' Holds DataGrid Object to print its contents
    Private Shared SelectedColumns As New List(Of String)  ' The Columns Selected by user to print
    Private Shared AvailableColumns As New List(Of String) ' All Columns avaiable in DataGrid   
    Private Shared PrintAllRows As Boolean = True          ' True = print all rows,  False = print selected rows    
    Private Shared FitToPageWidth As Boolean = False ' True = Fits selected columns to page width ,  False = Print columns as shown    
    Private Shared HeaderHeight As Int16 = 0

    Public Shared Sub Print_DataGridView(ByVal dgv1 As DataGridView)
        Dim ppvw As PrintPreviewDialog
        Try
            ' Getting DataGridView object to print
            dgv = dgv1

            ' Getting all Coulmns Names in the DataGridView
            AvailableColumns.Clear()
            For Each c As DataGridViewColumn In dgv.Columns
                If Not c.Visible Then Continue For
                AvailableColumns.Add(c.HeaderText)
            Next

            ' Showing the PrintOption Form

            Dim dlg As New PrintOptions(AvailableColumns)
            If dlg.ShowDialog() <> DialogResult.OK Then Exit Sub

            ' Saving some printing attributes

            'PrintTitle = dlg.PrintTitle - no title is used for this invoice
            'This would be called form the PrintOptions form if it was there


            'PrintAllRows = dlg.PrintAllRows

            'FitToPageWidth = dlg.FitToPageWidth - not needed as column widths fixed

            SelectedColumns = dlg.GetSelectedColumns


            RowsPerPage = 0
            ppvw = New PrintPreviewDialog

            If dlg.Zoom100 = True Then

                'Set the zoom to 100%
                ppvw.PrintPreviewControl.Zoom = 1

                'Maximise the form to fill the screen
                ppvw.WindowState = FormWindowState.Maximized

            End If

            ppvw.Document = PrintDoc

            ' Showing the Print Preview Page
            If ppvw.ShowDialog() <> DialogResult.OK Then Exit Sub

            ' Printing the Documnet
            PrintDoc.Print()

        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Finally

        End Try


    End Sub

    Private Shared Sub PrintDoc_BeginPrint(ByVal sender As Object,
                ByVal e As System.Drawing.Printing.PrintEventArgs) Handles PrintDoc.BeginPrint

        Try
            ' Formatting the Content of Text Cells to print
            StrFormat = New StringFormat
            StrFormat.Alignment = StringAlignment.Near 'text horizontal alignment
            StrFormat.LineAlignment = StringAlignment.Center 'Text vertical alignment
            StrFormat.Trimming = StringTrimming.EllipsisCharacter


            ColumnLefts.Clear()
            ColumnWidths.Clear()
            ColumnTypes.Clear() 'Not needed in this project
            CellHeight = 0
            RowsPerPage = 0

            TotalWidth = 0
            For Each GridCol As DataGridViewColumn In dgv.Columns
                If Not GridCol.Visible Then Continue For
                If Not SelectedColumns.Contains(GridCol.HeaderText) Then Continue For
                TotalWidth += GridCol.Width
            Next
            PageNo = 1
            NewPage = True
            RowPos = 0
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Finally

        End Try
    End Sub

    Private Shared Sub PrintDoc_PrintPage(ByVal sender As Object,
            ByVal e As System.Drawing.Printing.PrintPageEventArgs) Handles PrintDoc.PrintPage

        Dim tmpWidth As Int16, i As Int16
        Dim tmpTop As Int16 = e.MarginBounds.Top
        Dim tmpLeft As Int16 = e.MarginBounds.Left

        Try

            If PageNo = 1 Then
                For Each GridCol As DataGridViewColumn In dgv.Columns
                    If Not GridCol.Visible Then Continue For
                    If Not SelectedColumns.Contains(GridCol.HeaderText) Then
                        Continue For
                    End If

                    tmpWidth = GridCol.Width

                    'Set dgv header height
                    HeaderHeight = e.Graphics.MeasureString(GridCol.HeaderText,
                                   GridCol.InheritedStyle.Font, tmpWidth).Height + 16

                    ColumnLefts.Add(tmpLeft)
                    ColumnWidths.Add(tmpWidth)
                    'ColumnTypes.Add(GridCol.GetType)- Not needed in this project
                    tmpLeft += tmpWidth
                Next
            End If

            ' Printing Current Page, Row by Row
            Do While RowPos <= dgv.Rows.Count - 1
                Dim GridRow As DataGridViewRow = dgv.Rows(RowPos)
                If GridRow.IsNewRow OrElse (Not PrintAllRows AndAlso Not GridRow.Selected) Then
                    RowPos += 1 : Continue Do
                End If

                CellHeight = GridRow.Height + 4 'Adjusts dgv row height


                If tmpTop + CellHeight >= e.MarginBounds.Height + e.MarginBounds.Top Then
                    DrawFooter(e, RowsPerPage)
                    NewPage = True
                    PageNo += 1
                    e.HasMorePages = True
                    Exit Sub
                Else

                    If NewPage Then

                        '******************************************************

                        '  **** I HAVE NOT TRIED THIS ****

                        'Insert this code if you want a logo
                        'Dim img As Image = Image.FromFile("1.jpg")
                        'Dim ImgSize As Size = img.Size
                        'e.Graphics.DrawImage(img, e.MarginBounds.Left, e.MarginBounds.Top - img.Height)
                        'Replace "1.jpg" by your own file, after seeing the resulted layout you can change the coordination to the best fit.
                        'The picture height should be smaller than the top margin. 

                        '******************************************************

                        ' Draw "Invoice" on top right hand side of page

                        'The following code is not strictly correct as "Using" applies to
                        'many operations

                        Using Invoice_font As New Font("Arial", 20, FontStyle.Bold)

                            e.Graphics.DrawString("Invoice", Invoice_font, Brushes.Blue, 675, 30)

                        End Using

                        'START PRINTING YOUR COMPANY NAME

                        'Get the saved font for the company name from MySettings
                        Dim CoNameFont As Font
                        CoNameFont = My.Settings.CoNameFont

                        'Get the saved colour for the company name from MySettings
                        Dim CoNameBrush As Brush
                        Dim col As New Color

                        Dim CoNameFontColor As System.Drawing.Color = My.Settings.CoNameColour
                        col = CoNameFontColor

                        CoNameBrush = New SolidBrush(col)

                        Dim CoName As String
                        CoName = InvMain.tbCoName.Text

                        'The following line of code prints the company name
                        'one inch in from the left margin and 0.4 inches from the top margin
                        e.Graphics.DrawString(CoName, CoNameFont, CoNameBrush, 100, 40)

                        'END PRINTING YOUR COMPANY NAME


                        'START PRINTING YOUR COMPANY ADDRESS

                        'Get the saved font for the company address
                        Dim CoAddressFont As Font
                        CoAddressFont = My.Settings.CoAddressFont

                        'Get the saved colour for the company address
                        Dim CoAddressBrush As Brush
                        Dim AddressCol As New Color

                        Dim CoAddressFontColor As System.Drawing.Color = My.Settings.CoAddressColour
                        AddressCol = CoAddressFontColor

                        CoAddressBrush = New SolidBrush(AddressCol)


                        Dim CA As String
                        CA = InvMain.tbCoAddress.Text

                        e.Graphics.DrawString(CA, CoAddressFont, CoAddressBrush, 100, 75)

                        'END PRINTING YOUR COMPANY ADDRESS


                        'Draw and fill the rectangle for "Tax Date" in blue

                        Dim ObjFont As New Font("Arial", 14, FontStyle.Regular, GraphicsUnit.Point)

                        e.Graphics.FillRectangle(Brushes.Blue, New Rectangle(520, 70, 130, 25))

                        'Print "Tax date" in white
                        e.Graphics.DrawString("Tax Date", ObjFont, Brushes.White, 545, 73)


                        'Draw and fill the rectangle for "Invoice Number" in blue

                        e.Graphics.FillRectangle(Brushes.Blue, New Rectangle(660, 70, 130, 25))

                        'Print "Invoice No" in white
                        e.Graphics.DrawString("Invoice No", ObjFont, Brushes.White, 670, 73)

                        'Print the invoice number from the textbox on MainForm
                        Dim A As String
                        A = InvMain.tbInvoiceNo.Text
                        e.Graphics.DrawString(A, ObjFont, Brushes.Black, 700, 105)

                        'Date from DateTimePicker on FormMain
                        Dim B As String
                        B = InvMain.dtp1.Text
                        e.Graphics.DrawString(B, ObjFont, Brushes.Black, 545, 105)

                        'Draw and fill "INVOICE TO:"

                        e.Graphics.FillRectangle(Brushes.Blue, New Rectangle(100, 200, 130, 26))
                        e.Graphics.DrawString("INVOICE TO:-", ObjFont, Brushes.White, 95, 203)

                        'Customer Name & Address from multiline textbox on FormMain
                        Dim C As String
                        C = InvMain.tbCustNameAddress.Text
                        e.Graphics.DrawString(C, ObjFont, Brushes.Black, 95, 230)

                        'Draw a short line with a pen thickness of 2 to show where to fold 
                        'to fit A4 paper into an European DL window envelope 
                        'measuring 220 mm x 110 mm
                        e.Graphics.DrawLine(New Pen(Color.Gray, 2), 10, 415, 20, 415)

                        'THAT FINISHES THE CODE FOR ITEMS ABOVE THE DATAGRIDVIEW


                        'CODE FOR HANDLING THE TEXT AND TEXTBOXES BELOW THE DGV.

                        'Print text boxes below the datagridview
                        e.Graphics.DrawString("SUBTOTAL", ObjFont, Brushes.Blue, 425, 853)
                        e.Graphics.DrawString("TAX", ObjFont, Brushes.Blue, 425, 901)
                        e.Graphics.DrawString("TOTAL", ObjFont, Brushes.Blue, 425, 949)

                        'Draw boxes for above amounts using the same colour as the grid
                        e.Graphics.DrawRectangle(Pens.Gray, New Rectangle(542, 836, 140, 50))
                        e.Graphics.DrawRectangle(Pens.Gray, New Rectangle(542, 886, 140, 50))
                        e.Graphics.DrawRectangle(Pens.Gray, New Rectangle(542, 936, 140, 50))

                        'Postion and print the text in the boxes

                        Dim ST As String

                        ST = InvMain.tbSubTotal.Text

                        'Set the font for the totals boxes at the bottom of the page
                        Dim TotalsFont As Font
                        TotalsFont = New Font("Arial", 12, FontStyle.Regular)

                        'Set the position where the Sub Total will be printed on the invoice
                        Dim STArea As Rectangle = New Rectangle(542, 853, 140, 50)
                        Dim STFormat As StringFormat = New StringFormat
                        STFormat.Alignment = StringAlignment.Far

                        'Print the Sub Total
                        e.Graphics.DrawString(ST, TotalsFont, Brushes.Black, STArea, STFormat)


                        Dim Tax As String
                        Tax = InvMain.tbTax.Text

                        'Set the position where the VAT Total will be printed on the invoice
                        Dim VATArea As Rectangle = New Rectangle(542, 901, 140, 50)
                        Dim VATFormat As StringFormat = New StringFormat
                        VATFormat.Alignment = StringAlignment.Far

                        'Print the VAT
                        e.Graphics.DrawString(Tax, TotalsFont, Brushes.Black, VATArea, VATFormat)


                        Dim TOTAL As String
                        TOTAL = InvMain.tbTotal.Text

                        'Set the position where the Total will be printed on the invoice
                        Dim TOTALArea As Rectangle = New Rectangle(542, 949, 140, 50)
                        Dim TOTALFormat As StringFormat = New StringFormat
                        TOTALFormat.Alignment = StringAlignment.Far

                        'Print the Total
                        e.Graphics.DrawString(TOTAL, TotalsFont, Brushes.Black, TOTALArea, TOTALFormat)



                        ' DRAW DATAGRIDVIEW

                        ' Move the DGV down the page to desired position
                        tmpTop = e.MarginBounds.Top + 280

                        'Prepare the DGV for print
                        i = 0
                        For Each GridCol As DataGridViewColumn In dgv.Columns
                            If Not GridCol.Visible Then Continue For
                            If Not SelectedColumns.Contains(GridCol.HeaderText) Then
                                Continue For
                            End If


                            'Set DGV column header text position
                            If GridCol.DisplayIndex = 0 Then
                                StrFormat.Alignment = StringAlignment.Center
                            End If

                            If GridCol.DisplayIndex = 1 Then
                                StrFormat.Alignment = StringAlignment.Center
                            End If

                            If GridCol.DisplayIndex = 2 Then
                                StrFormat.Alignment = StringAlignment.Center
                            End If


                            'Set background colour for DGV header cell
                            e.Graphics.FillRectangle(New SolidBrush(Drawing.Color.Blue),
                                    New Rectangle(ColumnLefts(i), tmpTop, ColumnWidths(i), HeaderHeight))


                            'DGV Header text colour
                            GridCol.DefaultCellStyle.ForeColor = Color.White


                            'Pen colour for DGV header grid
                            e.Graphics.DrawRectangle(Pens.Gray, New Rectangle(ColumnLefts(i),
                                    tmpTop, ColumnWidths(i), HeaderHeight))


                            'Grid column header text DefaultCellStyle.
                            GridCol.DefaultCellStyle.Font = New Font("Arial", 12, FontStyle.Bold)


                            'Draws column header text
                            e.Graphics.DrawString(GridCol.HeaderText, GridCol.InheritedStyle.Font,
                                    New SolidBrush(GridCol.InheritedStyle.ForeColor),
                                    New RectangleF(ColumnLefts(i), tmpTop, ColumnWidths(i),
                                    HeaderHeight), StrFormat)


                            i += 1
                        Next
                        NewPage = False

                        tmpTop += HeaderHeight
                    End If

                    i = 0
                    For Each Cel As DataGridViewCell In GridRow.Cells
                        If Not Cel.OwningColumn.Visible Then Continue For
                        If Not SelectedColumns.Contains(Cel.OwningColumn.HeaderText) Then
                            Continue For
                        End If


                        ' Text colour in all TextBox Columns
                        Cel.Style.ForeColor = Color.Black

                        'Text font size in all Textboxes
                        Cel.Style.Font = New Font("Arial", 10, FontStyle.Regular)


                        If Cel.ValueType.Name = "String" Then
                            StrFormat.Alignment = StringAlignment.Near
                        Else
                            StrFormat.Alignment = StringAlignment.Near
                        End If


                        'Set column text alignment in DGV body
                        If Cel.ColumnIndex = 0 Then
                            StrFormat.Alignment = StringAlignment.Near
                        End If

                        If Cel.ColumnIndex = 1 Then
                            StrFormat.Alignment = StringAlignment.Far
                        End If

                        If Cel.ColumnIndex = 2 Then
                            StrFormat.Alignment = StringAlignment.Far
                        End If


                        'Check for cell contents
                        'Without this code, the printing will stop at the first empty cell
                        If Cel.Value Is Nothing Then
                            Cel.Value = ""
                        End If


                        'Insert the DGV text
                        e.Graphics.DrawString(Cel.Value.ToString, Cel.InheritedStyle.Font,
                                New SolidBrush(Cel.InheritedStyle.ForeColor),
                                New RectangleF(ColumnLefts(i), tmpTop, ColumnWidths(i),
                                CellHeight), StrFormat)


                        ' Drawing Cells Borders - grid body 
                        e.Graphics.DrawRectangle(Pens.Gray, New Rectangle(ColumnLefts(i),
                                tmpTop, ColumnWidths(i), CellHeight))



                        i += 1

                    Next
                    tmpTop += CellHeight

                End If

                RowPos += 1
                ' For the first page it calculates Rows per Page
                If PageNo = 1 Then
                    RowsPerPage += 1
                End If
            Loop

            If RowsPerPage = 0 Then Exit Sub

            ' Write Footer (Page Number)
            DrawFooter(e, RowsPerPage)

            e.HasMorePages = False
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Finally

        End Try
    End Sub

    Private Shared Sub DrawFooter(ByVal e As System.Drawing.Printing.PrintPageEventArgs, ByVal RowsPerPage As Int32)
        Dim cnt As Integer

        ' Detemining rows number to print
        If PrintAllRows Then
            If dgv.Rows(dgv.Rows.Count - 1).IsNewRow Then
                ' When the DataGridView doesn't allow adding rows
                cnt = dgv.Rows.Count - 2
            Else
                ' When the DataGridView allows adding rows
                cnt = dgv.Rows.Count - 1
            End If
        Else
            cnt = dgv.SelectedRows.Count
        End If

        ' Writing the Page Number on the Bottom of Page
        'Dim PageNum As String = PageNo.ToString + " of " + _
        '            Math.Ceiling(cnt / RowsPerPage).ToString
        'e.Graphics.DrawString(PageNum, dgv.Font, Brushes.Black, _
        '            e.MarginBounds.Left + (e.MarginBounds.Width - _
        '            e.Graphics.MeasureString(PageNum, dgv.Font, _
        '            e.MarginBounds.Width).Width) / 2, e.MarginBounds.Top + _
        '            e.MarginBounds.Height + 31)

    End Sub

End Class