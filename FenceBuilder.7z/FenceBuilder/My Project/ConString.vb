﻿Imports System.Data.OleDb
Module RailsDBConString
    Public RaCon As OleDbConnection = New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0; Data Source=.\\RailsDB.accdb;Persist Security Info=False")
    Public RaDad As OleDbDataAdapter
    Public RaDrd As OleDbDataReader
    Public RaCmd As OleDbCommand
    Public RaDst = New DataSet
    Public RaCurrentRow As Integer
End Module

Module PostsDBConString
    Public PoCon As OleDbConnection = New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0; Data Source=.\\PostsDB.accdb;Persist Security Info=False")
    Public PoDad As OleDbDataAdapter
    Public PoDrd As OleDbDataReader
    Public PoCmd As OleDbCommand
    Public PoDst = New DataSet
    Public PoCurrentRow As Integer
End Module

Module PicketsDBConString
    Public PicketCon As OleDbConnection = New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0; Data Source=.\\PicketsDB.accdb;Persist Security Info=False")
    Public PicketDad As OleDbDataAdapter
    Public PicketDrd As OleDbDataReader
    Public PicketCmd As OleDbCommand
    Public PicketDst = New DataSet
    Public PicketCurrentRow As Integer
End Module
