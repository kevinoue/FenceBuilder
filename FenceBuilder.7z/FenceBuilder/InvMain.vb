﻿Public Class InvMain

    Private Sub btnPrint_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnPrint.Click


        'Calling DataGridView Printing
        ' Printdgv.Print_DataGridView(dgv)

    End Sub
    Dim dgv As DataGridView                     ' Holds DataGrid Object to print its contents

    Private Sub InvMain_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        'As this project has no database, load the following information
        'for the DataGridView's contents.

        'Place 16 rows on the DGV
        dgv.RowCount = 16

        'Fill all 16 rows in the DGV with data to print
        'Not all cells have to contain data but have been filled for this demonstration
        'These would normally be left blank for the user to enter data

        Me.dgv.Item(0, 0).Value = "Item 1  Each line has lots of text space"
        Me.dgv.Item(0, 1).Value = "Item 2"
        Me.dgv.Item(0, 2).Value = "Item 3"
        Me.dgv.Item(0, 3).Value = "Item 4"
        Me.dgv.Item(0, 4).Value = "Item 5"
        Me.dgv.Item(0, 5).Value = "Item 6"
        Me.dgv.Item(0, 6).Value = "Item 7"
        Me.dgv.Item(0, 7).Value = "Item 8"
        Me.dgv.Item(0, 8).Value = "Item 9"
        Me.dgv.Item(0, 9).Value = "Item 10"
        Me.dgv.Item(0, 10).Value = "Item 11"
        Me.dgv.Item(0, 11).Value = "Item 12"
        Me.dgv.Item(0, 12).Value = "Item 13"
        Me.dgv.Item(0, 13).Value = "Item 14"
        Me.dgv.Item(0, 14).Value = "Item 15"
        Me.dgv.Item(0, 15).Value = "Item 16"

        Me.dgv.Item(1, 0).Value = "100.00"
        Me.dgv.Item(1, 1).Value = "150.00"
        Me.dgv.Item(1, 2).Value = "200.00"
        Me.dgv.Item(1, 3).Value = "250.00"
        Me.dgv.Item(1, 4).Value = "300.00"
        Me.dgv.Item(1, 5).Value = "350.00"
        Me.dgv.Item(1, 6).Value = "400.00"
        Me.dgv.Item(1, 7).Value = "450.00"
        Me.dgv.Item(1, 8).Value = "500.00"
        Me.dgv.Item(1, 9).Value = "550.00"
        Me.dgv.Item(1, 10).Value = "600.00"
        Me.dgv.Item(1, 11).Value = "100.00"
        Me.dgv.Item(1, 12).Value = "150.00"
        Me.dgv.Item(1, 13).Value = "200.00"
        Me.dgv.Item(1, 14).Value = "250.00"
        Me.dgv.Item(1, 15).Value = "300.00"


        Me.dgv.Item(2, 0).Value = "10.00"
        Me.dgv.Item(2, 1).Value = "15.00"
        Me.dgv.Item(2, 2).Value = "20.00"
        Me.dgv.Item(2, 3).Value = "25.00"
        Me.dgv.Item(2, 4).Value = "30.00"
        Me.dgv.Item(2, 5).Value = "35.00"
        Me.dgv.Item(2, 6).Value = "40.00"
        Me.dgv.Item(2, 7).Value = "45.00"
        Me.dgv.Item(2, 8).Value = "50.00"
        Me.dgv.Item(2, 9).Value = "55.00"
        Me.dgv.Item(2, 10).Value = "60.00"
        Me.dgv.Item(2, 11).Value = "10.00"
        Me.dgv.Item(2, 12).Value = "15.00"
        Me.dgv.Item(2, 13).Value = "20.00"
        Me.dgv.Item(2, 14).Value = "25.00"
        Me.dgv.Item(2, 15).Value = "30.00"

        'Set the dgv header properties
        dgv.EnableHeadersVisualStyles = False
        dgv.ColumnHeadersDefaultCellStyle.Font = My.Settings.dgvHeaderFont
        dgv.ColumnHeadersDefaultCellStyle.ForeColor = My.Settings.dgvHeaderForeColour
        dgv.ColumnHeadersDefaultCellStyle.BackColor = My.Settings.dgvHeaderBackColour


        Dim VAT As Double
        Dim ST As Double

        'Get the total for the "Net Amount" column
        For Each r As DataGridViewRow In Me.dgv.Rows
            ST = ST + r.Cells(1).Value

        Next r

        'Get the total for the "VAT" column
        For Each r As DataGridViewRow In Me.dgv.Rows
            VAT = VAT + r.Cells(2).Value

        Next r

        'Set the format to number with 2 decimal places
        tbSubTotal.Text = String.Format("{0:N2}", ST)
        tbTax.Text = String.Format("{0:N2}", VAT)
        tbTotal.Text = String.Format("{0:N2}", ST + VAT)

        'The following 2 lines of code retain the My.Settings colours for the text boxes
        'with the "ReadOnly" set to "False".
        tbCoName.BackColor = Color.White
        tbCoAddress.BackColor = Color.White

        Me.ActiveControl = btnPrint

    End Sub

    Private Sub OrderDataGridView_EditingControlShowing(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewEditingControlShowingEventArgs) Handles dgv.EditingControlShowing

        'Set the maximum number of characters i the Desceiption column to 70
        If dgv.CurrentCell.ColumnIndex = 0 Then

            DirectCast(e.Control, TextBox).MaxLength = 70

        End If

    End Sub



End Class

