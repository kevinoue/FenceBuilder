﻿
Public Class PostTbl
    ' To display the data in datagridview control
    Private Sub PostsTbl_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        DataGridView2.DataSource = PoDst.Tables(0)
    End Sub
    ' To close the current form and display main frame
    Private Sub PostTableExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PostTableExit.Click
        Me.Close()
        PostLibrary.Show()
    End Sub
End Class