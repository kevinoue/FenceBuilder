﻿
Imports System.Data.OleDb


Public Class PostLibrary
    Dim DataGridView2 As New DataGridView
    Private Sub PostLibrary_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'PostsDBDataSet.PoLib' table. You can move, or remove it, as needed.
        Me.PoLibTableAdapter.Fill(Me.PostsDBDataSet.PoLib)
        ''  Me.PoLibTableAdapter.Update(Me.PostsDBDataSet.PoLib)
        '' Me.PoLibTableAdapter.Fill(Me.PostsDBDataSet.PoLib)
        PoCurrentRow = 0
        PoCon.Open()
        PoDad = New OleDbDataAdapter("SELECT * FROM PoLib ORDER BY ID", PoCon)
        PoDad.Fill(PoDst, "PoLib")
        ShowData(PoCurrentRow)
        DataGridView2.DataSource = PoDst.Tables(0)
        PoCon.Close()
    End Sub

    Private Sub ShowData(ByVal CurrentRow)
        Try
            PoID.Text = PoDst.Tables("PoLib").Rows(CurrentRow)("ID")
            PoHeight.Text = PoDst.Tables("PoLib").Rows(CurrentRow)("Height")
            PoWidth.Text = PoDst.Tables("PoLib").Rows(CurrentRow)("Width")
            PoThick.Text = PoDst.Tables("PoLib").Rows(CurrentRow)("Thickness")
            PoRad.Text = PoDst.Tables("PoLib").Rows(CurrentRow)("Radius")
        Catch ex As Exception
        End Try
    End Sub


    ' To exit from application
    Private Sub PostLibraryExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PostLibraryExit.Click
        DataGridView2.DataSource.clear
        Me.PoLibTableAdapter.Update(Me.PostsDBDataSet.PoLib)
        Me.PoLibTableAdapter.Fill(Me.PostsDBDataSet.PoLib)
        Me.Close()
    End Sub


    ' To clear all fields : Id, First Name, Last Name, MaterialThickness, Salary
    Private Sub Clear()
        PoID.Text = ""
        PoHeight.Text = ""
        PoWidth.Text = ""
        PoThick.Text = ""
        PoRad.Text = ""
    End Sub


    ' To insert the record in database
    Private Sub PostLibraryInsert_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PostLibraryInsert.Click

        Dim Str As String

        If IfIdExist() = True Then
            MsgBox("Material already found in Database. Consider updating existing entry.")
            Exit Sub
        ElseIf CheckMaterialHeight() = False Then
            MsgBox("Material Height : Only Numbers Allowed!!!")
            Exit Sub
        ElseIf CheckMaterialWidth() = False Then
            MsgBox("Material Width : Only Numbers Allowed!!!")
            Exit Sub
        ElseIf CheckMatThick() = False Then
            MsgBox("Material Thickness : Only Numbers Allowed!!!")
            Exit Sub
        ElseIf CheckMatRad() = False Then
            MsgBox("Material Radius : Only Numbers Allowed!!!")
            Exit Sub
        End If

        Try
            Str = "INSERT INTO PoLib VALUES("
            Str += """" & PoID.Text & """"
            Str += ","
            Str += PoHeight.Text
            Str += ","
            Str += PoWidth.Text
            Str += ","
            Str += PoThick.Text
            Str += ","
            Str += PoRad.Text
            Str += ")"
            PoCon.Open()
            PoCmd = New OleDbCommand(Str, PoCon)
            PoCmd.ExecuteNonQuery()
            PoDad = New OleDbDataAdapter("SELECT * FROM PoLib ORDER BY ID", PoCon)
            MsgBox("Record inserted successfully...")
            DataGridView2.DataSource.clear
            PoCon.Close()
        Catch ex As Exception
            MessageBox.Show("Incorrect Data Entered!!!")
            MsgBox(ex.Message & " -  " & ex.Source)
        End Try
        Me.Close()
        Me.PoLibTableAdapter.Update(Me.PostsDBDataSet.PoLib) 'must have this to load data in to the drop down menu.
        Me.PoLibTableAdapter.Fill(Me.PostsDBDataSet.PoLib) 'must have this to load data in to the drop down menu.
    End Sub






    ' To delete the record from database
    Private Sub DeletePostLibrary_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DeletePostLibrary.Click

        If IfIdExist() = False Then
            MsgBox("Record not found.")
        Else


            Dim Str As String

            Try
                Str = "delete from PoLib where ID="
                Str += """" & PoID.Text & """"
                PoCon.Open()
                PoCmd = New OleDbCommand(Str, PoCon)
                PoCmd.ExecuteNonQuery()
                PoDst.clear()
                PoDad = New OleDbDataAdapter("SELECT * FROM PoLib ORDER BY ID", PoCon)
                PoDad.Fill(PoDst, "MaterialType")
                MsgBox("Record deleted successfully...")
                If PoCurrentRow > 0 Then
                    PoCurrentRow -= 1
                    ShowData(PoCurrentRow)
                End If
                PoDad.Fill(PoDst, "PoLib")
                Me.PoLibTableAdapter.Update(Me.PostsDBDataSet.PoLib) 'must have this to load data in to the drop down menu.
                Me.PoLibTableAdapter.Fill(Me.PostsDBDataSet.PoLib) 'must have this to load data in to the drop down menu.
                PoCon.Close()
            Catch ex As Exception
                MessageBox.Show("Could Not delete Record!")
                MsgBox(ex.Message & " -  " & ex.Source)

            End Try
        End If

    End Sub










    ' To update the records in database
    Private Sub PostLibraryUpdate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PostLibraryUpdate.Click
        Dim Str As String
        If CheckMaterialHeight() = False Then
            MsgBox("Material Height : Only Numbers Allowed!!!")
            Exit Sub
        ElseIf CheckMaterialWidth() = False Then
            MsgBox("Material Width : Only Numbers Allowed!!!")
            Exit Sub
        ElseIf CheckMatThick() = False Then
            MsgBox("Material Thickness : Only Numbers Allowed!!!")
            Exit Sub
        ElseIf CheckMatRad() = False Then
            MsgBox("Material Radius : Only Numbers Allowed!!!")
            Exit Sub
        End If


        Try

            Str = "update PoLib set Height="
            Str += """" & PoHeight.Text & """"
            Str += " where ID="
            Str += """" & PoID.Text & """"
            PoCon.Open()
            PoCmd = New OleDbCommand(Str, PoCon)
            PoCmd.ExecuteNonQuery()
            PoCon.Close()
            PoCon.Open()
            Str = "update PoLib set Width="
            Str += """" & PoWidth.Text & """"
            Str += " where ID="
            Str += """" & PoID.Text & """"
            PoCmd = New OleDbCommand(Str, PoCon)
            PoCmd.ExecuteNonQuery()
            PoCon.Close()
            PoCon.Open()
            Str = "update PoLib set Thickness="
            Str += """" & PoThick.Text & """"
            Str += " where ID="
            Str += """" & PoID.Text & """"
            PoCmd = New OleDbCommand(Str, PoCon)
            PoCmd.ExecuteNonQuery()
            PoCon.Close()
            PoCon.Open()
            Str = "update PoLib set Radius="
            Str += """" & PoRad.Text & """"
            Str += " where ID="
            Str += """" & PoID.Text & """"
            PoCmd = New OleDbCommand(Str, PoCon)
            PoCmd.ExecuteNonQuery()
            PoCon.Close()

            PoDst.Clear()
            PoDad = New OleDbDataAdapter("SELECT * FROM PoLib ORDER BY ID", PoCon)
            PoDad.Fill(PoDst, "PoLib")
            MsgBox("Updated Successfully...")

        Catch ex As Exception
            MsgBox(ex.Message & "--" & ex.Source)
            PoCon.Close()

        End Try
        '' Me.PoLibTableAdapter.Update(Me.PostsDBDataSet.PoLib) 'must have this to load data in to the drop down menu.
        '' Me.PoLibTableAdapter.Fill(Me.PostsDBDataSet.PoLib) 'must have this to load data in to the drop down menu.
    End Sub





    ' To check the data in Id field : whether numeric or not 
    Private Function CheckId()
        Try
            If IsNumeric(PoID.Text) = True Then
                ShowData(PoCurrentRow)
                PoID.Focus()
                Return False
            End If
        Catch ex As Exception
        End Try
        Return True
    End Function






    ' To check the data in First : whether a string or not
    Private Function CheckMaterialHeight()
        Try
            If IsNumeric(PoHeight.Text) = True Then
                ' ShowData(CurrentRow)
                ' MatHeight.Focus()
                Return True
            End If
        Catch ex As Exception
        End Try
        Return False
    End Function






    ' To check the data in Second Field : whether a string or not
    Private Function CheckMaterialWidth()
        Try
            If IsNumeric(PoWidth.Text) = True Then
                ' ShowData(CurrentRow)
                ' MatWidth.Focus()
                Return True
            End If
        Catch ex As Exception
        End Try
        Return False
    End Function






    ' To check the data in Third Field : whether a string or not
    Private Function CheckMatThick()
        Try
            If IsNumeric(PoThick.Text) = True Then
                '  ShowData(CurrentRow)
                ' MatThick.Focus()
                Return True
            End If
        Catch ex As Exception
        End Try
        Return False
    End Function

    ' To check the data in Fourth Field : whether a string or not
    Private Function CheckMatRad()
        Try
            If IsNumeric(PoRad.Text) = True Then
                '  ShowData(CurrentRow)
                ' MatRad.Focus()
                Return True
            End If
        Catch ex As Exception
        End Try
        Return False
    End Function




    ' To check the string for numeric values
    Private Function ValidateString(ByVal Str)
        Dim i As Integer
        Dim ch As Char
        i = 0
        While i < Str.Length()
            ch = Str.Chars(i)
            If IsNumeric(ch) = True Then
                Return False
            End If
            i += 1
        End While
        Return True
    End Function





    ' To show the data in the datagridview
    Private Sub ShowPoLib_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ShowPoLib.Click
        Me.Hide()
        '' Me.PoLibTableAdapter.Update(Me.PostsDBDataSet.PoLib) 'must have this to load data in to the drop down menu.
        PostTbl.Show()
    End Sub





    ' To check whether Id exist in database
    Private Function IfIdExist()
        Dim Str, Str1 As String
        Dim i As Integer
        Str = PoID.Text
        i = 0
        While i <> PoDst.Tables("PoLib").rows.count
            Str1 = PoDst.Tables("PoLib").Rows(i)("ID")
            If Str = Str1 Then
                Return True
            End If
            i += 1
        End While
        Return False

    End Function



End Class