﻿
Imports System.Data.OleDb


Public Class PicketLibrary
    Dim DataGridView3 As New DataGridView
    Private Sub PicketLibrary_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'PicketsDBDataSet.PicketLib' table. You can move, or remove it, as needed.
        Me.PicketLibTableAdapter.Fill(Me.PicketsDBDataSet.PicketLib)
        'TODO: This line of code loads data into the 'PicketsDBDataSet.PicketLib' table. You can move, or remove it, as needed.
        Me.PicketLibTableAdapter.Fill(Me.PicketsDBDataSet.PicketLib)
        Me.PicketLibTableAdapter.Update(Me.PicketsDBDataSet.PicketLib)
        Me.PicketLibTableAdapter.Fill(Me.PicketsDBDataSet.PicketLib)
        PicketCurrentRow = 0
        PicketCon.Open()
        PicketDad = New OleDbDataAdapter("SELECT * FROM PicketLib ORDER BY ID", PicketCon)
        PicketDad.Fill(PicketDst, "PicketLib")
        ShowData(PicketCurrentRow)
        DataGridView3.DataSource = PicketDst.Tables(0)
        PicketCon.Close()
    End Sub

    Private Sub ShowData(ByVal CurrentRow)
        Try
            PicketID.Text = PicketDst.Tables("PicketLib").Rows(CurrentRow)("ID")
            PicketHeight.Text = PicketDst.Tables("PicketLib").Rows(CurrentRow)("Height")
            PicketWidth.Text = PicketDst.Tables("PicketLib").Rows(CurrentRow)("Width")
            PicketThick.Text = PicketDst.Tables("PicketLib").Rows(CurrentRow)("Thickness")
            PicketRad.Text = PicketDst.Tables("PicketLib").Rows(CurrentRow)("Radius")
        Catch ex As Exception
        End Try
    End Sub


    ' To exit from application
    Private Sub PicketLibraryExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PicketLibraryExit.Click
        DataGridView3.DataSource.clear
        Me.PicketLibTableAdapter.Update(Me.PicketsDBDataSet.PicketLib)
        Me.PicketLibTableAdapter.Fill(Me.PicketsDBDataSet.PicketLib)
        Me.Close()
    End Sub


    ' To clear all fields : Id, First Name, Last Name, MaterialThickness, Salary
    Private Sub Clear()
        PicketID.Text = ""
        PicketHeight.Text = ""
        PicketWidth.Text = ""
        PicketThick.Text = ""
        PicketRad.Text = ""
    End Sub


    ' To insert the record in database
    Private Sub PicketLibraryInsert_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PicketLibraryInsert.Click

        Dim Str As String

        If IfIdExist() = True Then
            MsgBox("Material already found in Database. Consider updating existing entry.")
            Exit Sub
        ElseIf CheckMaterialHeight() = False Then
            MsgBox("Material Height : Only Numbers Allowed!!!")
            Exit Sub
        ElseIf CheckMaterialWidth() = False Then
            MsgBox("Material Width : Only Numbers Allowed!!!")
            Exit Sub
        ElseIf CheckMatThick() = False Then
            MsgBox("Material Thickness : Only Numbers Allowed!!!")
            Exit Sub
        ElseIf CheckMatRad() = False Then
            MsgBox("Material Radius : Only Numbers Allowed!!!")
            Exit Sub
        End If

        Try
            Str = "INSERT INTO PicketLib VALUES("
            Str += """" & PicketID.Text & """"
            Str += ","
            Str += PicketHeight.Text
            Str += ","
            Str += PicketWidth.Text
            Str += ","
            Str += PicketThick.Text
            Str += ","
            Str += PicketRad.Text
            Str += ")"
            PicketCon.Open()
            PicketCmd = New OleDbCommand(Str, PicketCon)
            PicketCmd.ExecuteNonQuery()
            PicketDad = New OleDbDataAdapter("SELECT * FROM PicketLib ORDER BY ID", PicketCon)
            MsgBox("Record inserted successfully...")
            DataGridView3.DataSource.clear
            PicketCon.Close()
        Catch ex As Exception
            MessageBox.Show("Incorrect Data Entered!!!")
            MsgBox(ex.Message & " -  " & ex.Source)
        End Try
        Me.Close()
        Me.PicketLibTableAdapter.Update(Me.PicketsDBDataSet.PicketLib) 'must have this to load data in to the drop down menu.
        Me.PicketLibTableAdapter.Fill(Me.PicketsDBDataSet.PicketLib) 'must have this to load data in to the drop down menu.
    End Sub






    ' To delete the record from database
    Private Sub DeletePicketLibrary_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DeletePicketLibrary.Click

        If IfIdExist() = False Then
            MsgBox("Record not found.")
        Else


            Dim Str As String

            Try
                Str = "delete from PicketLib where ID="
                Str += """" & PicketID.Text & """"
                PicketCon.Open()
                PicketCmd = New OleDbCommand(Str, PicketCon)
                PicketCmd.ExecuteNonQuery()
                PicketDst.clear()
                PicketDad = New OleDbDataAdapter("SELECT * FROM PicketLib ORDER BY ID", PicketCon)
                PicketDad.Fill(PicketDst, "MaterialType")
                MsgBox("Record deleted successfully...")
                If PicketCurrentRow > 0 Then
                    PicketCurrentRow -= 1
                    ShowData(PicketCurrentRow)
                End If
                PicketDad.Fill(PicketDst, "PicketLib")
                Me.PicketLibTableAdapter.Update(Me.PicketsDBDataSet.PicketLib) 'must have this to load data in to the drop down menu.
                Me.PicketLibTableAdapter.Fill(Me.PicketsDBDataSet.PicketLib) 'must have this to load data in to the drop down menu.
                PicketCon.Close()
            Catch ex As Exception
                MessageBox.Show("Could Not delete Record!")
                MsgBox(ex.Message & " -  " & ex.Source)

            End Try
        End If

    End Sub










    ' To update the records in database
    Private Sub PicketLibraryUpdate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PicketLibraryUpdate.Click
        Dim Str As String
        If CheckMaterialHeight() = False Then
            MsgBox("Material Height : Only Numbers Allowed!!!")
            Exit Sub
        ElseIf CheckMaterialWidth() = False Then
            MsgBox("Material Width : Only Numbers Allowed!!!")
            Exit Sub
        ElseIf CheckMatThick() = False Then
            MsgBox("Material Thickness : Only Numbers Allowed!!!")
            Exit Sub
        ElseIf CheckMatRad() = False Then
            MsgBox("Material Radius : Only Numbers Allowed!!!")
            Exit Sub
        End If


        Try

            Str = "update PicketLib set Height="
            Str += """" & PicketHeight.Text & """"
            Str += " where ID="
            Str += """" & PicketID.Text & """"
            PicketCon.Open()
            PicketCmd = New OleDbCommand(Str, PicketCon)
            PicketCmd.ExecuteNonQuery()
            PicketCon.Close()
            PicketCon.Open()
            Str = "update PicketLib set Width="
            Str += """" & PicketWidth.Text & """"
            Str += " where ID="
            Str += """" & PicketID.Text & """"
            PicketCmd = New OleDbCommand(Str, PicketCon)
            PicketCmd.ExecuteNonQuery()
            PicketCon.Close()
            PicketCon.Open()
            Str = "update PicketLib set Thickness="
            Str += """" & PicketThick.Text & """"
            Str += " where ID="
            Str += """" & PicketID.Text & """"
            PicketCmd = New OleDbCommand(Str, PicketCon)
            PicketCmd.ExecuteNonQuery()
            PicketCon.Close()
            PicketCon.Open()
            Str = "update PicketLib set Radius="
            Str += """" & PicketRad.Text & """"
            Str += " where ID="
            Str += """" & PicketID.Text & """"
            PicketCmd = New OleDbCommand(Str, PicketCon)
            PicketCmd.ExecuteNonQuery()
            PicketCon.Close()

            PicketDst.Clear()
            PicketDad = New OleDbDataAdapter("SELECT * FROM PicketLib ORDER BY ID", PicketCon)
            PicketDad.Fill(PicketDst, "PicketLib")
            MsgBox("Updated Successfully...")

        Catch ex As Exception
            MsgBox(ex.Message & "--" & ex.Source)
            PicketCon.Close()

        End Try
        Me.PicketLibTableAdapter.Update(Me.PicketsDBDataSet.PicketLib) 'must have this to load data in to the drop down menu.
        Me.PicketLibTableAdapter.Fill(Me.PicketsDBDataSet.PicketLib) 'must have this to load data in to the drop down menu.
    End Sub





    ' To check the data in Id field : whether numeric or not 
    Private Function CheckId()
        Try
            If IsNumeric(PicketID.Text) = True Then
                ShowData(PicketCurrentRow)
                PicketID.Focus()
                Return False
            End If
        Catch ex As Exception
        End Try
        Return True
    End Function






    ' To check the data in First : whether a string or not
    Private Function CheckMaterialHeight()
        Try
            If IsNumeric(PicketHeight.Text) = True Then
                ' ShowData(CurrentRow)
                ' MatHeight.Focus()
                Return True
            End If
        Catch ex As Exception
        End Try
        Return False
    End Function






    ' To check the data in Second Field : whether a string or not
    Private Function CheckMaterialWidth()
        Try
            If IsNumeric(PicketWidth.Text) = True Then
                ' ShowData(CurrentRow)
                ' MatWidth.Focus()
                Return True
            End If
        Catch ex As Exception
        End Try
        Return False
    End Function






    ' To check the data in Third Field : whether a string or not
    Private Function CheckMatThick()
        Try
            If IsNumeric(PicketThick.Text) = True Then
                '  ShowData(CurrentRow)
                ' MatThick.Focus()
                Return True
            End If
        Catch ex As Exception
        End Try
        Return False
    End Function

    ' To check the data in Fourth Field : whether a string or not
    Private Function CheckMatRad()
        Try
            If IsNumeric(PicketRad.Text) = True Then
                '  ShowData(CurrentRow)
                ' MatRad.Focus()
                Return True
            End If
        Catch ex As Exception
        End Try
        Return False
    End Function




    ' To check the string for numeric values
    Private Function ValidateString(ByVal Str)
        Dim i As Integer
        Dim ch As Char
        i = 0
        While i < Str.Length()
            ch = Str.Chars(i)
            If IsNumeric(ch) = True Then
                Return False
            End If
            i += 1
        End While
        Return True
    End Function





    ' To show the data in the datagridview
    Private Sub ShowPicketLib_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ShowPicketLib.Click
        Me.Hide()
        Me.PicketLibTableAdapter.Update(Me.PicketsDBDataSet.PicketLib) 'must have this to load data in to the drop down menu.
        PicketsTbl.Show()
    End Sub





    ' To check whether Id exist in database
    Private Function IfIdExist()
        Dim Str, Str1 As String
        Dim i As Integer
        Str = PicketID.Text
        i = 0
        While i <> PicketDst.Tables("PicketLib").rows.count
            Str1 = PicketDst.Tables("PicketLib").Rows(i)("ID")
            If Str = Str1 Then
                Return True
            End If
            i += 1
        End While
        Return False

    End Function



End Class