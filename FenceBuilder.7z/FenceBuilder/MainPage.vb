﻿Imports System.Data.OleDb


Friend Class MainPage

    Public PicketSpaceNoSlope As Double



    Public Sub MainPage_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Me.RaLibTableAdapter.Fill(Me.BottomRailsDBDataSet.RaLib)
        Me.PoLibTableAdapter1.Fill(Me.PostsDBDataSet1.PoLib)
        Me.PicketLibTableAdapter.Fill(Me.PicketsDataSet.PicketLib)
        Me.RaLibTableAdapter1.Fill(Me.TopRailsDataSet.RaLib)
        GroupBoxRise.Enabled = False
        GroupBoxRun.Enabled = False
        GroupBoxDeckToPost.Enabled = False
        GroupBoxPostToStep.Enabled = False
        GroupBox5.Enabled = False
        CheckBox1.Enabled = True
        CheckBox1.Checked = False
        StrRise.Enabled = False
        StrRun.Enabled = False
        DeckEdge.Enabled = False
        StepEdge.Enabled = False
        Post2FirstStepUpSel.Enabled = False
        Post2FirstStepDownSel.Enabled = False
        DeckEdge2PostUpSel.Enabled = False
        DeckEdge2PostDownSel.Enabled = False
        CheckBox2.Enabled = False
        AngleRef.Enabled = False
        PostBelowGround.Text = 0
        DesPicketSpc.Text = 3.5
        RailHeight.Text = 36
        InBetweenDistance.Text = 48
        DistanceFromTop.Text = 3
        DistanceToBottom.Text = 3.5
        IBDIncrement.Text = 0.125
        StepEdge.Text = 0
        DeckEdge.Text = 3
    End Sub



    Public Sub InbetweenDistanceUpSelect_Click(sender As Object, e As EventArgs) Handles InBetweenDistanceUpSelect.Click

        InBetweenDistance.Text = InBetweenDistance.Text + (IBDIncrement.Text * 1)
    End Sub
    Public Sub InbetweenDistanceDownSelect_Click(sender As Object, e As EventArgs) Handles InbetweenDistanceDownSelect.Click
        InBetweenDistance.Text = InBetweenDistance.Text - (IBDIncrement.Text * 1)
    End Sub
    Public Sub RailHeightUpSelect_Click(sender As Object, e As EventArgs) Handles RailHeightUpSelect.Click
        RailHeight.Text = RailHeight.Text + (RailHeightIncrement.Text * 1)
    End Sub
    Public Sub RailheightDownSelect_Click(sender As Object, e As EventArgs) Handles RailHeightDownSelect.Click
        RailHeight.Text = RailHeight.Text - (RailHeightIncrement.Text * 1)
    End Sub
    Public Sub DFTUpSelect_Click(sender As Object, e As EventArgs) Handles DFTUpSelect.Click
        DistanceFromTop.Text = DistanceFromTop.Text + (DFTIncrement.Text * 1)
    End Sub
    Public Sub DFTDownSelect_Click(sender As Object, e As EventArgs) Handles DFTDownSelect.Click
        DistanceFromTop.Text = DistanceFromTop.Text - (DFTIncrement.Text * 1)
    End Sub
    Public Sub DTBUpSelect_Click(sender As Object, e As EventArgs) Handles DTBUpSelect.Click
        DistanceToBottom.Text = DistanceToBottom.Text + (DTBIncrement.Text * 1)
    End Sub
    Public Sub DTBDownSelect_Click(sender As Object, e As EventArgs) Handles DTBDownSelect.Click
        DistanceToBottom.Text = DistanceToBottom.Text - (DTBIncrement.Text * 1)
    End Sub
    Public Sub PicSpaceDownSelect_Click(sender As Object, e As EventArgs) Handles PicSpaceDownSelect.Click
        DesPicketSpc.Text = DesPicketSpc.Text - (DPSIncrement.Text * 1)
    End Sub
    Public Sub PicSpaceUpSelect_Click(sender As Object, e As EventArgs) Handles PicSpaceUpSelect.Click
        DesPicketSpc.Text = DesPicketSpc.Text + (DPSIncrement.Text * 1)
    End Sub
    Public Sub Post2FirstStepDownSel_Click(sender As Object, e As EventArgs) Handles Post2FirstStepDownSel.Click
        StepEdge.Text = StepEdge.Text - (StepEdgeIncrement.Text * 1)
    End Sub
    Public Sub Post2FirstStepUpSel_Click(sender As Object, e As EventArgs) Handles Post2FirstStepUpSel.Click
        StepEdge.Text = StepEdge.Text + (StepEdgeIncrement.Text * 1)
    End Sub
    Public Sub DeckEdge2PostDownSel_Click(sender As Object, e As EventArgs) Handles DeckEdge2PostDownSel.Click
        DeckEdge.Text = DeckEdge.Text - (DeckEdgeIncrement.Text * 1)
    End Sub
    Public Sub DeckEdge2PostUpSel_Click(sender As Object, e As EventArgs) Handles DeckEdge2PostUpSel.Click
        DeckEdge.Text = DeckEdge.Text + (DeckEdgeIncrement.Text * 1)
    End Sub
    Public Sub AmtInGroundDownSel_Click(sender As Object, e As EventArgs) Handles AmtInGroundDownSel.Click
        PostBelowGround.Text = PostBelowGround.Text - (AmtInGroundInc.Text * 1)
    End Sub
    Public Sub AmtInGroundUpSel_Click(sender As Object, e As EventArgs) Handles AmtInGroundUpSel.Click
        PostBelowGround.Text = PostBelowGround.Text + (AmtInGroundInc.Text * 1)
    End Sub
    Public Sub HoleClearanceDownSel_Click(sender As Object, e As EventArgs) Handles HoleClearanceDownSel.Click
        PostHoleClearance.Text = PostHoleClearance.Text - (HoleClearanceInc.Text * 1)
    End Sub
    Public Sub HoleClearanceUpSel_Click(sender As Object, e As EventArgs) Handles HoleClearanceUpSel.Click
        PostHoleClearance.Text = PostHoleClearance.Text + (HoleClearanceInc.Text * 1)
    End Sub



    Public Sub RiseUpSelect_Click(sender As Object, e As EventArgs) Handles RiseUpSelect.Click
        StrRise.Text = StrRise.Text + (RiseIncrement.Text * 1)
    End Sub
    Public Sub RiseDownSelect_Click(sender As Object, e As EventArgs) Handles RiseDownSelect.Click
        StrRise.Text = StrRise.Text - (RiseIncrement.Text * 1)
    End Sub
    Public Sub RunUpSelect_Click(sender As Object, e As EventArgs) Handles RunUpSelect.Click
        StrRun.Text = StrRun.Text + (RunIncrement.Text * 1)
    End Sub
    Public Sub RunDownSelect_Click(sender As Object, e As EventArgs) Handles RunDownSelect.Click
        StrRun.Text = StrRun.Text - (RunIncrement.Text * 1)
    End Sub




    Public Sub Combobox3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboBox3.Click
        Me.PoLibTableAdapter1.Update(Me.PostsDBDataSet1.PoLib)
        Me.PoLibTableAdapter1.Fill(Me.PostsDBDataSet1.PoLib)
    End Sub
    Public Sub Combobox1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboBox1.Click
        Me.RaLibTableAdapter1.Update(Me.TopRailsDataSet.RaLib)
        Me.RaLibTableAdapter1.Fill(Me.TopRailsDataSet.RaLib)
        Me.RaLibTableAdapter.Update(Me.BottomRailsDBDataSet.RaLib)
        Me.RaLibTableAdapter.Fill(Me.BottomRailsDBDataSet.RaLib)
    End Sub
    Public Sub ComboBox2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboBox2.Click

        Me.RaLibTableAdapter.Update(Me.BottomRailsDBDataSet.RaLib)
        Me.RaLibTableAdapter.Fill(Me.BottomRailsDBDataSet.RaLib)
    End Sub
    Public Sub PicketComboBox_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PicketComboBox.Click
        Me.PicketLibTableAdapter.Update(Me.PicketsDataSet.PicketLib)
        Me.PicketLibTableAdapter.Fill(Me.PicketsDataSet.PicketLib)
    End Sub
    Private Sub CheckBox1_CheckedChange(sender As Object, e As EventArgs) Handles CheckBox1.CheckedChanged
        If CheckBox1.Checked = True Then
            GroupBoxRise.Enabled = True
            GroupBoxRun.Enabled = True
            GroupBoxDeckToPost.Enabled = True
            GroupBoxPostToStep.Enabled = True
            GroupBox5.Enabled = True
            CheckBox2.Text = "Aligned"
            StrRise.Enabled = True
            StrRise.Text = 7
            StrRun.Enabled = True
            StrRun.Text = 11
            DeckEdge.Enabled = True
            StepEdge.Enabled = True
            Post2FirstStepUpSel.Enabled = True
            Post2FirstStepDownSel.Enabled = True
            DeckEdge2PostUpSel.Enabled = True
            DeckEdge2PostDownSel.Enabled = True
            CheckBox2.Enabled = True
            AngleRef.Enabled = True
            '  StrRunLabel.Enabled = True
            '  StrRiseLabel.Enabled = True
        Else
            GroupBoxRise.Enabled = False
            GroupBoxRun.Enabled = False
            GroupBoxDeckToPost.Enabled = False
            GroupBoxPostToStep.Enabled = False
            GroupBox5.Enabled = False
            CheckBox1.Text = "Slope"
            CheckBox2.Text = "Linear"
            StrRise.Enabled = False
            StrRun.Enabled = False
            DeckEdge.Enabled = False
            StepEdge.Enabled = False
            CheckBox2.Enabled = False
            '    StrRiseLabel.Enabled = False
            '   StrRunLabel.Enabled = False
        End If
    End Sub
    Public Sub StrRise_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles StrRise.TextChanged
        Const rad2deg = 57.2957795130823
        Const pi = 3.14159265359


        If String.IsNullOrEmpty(StrRise.Text) OrElse String.IsNullOrEmpty(StrRun.Text) Then Exit Sub
        If Not IsNumeric(StrRise.Text) OrElse Not IsNumeric(StrRun.Text) Then Exit Sub

        If CheckBox1.Checked = True Then

            AngleRef.Text = Math.Round((rad2deg * (((Math.Asin((Math.Sin((90 * pi / 180)) * StrRise.Text) / (Math.Sqrt(((StrRise.Text ^ 2) + StrRun.Text ^ 2)) - (2 * StrRise.Text * StrRun.Text) * (Math.Cos((90 * pi / 180))))))))), 1) & "°"

        End If

    End Sub
    Public Sub StrRun_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles StrRun.TextChanged
        Const rad2deg = 57.2957795130823
        Const pi = 3.14159265359


        If String.IsNullOrEmpty(StrRise.Text) OrElse String.IsNullOrEmpty(StrRun.Text) Then Exit Sub
        If Not IsNumeric(StrRise.Text) OrElse Not IsNumeric(StrRun.Text) Then Exit Sub

        If CheckBox1.Checked = True Then

            AngleRef.Text = Math.Round((rad2deg * (((Math.Asin((Math.Sin((90 * pi / 180)) * StrRise.Text) / (Math.Sqrt(((StrRise.Text ^ 2) + StrRun.Text ^ 2)) - (2 * StrRise.Text * StrRun.Text) * (Math.Cos((90 * pi / 180))))))))), 1) & "°"

        End If

    End Sub
    '' Calc
    Public Sub StairCalc_Click(sender As Object, e As EventArgs) Handles StairCalc.Click
        Const pi = 3.14159265359
        Const rad2deg = 57.2957795130823
        Dim RoundValue As Integer = 3
        Dim Radians As Double
        Dim Degrees As Double
        Dim AltAngl As Double
        Dim ActPicSpc As Double
        Dim GapBase As Double
        Dim GapBaseZ As Double
        Dim TopRailHole As Double
        Dim BotRailHole As Double
        Dim InBetweenAligned As Double
        Dim DistanceFromTop As Double
        Dim DistanceToBottom As Double
        Dim TopRailHeight As Double
        Dim BotRailHeight As Double
        Dim RailHeight As Double
        Dim StrRise As Double
        Dim StrRun As Double
        Dim NumPicketHoles As Double
        Dim DesPicketSpc As Double
        Dim PostThick As Double
        Dim TempCalc As Double
        Dim PicketHeight As Double
        Dim StanRailCutL As Double
        Dim PostBelowGround As Double
        Dim TopPostCutLength As Double
        Dim TopStrRailCutL As Double
        Dim BotStrRailCutL As Double
        Dim TopStrRailPicSpace As Double
        Dim TopStrRailDisFirstHole As Double
        Dim BotStrRailPicSpace As Double
        Dim BotStrRailDisFirstHole As Double
        Dim StanDistFirstHole As Double
        Dim PicketCutL As Double
        Dim BetweenHolesNoSlope As Double
        Dim BetweenHolesSlope As Double
        Dim BotPostCutLength As Double
        Dim TopPostFirstHole2 As Double
        Dim BotPostFirstHole2 As Double
        Dim PostFirstHole As Double
        Dim PostSecondHole As Double
        Dim PostCutLength As Double
        '    Dim PostHoleClearance As Double
        ''  Dim InBetweenDistance As Double
        DataGridView1.Rows.Clear()

        DistanceFromTop = Val(Me.DistanceFromTop.Text)
        DistanceToBottom = Val(Me.DistanceToBottom.Text)
        TopRailHeight = Val(Me.TopRailHeight.Text)
        BotRailHeight = Val(Me.BotRailHeight.Text)
        RailHeight = Val(Me.RailHeight.Text)
        StrRise = Val(Me.StrRise.Text)
        StrRun = Val(Me.StrRun.Text)
        'InBetweenDistance = Val(Me.InBetweenDistance.Text)
        PostThick = Val(Me.PostThick.Text)
        PicketHeight = Val(Me.PicketHeight.Text)
        DistanceToBottom = Val(Me.DistanceToBottom.Text)
        DistanceFromTop = Val(Me.DistanceFromTop.Text)
        RailHeight = Val(Me.RailHeight.Text)
        PostBelowGround = Val(Me.PostBelowGround.Text)
        BotRailHeight = Val(Me.BotRailHeight.Text)
        ' PostHoleClearance = Val(Me.PostHoleClearance.Text)
        DistanceFromTop = Val(Me.DistanceFromTop.Text)
        DistanceToBottom = Val(Me.DistanceToBottom.Text)
        BotRailHeight = Val(Me.BotRailHeight.Text)
        RailHeight = Val(Me.RailHeight.Text)
        StrRise = Val(Me.StrRise.Text)
        StrRun = Val(Me.StrRun.Text)
        PostThick = Val(Me.PostThick.Text)
        PicketHeight = Val(Me.PicketHeight.Text)

        If Not IsNumeric(Me.RailHeight.Text) Then
            MsgBox("Enter a numeric value for Railing Height.")
            Me.RailHeight.Select()
            Exit Sub

        End If
        If Me.RailHeight.Text < (TopRailHeight + BotRailHeight + DistanceFromTop + DistanceToBottom) Then
            TempCalc = (TopRailHeight + BotRailHeight + DistanceFromTop + DistanceToBottom)
            MsgBox("Railing Height must be greater than" & Space(1) & TempCalc)
            Me.RailHeight.Focus()
            Exit Sub
        End If
        If Not IsNumeric(Me.InBetweenDistance.Text) Then
            MsgBox("Enter a numeric value for In-between Distance.")
            Me.InBetweenDistance.Text = ""
            Me.InBetweenDistance.Focus()
            Exit Sub
        End If
        If Me.InBetweenDistance.Text < ((DesPicketSpc * 2) + PicketHeight) Then
            TempCalc = ((DesPicketSpc * 2) + PicketHeight)
            MsgBox("In-between distance must be greater than or equal to" & Space(1) & TempCalc)
            Me.InBetweenDistance.Text = ""
            Me.InBetweenDistance.Focus()
            Exit Sub
        End If
        If Not IsNumeric(Me.DistanceToBottom.Text) Then
            MsgBox("Enter a numeric value for Distance To Bottom.")
            Me.DistanceToBottom.Text = ""
            Me.DistanceToBottom.Focus()
        End If
        If Me.DistanceToBottom.Text = 0 Then
            MsgBox("Distance To Bottom must be greater than zero.")
            Me.DistanceToBottom.Text = ""
            Me.DistanceToBottom.Focus()
            Exit Sub
        End If
        If Not IsNumeric(Me.PicketHeight.Text) Then
            MsgBox("Enter a numeric value for Picket Size")
            Me.PicketHeight.Text = ""
            Me.PicketHeight.Focus()
        End If
        If Me.PicketHeight.Text = 0 Then
            MsgBox("Picket Size must be greater than zero.")
            Me.PicketHeight.Select()
            Exit Sub
        End If
        If Not IsNumeric(Me.InBetweenDistance.Text) Then
            MsgBox("Enter a numeric value for In-between Distance.")
            Me.InBetweenDistance.Text = ""
            Me.InBetweenDistance.Focus()
            Exit Sub
        End If
        If Me.InBetweenDistance.Text < ((DesPicketSpc * 2) + PicketHeight) Then
            TempCalc = ((DesPicketSpc * 2) + PicketHeight)
            MsgBox("In-between distance must be greater than or equal to" & Space(1) & TempCalc)
            Me.InBetweenDistance.Text = ""
            Me.InBetweenDistance.Focus()
            Exit Sub
        End If
        If Not IsNumeric(Me.PicketHeight.Text) Then
            MsgBox("Enter a value for Picket Size.")
            Me.PicketHeight.Text = ""
            Me.PicketHeight.Focus()
            Exit Sub
        End If
        If Me.PicketHeight.Text = "" Then
            MsgBox("Picket Size must be greater than Zero")
            Me.PicketHeight.Text = ""
            Me.PicketHeight.Focus()
            Exit Sub
        End If
        If Not IsNumeric(Me.DesPicketSpc.Text) Then
            MsgBox("Enter a numeric value for Picket Spacing.")
            Me.DesPicketSpc.Text = ""
            Exit Sub
        End If
        If Me.DesPicketSpc.Text = "0" Then
            MsgBox("Picket Spacing must be greater than Zero")
            Me.DesPicketSpc.Text = ""
            Me.DesPicketSpc.Focus()
            Exit Sub
        End If
        If Not IsNumeric(Me.RailHeight.Text) Then
            MsgBox("Enter a numeric value for Railing Height.")
            Me.RailHeight.Select()
            Exit Sub
        End If
        If Me.RailHeight.Text < (TopRailHeight + BotRailHeight + DistanceFromTop + DistanceToBottom) Then
            TempCalc = (TopRailHeight + BotRailHeight + DistanceFromTop + DistanceToBottom)
            MsgBox("Railing Height must be greater than" & Space(1) & TempCalc)
            Me.RailHeight.Focus()
            Exit Sub
        End If
        If Not IsNumeric(Me.PostBelowGround.Text) Then
            MsgBox("Enter a numeric value for Amount Below Ground.")
            Me.PostBelowGround.Text = ""
            Exit Sub
        End If
        If Not IsNumeric(Me.PostHoleClearance.Text) Then
            MsgBox("Enter a numeric value for Picket Spacing.")
            Me.PostHoleClearance.Text = ""
            Exit Sub
        End If
        If Not IsNumeric(Me.RailHeight.Text) Then
            MsgBox("Enter a numeric value for Railing Height.")
            Me.RailHeight.Select()
            Exit Sub

        End If
        If Me.RailHeight.Text < (TopRailHeight + BotRailHeight + DistanceFromTop + DistanceToBottom) Then
            TempCalc = (TopRailHeight + BotRailHeight + DistanceFromTop + DistanceToBottom)
            MsgBox("Railing Height must be greater than" & Space(1) & TempCalc)
            Me.RailHeight.Focus()
            Exit Sub
        End If
        If Not IsNumeric(Me.DistanceToBottom.Text) Then
            MsgBox("Enter a numeric value for Distance To Bottom.")
            Me.DistanceToBottom.Text = ""
            Me.DistanceToBottom.Focus()
        End If
        If Me.DistanceToBottom.Text = 0 Then
            MsgBox("Distance To Bottom must be greater than zero.")
            Me.DistanceToBottom.Text = ""
            Me.DistanceToBottom.Focus()
            Exit Sub
        End If
        If CheckBox1.Checked = True Then
            If Me.StrRise.Text = 0 Then
                MsgBox("Stair Rise cannot be zero.")
                Me.StrRise.Text = ""
                Me.StrRise.Focus()
                Exit Sub
            End If
            If Me.StrRun.Text = 0 Then
                MsgBox("Stair Run cannot be zero.")
                Me.StrRun.Text = ""
                Me.StrRun.Focus()
                Exit Sub
            End If
        End If

        If CheckBox1.Checked = True Then

            Radians = ((Math.Asin((Math.Sin((90 * pi / 180)) * StrRise) / (Math.Sqrt(((StrRise ^ 2) + StrRun ^ 2)) - (2 * StrRise * StrRun) * (Math.Cos((90 * pi / 180)))))))
            Degrees = (rad2deg * Radians)
            AltAngl = ((90 - Degrees) * (3.14159265359 / 180))

            GapBase = StrRun - DeckEdge.Text - StepEdge.Text
            GapBaseZ = GapBase * Math.Tan(Radians)
            TopRailHole = Math.Round((Me.PicketHeight.Text / (StrRun / (Math.Sqrt((StrRise ^ 2) + StrRun ^ 2)))) + (TopRailThick.Text * Math.Tan(Radians)), RoundValue)
            BotRailHole = Math.Round((Me.PicketHeight.Text / (StrRun / (Math.Sqrt((StrRise ^ 2) + StrRun ^ 2)))) + (BotRailThick.Text * Math.Tan(Radians)), RoundValue)
            DesPicketSpc = Math.Round((Me.DesPicketSpc.Text / (StrRun / (Math.Sqrt((StrRise ^ 2) + StrRun ^ 2)))), RoundValue)



            If CheckBox2.Checked = True Then
                InBetweenAligned = Me.InBetweenDistance.Text
                Label2.Text = Math.Round(InBetweenAligned * (Math.Cos(Radians)), RoundValue)
                Label17.Text = "Actual IBD"
            Else
                InBetweenAligned = Me.InBetweenDistance.Text * (Math.Cos(Radians) ^ -1)
                Label2.Text = Math.Round(Me.InBetweenDistance.Text / (Math.Cos(Radians)), RoundValue)
                Label17.Text = "Aligned IBD"
            End If

            NumPicketHoles = Fix(InBetweenAligned / (DesPicketSpc + TopRailHole)) 'a bug,, cant be top rail always. or, shouldnt be if there is a large differfence in top and bottom rail

            ActPicSpc = (InBetweenAligned * Math.Cos(Radians) - ((NumPicketHoles * (Me.PicketHeight.Text)) / (NumPicketHoles + 1)))
            TopStrRailCutL = Math.Round(InBetweenAligned + ((BotRailThick.Text) * Math.Cos(((Degrees * 2 * pi) / 360)) ^ -1) + ((TopRailThick.Text) * Math.Cos(((Degrees * 2 * pi) / 360)) ^ -1) + ((Me.TopRailHeight.Text * Math.Tan((Degrees * 2 * pi) / 360))) + (ExtraEndMat.Text * 2), RoundValue)

            ' Me.TopRailHole.Text = TopRailHol
            TopStrRailPicSpace = Math.Round(((InBetweenAligned - (NumPicketHoles * (TopRailHole))) / (NumPicketHoles + 1)), RoundValue)
            TopStrRailDisFirstHole = Math.Round((((Me.TopRailHeight.Text * Math.Tan((Degrees * 2 * pi) / 360))) + TopStrRailPicSpace + ((TopRailThick.Text) * Math.Cos(((Degrees * 2 * pi) / 360)) ^ -1) + ExtraEndMat.Text) - (PostThick * Math.Tan(Radians) / 2), RoundValue)
            BotStrRailCutL = Math.Round(InBetweenAligned + ((BotRailThick.Text) * Math.Cos(((Degrees * 2 * pi) / 360)) ^ -1) + ((TopRailThick.Text) * Math.Cos(((Degrees * 2 * pi) / 360)) ^ -1) + ((Me.BotRailHeight.Text * Math.Tan((Degrees * 2 * pi) / 360))) + (ExtraEndMat.Text * 2), RoundValue)

            ' Me.BotRailHole.Text = BotRailHole
            BotStrRailPicSpace = Math.Round((((InBetweenAligned - (NumPicketHoles * (BotRailHole)))) / (NumPicketHoles + 1)), RoundValue)
            BotStrRailDisFirstHole = Math.Round((BotStrRailPicSpace + ((BotRailThick.Text) * Math.Cos(((Degrees * 2 * pi) / 360)) ^ -1) + ExtraEndMat.Text) + (PostThick * Math.Tan(Radians) * 0.5), RoundValue) 'addeda half

            ActPicketSpc.Text = Math.Round((TopStrRailPicSpace * Math.Cos(Radians)) + (PostThick * Math.Tan(Radians)), RoundValue)
            PostFirstHole = Math.Round(TopRailHeight / (StrRun / (Math.Sqrt((StrRise ^ 2) + (StrRun ^ 2)))) + (PostThick / Math.Tan(AltAngl)), RoundValue)
            PostSecondHole = Math.Round(BotRailHeight / (StrRun / (Math.Sqrt((StrRise ^ 2) + (StrRun ^ 2)))) + (PostThick / Math.Tan(AltAngl)), RoundValue)
            TopPostFirstHole2 = Math.Round(DistanceFromTop - PostThick * Math.Tan(Radians), RoundValue)
            BotPostFirstHole2 = Math.Round((DistanceFromTop), RoundValue)

            BetweenHolesSlope = Math.Round((RailHeight - PostFirstHole - PostSecondHole - DistanceToBottom) + (PostThick * Math.Tan(Radians)), RoundValue)
            PicketCutL = Math.Round(BetweenHolesSlope + (Convert.ToDecimal(PostFirstHole) + PostSecondHole) - Me.PostThick.Text * Math.Tan(Radians) - (Me.PicketHeight.Text * Math.Tan(Radians)) - (Me.TopRailThick.Text / Math.Cos(Radians)) - (Me.BotRailThick.Text / Math.Cos(Radians)) - Me.PicketClear.Text, RoundValue)
            TopPostCutLength = Math.Round((RailHeight + DistanceFromTop), RoundValue)

            BotPostCutLength = Math.Round(((RailHeight + DistanceFromTop) + GapBaseZ), RoundValue)

            NumPicketHoles = Fix(Me.InBetweenDistance.Text / (DesPicketSpc + PicketHeight))
            PostCutLength = RailHeight + DistanceFromTop + PostBelowGround
            BetweenHolesNoSlope = (Me.RailHeight.Text - Me.DistanceToBottom.Text - Me.TopRailHeight.Text - Me.BotRailHeight.Text - (Me.PostHoleClearance.Text * 2))
            PicketSpaceNoSlope = Math.Round(((Me.InBetweenDistance.Text - (NumPicketHoles * (PicketHeight))) / (NumPicketHoles + 1)), RoundValue)
            StanDistFirstHole = ((StanRailCutL - Me.InBetweenDistance.Text) / 2) + PicketSpaceNoSlope


            ''enter datagrid view here

            ' Create an unbound DataGridView by declaring a column count.
            DataGridView1.ColumnCount = 8

            DataGridView1.ColumnHeadersVisible = True

            ' Set the column header style.
            Dim columnHeaderStyle As New DataGridViewCellStyle()

            columnHeaderStyle.BackColor = Color.Beige
            columnHeaderStyle.Font = New Font("Verdana", 10, FontStyle.Bold)
            DataGridView1.ColumnHeadersDefaultCellStyle = columnHeaderStyle


            ' DataGridView1.AutoResizeColumns()

            ' Set the column header names.
            DataGridView1.Columns(0).Name = "ITEM"
            DataGridView1.Columns(1).Name = "CUT LENGTH"
            DataGridView1.Columns(2).Name = "HOLES"
            DataGridView1.Columns(3).Name = "PICKETS"

            DataGridView1.Columns(4).Name = "HOLE SPACING"
            DataGridView1.Columns(5).Name = "HOLE 1 DIST"
            DataGridView1.Columns(6).Name = "HOLE 1 SIZE"
            DataGridView1.Columns(7).Name = "HOLE 2 SIZE"
            ' Populate the rows.

            Dim row1() As String = {ComboBox1.Text + "" + "Top Rail", TopStrRailCutL, NumPicketHoles, "", TopStrRailPicSpace, TopStrRailDisFirstHole}
            Dim row2() As String = {ComboBox2.Text + "" + "Bottom Rail", BotStrRailCutL, NumPicketHoles, "", BotStrRailPicSpace, BotStrRailDisFirstHole}
            Dim row3() As String = {PicketComboBox.Text + "" + "Pickets", PicketCutL, "", NumPicketHoles}
            Dim row4() As String = {ComboBox3.Text + "" + "Post", TopPostCutLength, "", BetweenHolesSlope, TopPostFirstHole2, PostFirstHole}
            Dim row5() As String = {ComboBox3.Text + "" + "Post", BotPostCutLength, "", BetweenHolesSlope, BotPostFirstHole2, PostSecondHole}
            Dim rows() As Object = {row1, row2, row3, row4, row5}

            Dim rowArray As String()
            For Each rowArray In rows
                DataGridView1.Rows.Add(rowArray)
            Next rowArray


        Else

            PicketCutL = (Me.RailHeight.Text - Me.DistanceToBottom.Text - TopRailThick.Text - BotRailThick.Text - PicketClear.Text)
            DesPicketSpc = Val(Me.DesPicketSpc.Text)
            StanRailCutL = Math.Round(Me.InBetweenDistance.Text + (ExtraEndMat.Text * 2), RoundValue)
            NumPicketHoles = Fix(Me.InBetweenDistance.Text / (DesPicketSpc + PicketHeight))
            PostCutLength = RailHeight + DistanceFromTop + PostBelowGround
            BetweenHolesNoSlope = (Me.RailHeight.Text - Me.DistanceToBottom.Text - Me.TopRailHeight.Text - Me.BotRailHeight.Text - (Me.PostHoleClearance.Text * 2))
            PicketSpaceNoSlope = Math.Round(((Me.InBetweenDistance.Text - (NumPicketHoles * (PicketHeight))) / (NumPicketHoles + 1)), RoundValue)
            StanDistFirstHole = ((StanRailCutL - Me.InBetweenDistance.Text) / 2) + PicketSpaceNoSlope

            ' Create an unbound DataGridView by declaring a column count.
            DataGridView1.ColumnCount = 5
            DataGridView1.ColumnHeadersVisible = True

            ' Set the column header style.
            Dim columnHeaderStyle As New DataGridViewCellStyle()

            columnHeaderStyle.BackColor = Color.Beige
            columnHeaderStyle.Font = New Font("Verdana", 10, FontStyle.Bold)
            DataGridView1.ColumnHeadersDefaultCellStyle = columnHeaderStyle

            ' Set the column header names.
            DataGridView1.Columns(0).Name = "Item"
            DataGridView1.Columns(1).Name = "Cut Length"
            DataGridView1.Columns(2).Name = "Holes"
            DataGridView1.Columns(3).Name = "Spacing"
            DataGridView1.Columns(4).Name = "First Hole"


            ' Populate the rows.

            Dim row1() As String = {ComboBox1.Text + "Rails", StanRailCutL, NumPicketHoles, PicketSpaceNoSlope, StanDistFirstHole}
            Dim row2() As String = {PicketComboBox.Text + "Pickets", PicketCutL, NumPicketHoles}
            Dim row3() As String = {ComboBox3.Text + "Post", PostCutLength, "", BetweenHolesNoSlope, DistanceFromTop}

            Dim rows() As Object = {row1, row2, row3}

            Dim rowArray As String()
            For Each rowArray In rows
                DataGridView1.Rows.Add(rowArray)
            Next rowArray


        End If


    End Sub


    '' Reset

    Private Sub Reset_Click(sender As Object, e As EventArgs) Handles StairReset.Click

        Me.RaLibTableAdapter.Fill(Me.BottomRailsDBDataSet.RaLib)
        Me.PoLibTableAdapter1.Fill(Me.PostsDBDataSet1.PoLib)
        Me.PicketLibTableAdapter.Fill(Me.PicketsDataSet.PicketLib)
        Me.RaLibTableAdapter1.Fill(Me.TopRailsDataSet.RaLib)
        GroupBoxRise.Enabled = False
        GroupBoxRun.Enabled = False
        GroupBoxDeckToPost.Enabled = False
        GroupBoxPostToStep.Enabled = False
        GroupBox5.Enabled = False
        CheckBox1.Enabled = True
        CheckBox1.Checked = False
        StrRise.Enabled = False
        StrRun.Enabled = False
        DeckEdge.Enabled = False
        StepEdge.Enabled = False
        Post2FirstStepUpSel.Enabled = False
        Post2FirstStepDownSel.Enabled = False
        DeckEdge2PostUpSel.Enabled = False
        DeckEdge2PostDownSel.Enabled = False
        CheckBox2.Enabled = False
        AngleRef.Enabled = False
        PostBelowGround.Text = 0
        DesPicketSpc.Text = 3.5
        RailHeight.Text = 36
        InBetweenDistance.Text = 48
        DistanceFromTop.Text = 3
        DistanceToBottom.Text = 3.5
        IBDIncrement.Text = 0.125
        StepEdge.Text = 0
        DeckEdge.Text = 3
    End Sub

    Public Sub RailingDB_Click(sender As Object, e As EventArgs) Handles RailingDB.Click
        RailLibrary.Show()
    End Sub
    Public Sub PostDB_Click(sender As Object, e As EventArgs) Handles PostDB.Click
        PostLibrary.Show()
    End Sub
    Public Sub PicketsDB_Click(sender As Object, e As EventArgs) Handles PicketsDB.Click
        PicketLibrary.Show()
    End Sub


End Class