﻿
Public Class PicketsTbl
    ' To display the data in datagridview control
    Private Sub PicketTbl_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        DataGridView3.DataSource = PicketDst.Tables(0)
    End Sub
    ' To close the current form and display main frame
    Private Sub PicketTableExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PicketTableExit.Click
        Me.Close()
        PicketLibrary.Show()
    End Sub
End Class