﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class MainPage
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(MainPage))
        Me.Options = New System.Windows.Forms.GroupBox()
        Me.AmtInGroundDownSel = New System.Windows.Forms.Button()
        Me.AmtInGroundUpSel = New System.Windows.Forms.Button()
        Me.PostBelowGround = New System.Windows.Forms.TextBox()
        Me.PostHoleClearance = New System.Windows.Forms.TextBox()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.ActPicketSpc = New System.Windows.Forms.Label()
        Me.AngleRef = New System.Windows.Forms.Label()
        Me.StairCalc = New System.Windows.Forms.Button()
        Me.StairReset = New System.Windows.Forms.Button()
        Me.PostHeight = New System.Windows.Forms.TextBox()
        Me.PoLibBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.PostsDBDataSet1 = New FenceBuilderRootNmspc.PostsDBDataSet1()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.PostThick = New System.Windows.Forms.TextBox()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.ComboBox3 = New System.Windows.Forms.ComboBox()
        Me.PostWidth = New System.Windows.Forms.TextBox()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.GroupBox15 = New System.Windows.Forms.GroupBox()
        Me.ComboBox1 = New System.Windows.Forms.ComboBox()
        Me.TopRaLibBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.TopRailsDataSet = New FenceBuilderRootNmspc.TopRailsDataSet()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.TopRailHeight = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.TopRailThick = New System.Windows.Forms.TextBox()
        Me.TopRailWidth = New System.Windows.Forms.TextBox()
        Me.GroupBox6 = New System.Windows.Forms.GroupBox()
        Me.BotRailWidth = New System.Windows.Forms.TextBox()
        Me.BotRaLibBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.BottomRailsDBDataSet = New FenceBuilderRootNmspc.BottomRailsDBDataSet1()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.BotRailThick = New System.Windows.Forms.TextBox()
        Me.ComboBox2 = New System.Windows.Forms.ComboBox()
        Me.Label32 = New System.Windows.Forms.Label()
        Me.Label33 = New System.Windows.Forms.Label()
        Me.BotRailHeight = New System.Windows.Forms.TextBox()
        Me.GroupBox7 = New System.Windows.Forms.GroupBox()
        Me.PicketComboBox = New System.Windows.Forms.ComboBox()
        Me.PicketLibBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.PicketsDataSet = New FenceBuilderRootNmspc.PicketsDataSet()
        Me.PicketHeight = New System.Windows.Forms.TextBox()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.PicketWidth = New System.Windows.Forms.TextBox()
        Me.PicketThick = New System.Windows.Forms.TextBox()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.DesPicketSpc = New System.Windows.Forms.TextBox()
        Me.DistanceToBottom = New System.Windows.Forms.TextBox()
        Me.DistanceFromTop = New System.Windows.Forms.TextBox()
        Me.InBetweenDistance = New System.Windows.Forms.TextBox()
        Me.RailHeight = New System.Windows.Forms.TextBox()
        Me.GroupBox11 = New System.Windows.Forms.GroupBox()
        Me.InbetweenDistanceDownSelect = New System.Windows.Forms.Button()
        Me.InBetweenDistanceUpSelect = New System.Windows.Forms.Button()
        Me.CheckBox2 = New System.Windows.Forms.CheckBox()
        Me.CheckBox1 = New System.Windows.Forms.CheckBox()
        Me.GroupBox10 = New System.Windows.Forms.GroupBox()
        Me.RailHeightDownSelect = New System.Windows.Forms.Button()
        Me.RailHeightUpSelect = New System.Windows.Forms.Button()
        Me.GroupBox9 = New System.Windows.Forms.GroupBox()
        Me.PicSpaceDownSelect = New System.Windows.Forms.Button()
        Me.PicSpaceUpSelect = New System.Windows.Forms.Button()
        Me.GroupBox20 = New System.Windows.Forms.GroupBox()
        Me.HoleClearanceDownSel = New System.Windows.Forms.Button()
        Me.HoleClearanceUpSel = New System.Windows.Forms.Button()
        Me.GroupBoxPostToStep = New System.Windows.Forms.GroupBox()
        Me.Post2FirstStepDownSel = New System.Windows.Forms.Button()
        Me.StepEdge = New System.Windows.Forms.TextBox()
        Me.Post2FirstStepUpSel = New System.Windows.Forms.Button()
        Me.GroupBoxDeckToPost = New System.Windows.Forms.GroupBox()
        Me.DeckEdge2PostDownSel = New System.Windows.Forms.Button()
        Me.DeckEdge = New System.Windows.Forms.TextBox()
        Me.DeckEdge2PostUpSel = New System.Windows.Forms.Button()
        Me.GroupBox17 = New System.Windows.Forms.GroupBox()
        Me.DTBUpSelect = New System.Windows.Forms.Button()
        Me.DTBDownSelect = New System.Windows.Forms.Button()
        Me.GroupBox16 = New System.Windows.Forms.GroupBox()
        Me.DFTDownSelect = New System.Windows.Forms.Button()
        Me.DFTUpSelect = New System.Windows.Forms.Button()
        Me.StrRun = New System.Windows.Forms.TextBox()
        Me.StrRise = New System.Windows.Forms.TextBox()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.RaLibTableAdapter1 = New FenceBuilderRootNmspc.TopRailsDataSetTableAdapters.RaLibTableAdapter()
        Me.PicketLibTableAdapter = New FenceBuilderRootNmspc.PicketsDataSetTableAdapters.PicketLibTableAdapter()
        Me.PoLibTableAdapter1 = New FenceBuilderRootNmspc.PostsDBDataSet1TableAdapters.PoLibTableAdapter()
        Me.RaLibTableAdapter = New FenceBuilderRootNmspc.BottomRailsDBDataSet1TableAdapters.RaLibTableAdapter()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.RiseIncrement = New System.Windows.Forms.TextBox()
        Me.RunIncrement = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.RailingDB = New System.Windows.Forms.Button()
        Me.HoleClearanceInc = New System.Windows.Forms.TextBox()
        Me.AmtInGroundInc = New System.Windows.Forms.TextBox()
        Me.ExtraEndMat = New System.Windows.Forms.TextBox()
        Me.DeckEdgeIncrement = New System.Windows.Forms.TextBox()
        Me.PicketClear = New System.Windows.Forms.TextBox()
        Me.IBDIncrement = New System.Windows.Forms.TextBox()
        Me.StepEdgeIncrement = New System.Windows.Forms.TextBox()
        Me.DPSIncrement = New System.Windows.Forms.TextBox()
        Me.RailHeightIncrement = New System.Windows.Forms.TextBox()
        Me.DTBIncrement = New System.Windows.Forms.TextBox()
        Me.DFTIncrement = New System.Windows.Forms.TextBox()
        Me.Label35 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.PostDB = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Label42 = New System.Windows.Forms.Label()
        Me.PicketsDB = New System.Windows.Forms.Button()
        Me.Label44 = New System.Windows.Forms.Label()
        Me.label99 = New System.Windows.Forms.Label()
        Me.Label43 = New System.Windows.Forms.Label()
        Me.TabPage3 = New System.Windows.Forms.TabPage()
        Me.GroupBox5 = New System.Windows.Forms.GroupBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.GroupBox4 = New System.Windows.Forms.GroupBox()
        Me.GroupBoxRun = New System.Windows.Forms.GroupBox()
        Me.RunDownSelect = New System.Windows.Forms.Button()
        Me.RunUpSelect = New System.Windows.Forms.Button()
        Me.GroupBoxRise = New System.Windows.Forms.GroupBox()
        Me.RiseDownSelect = New System.Windows.Forms.Button()
        Me.RiseUpSelect = New System.Windows.Forms.Button()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.TabControl2 = New System.Windows.Forms.TabControl()
        Me.BottomRailsDBDataSet1 = New FenceBuilderRootNmspc.BottomRailsDBDataSet()
        Me.Options.SuspendLayout()
        CType(Me.PoLibBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PostsDBDataSet1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox15.SuspendLayout()
        CType(Me.TopRaLibBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TopRailsDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox6.SuspendLayout()
        CType(Me.BotRaLibBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.BottomRailsDBDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox7.SuspendLayout()
        CType(Me.PicketLibBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PicketsDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox11.SuspendLayout()
        Me.GroupBox10.SuspendLayout()
        Me.GroupBox9.SuspendLayout()
        Me.GroupBox20.SuspendLayout()
        Me.GroupBoxPostToStep.SuspendLayout()
        Me.GroupBoxDeckToPost.SuspendLayout()
        Me.GroupBox17.SuspendLayout()
        Me.GroupBox16.SuspendLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage1.SuspendLayout()
        Me.TabPage3.SuspendLayout()
        Me.GroupBox5.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        Me.GroupBoxRun.SuspendLayout()
        Me.GroupBoxRise.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.TabControl2.SuspendLayout()
        CType(Me.BottomRailsDBDataSet1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Options
        '
        Me.Options.Controls.Add(Me.AmtInGroundDownSel)
        Me.Options.Controls.Add(Me.AmtInGroundUpSel)
        Me.Options.Controls.Add(Me.PostBelowGround)
        Me.Options.Location = New System.Drawing.Point(217, 12)
        Me.Options.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.Options.Name = "Options"
        Me.Options.Padding = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.Options.Size = New System.Drawing.Size(107, 43)
        Me.Options.TabIndex = 125
        Me.Options.TabStop = False
        Me.Options.Text = "Amount In Ground"
        '
        'AmtInGroundDownSel
        '
        Me.AmtInGroundDownSel.BackColor = System.Drawing.Color.White
        Me.AmtInGroundDownSel.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.AmtInGroundDownSel.FlatAppearance.BorderSize = 0
        Me.AmtInGroundDownSel.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.AmtInGroundDownSel.Location = New System.Drawing.Point(7, 16)
        Me.AmtInGroundDownSel.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.AmtInGroundDownSel.Name = "AmtInGroundDownSel"
        Me.AmtInGroundDownSel.Size = New System.Drawing.Size(20, 20)
        Me.AmtInGroundDownSel.TabIndex = 148
        Me.AmtInGroundDownSel.Text = "<"
        Me.AmtInGroundDownSel.UseVisualStyleBackColor = False
        '
        'AmtInGroundUpSel
        '
        Me.AmtInGroundUpSel.BackColor = System.Drawing.Color.White
        Me.AmtInGroundUpSel.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.AmtInGroundUpSel.Location = New System.Drawing.Point(29, 16)
        Me.AmtInGroundUpSel.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.AmtInGroundUpSel.Name = "AmtInGroundUpSel"
        Me.AmtInGroundUpSel.Size = New System.Drawing.Size(20, 20)
        Me.AmtInGroundUpSel.TabIndex = 149
        Me.AmtInGroundUpSel.Text = ">"
        Me.AmtInGroundUpSel.UseVisualStyleBackColor = False
        '
        'PostBelowGround
        '
        Me.PostBelowGround.Location = New System.Drawing.Point(53, 16)
        Me.PostBelowGround.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.PostBelowGround.Name = "PostBelowGround"
        Me.PostBelowGround.Size = New System.Drawing.Size(44, 20)
        Me.PostBelowGround.TabIndex = 116
        Me.PostBelowGround.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'PostHoleClearance
        '
        Me.PostHoleClearance.Location = New System.Drawing.Point(54, 16)
        Me.PostHoleClearance.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.PostHoleClearance.Name = "PostHoleClearance"
        Me.PostHoleClearance.Size = New System.Drawing.Size(44, 20)
        Me.PostHoleClearance.TabIndex = 117
        Me.PostHoleClearance.Text = "0"
        Me.PostHoleClearance.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label17
        '
        Me.Label17.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(4, 16)
        Me.Label17.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(74, 13)
        Me.Label17.TabIndex = 119
        Me.Label17.Text = "Horz. Spacing"
        Me.Label17.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'Label2
        '
        Me.Label2.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.Transparent
        Me.Label2.Location = New System.Drawing.Point(73, 33)
        Me.Label2.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(34, 13)
        Me.Label2.TabIndex = 98
        Me.Label2.Tag = "input1"
        Me.Label2.Text = "0.000"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'ActPicketSpc
        '
        Me.ActPicketSpc.AutoSize = True
        Me.ActPicketSpc.BackColor = System.Drawing.Color.Transparent
        Me.ActPicketSpc.Location = New System.Drawing.Point(73, 16)
        Me.ActPicketSpc.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.ActPicketSpc.Name = "ActPicketSpc"
        Me.ActPicketSpc.Size = New System.Drawing.Size(34, 13)
        Me.ActPicketSpc.TabIndex = 97
        Me.ActPicketSpc.Tag = "input1"
        Me.ActPicketSpc.Text = "0.000"
        Me.ActPicketSpc.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'AngleRef
        '
        Me.AngleRef.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom), System.Windows.Forms.AnchorStyles)
        Me.AngleRef.AutoSize = True
        Me.AngleRef.BackColor = System.Drawing.Color.Transparent
        Me.AngleRef.Location = New System.Drawing.Point(74, 15)
        Me.AngleRef.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.AngleRef.Name = "AngleRef"
        Me.AngleRef.Size = New System.Drawing.Size(16, 13)
        Me.AngleRef.TabIndex = 98
        Me.AngleRef.Tag = "input1"
        Me.AngleRef.Text = "-.-"
        Me.AngleRef.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'StairCalc
        '
        Me.StairCalc.Location = New System.Drawing.Point(399, 439)
        Me.StairCalc.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.StairCalc.Name = "StairCalc"
        Me.StairCalc.Size = New System.Drawing.Size(72, 23)
        Me.StairCalc.TabIndex = 74
        Me.StairCalc.Text = "Calculate"
        Me.StairCalc.UseVisualStyleBackColor = True
        '
        'StairReset
        '
        Me.StairReset.Location = New System.Drawing.Point(478, 439)
        Me.StairReset.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.StairReset.Name = "StairReset"
        Me.StairReset.Size = New System.Drawing.Size(74, 23)
        Me.StairReset.TabIndex = 75
        Me.StairReset.Text = "Reset"
        Me.StairReset.UseVisualStyleBackColor = True
        '
        'PostHeight
        '
        Me.PostHeight.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.PoLibBindingSource, "Height", True))
        Me.PostHeight.Location = New System.Drawing.Point(8, 36)
        Me.PostHeight.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.PostHeight.Name = "PostHeight"
        Me.PostHeight.Size = New System.Drawing.Size(44, 20)
        Me.PostHeight.TabIndex = 6
        Me.PostHeight.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'PoLibBindingSource
        '
        Me.PoLibBindingSource.DataMember = "PoLib"
        Me.PoLibBindingSource.DataSource = Me.PostsDBDataSet1
        '
        'PostsDBDataSet1
        '
        Me.PostsDBDataSet1.DataSetName = "PostsDBDataSet1"
        Me.PostsDBDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(54, 59)
        Me.Label14.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(26, 13)
        Me.Label14.TabIndex = 102
        Me.Label14.Text = "WD"
        '
        'PostThick
        '
        Me.PostThick.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.PoLibBindingSource, "Thickness", True))
        Me.PostThick.Location = New System.Drawing.Point(8, 78)
        Me.PostThick.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.PostThick.Name = "PostThick"
        Me.PostThick.Size = New System.Drawing.Size(44, 20)
        Me.PostThick.TabIndex = 8
        Me.PostThick.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(54, 39)
        Me.Label16.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(22, 13)
        Me.Label16.TabIndex = 95
        Me.Label16.Text = "HT"
        '
        'ComboBox3
        '
        Me.ComboBox3.DataSource = Me.PoLibBindingSource
        Me.ComboBox3.DisplayMember = "ID"
        Me.ComboBox3.DropDownWidth = 66
        Me.ComboBox3.FormattingEnabled = True
        Me.ComboBox3.Location = New System.Drawing.Point(7, 14)
        Me.ComboBox3.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.ComboBox3.Name = "ComboBox3"
        Me.ComboBox3.Size = New System.Drawing.Size(77, 21)
        Me.ComboBox3.TabIndex = 5
        '
        'PostWidth
        '
        Me.PostWidth.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.PoLibBindingSource, "Width", True))
        Me.PostWidth.Location = New System.Drawing.Point(8, 57)
        Me.PostWidth.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.PostWidth.Name = "PostWidth"
        Me.PostWidth.Size = New System.Drawing.Size(44, 20)
        Me.PostWidth.TabIndex = 7
        Me.PostWidth.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(54, 79)
        Me.Label15.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(29, 13)
        Me.Label15.TabIndex = 96
        Me.Label15.Text = "THK"
        '
        'GroupBox15
        '
        Me.GroupBox15.Controls.Add(Me.ComboBox1)
        Me.GroupBox15.Controls.Add(Me.Label5)
        Me.GroupBox15.Controls.Add(Me.TopRailHeight)
        Me.GroupBox15.Controls.Add(Me.Label7)
        Me.GroupBox15.Controls.Add(Me.Label11)
        Me.GroupBox15.Controls.Add(Me.TopRailThick)
        Me.GroupBox15.Controls.Add(Me.TopRailWidth)
        Me.GroupBox15.Location = New System.Drawing.Point(12, 128)
        Me.GroupBox15.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.GroupBox15.Name = "GroupBox15"
        Me.GroupBox15.Padding = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.GroupBox15.Size = New System.Drawing.Size(89, 103)
        Me.GroupBox15.TabIndex = 71
        Me.GroupBox15.TabStop = False
        Me.GroupBox15.Text = "Top Rail"
        '
        'ComboBox1
        '
        Me.ComboBox1.DataSource = Me.TopRaLibBindingSource
        Me.ComboBox1.DisplayMember = "ID"
        Me.ComboBox1.FormattingEnabled = True
        Me.ComboBox1.Location = New System.Drawing.Point(5, 14)
        Me.ComboBox1.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.ComboBox1.Name = "ComboBox1"
        Me.ComboBox1.Size = New System.Drawing.Size(77, 21)
        Me.ComboBox1.TabIndex = 13
        '
        'TopRaLibBindingSource
        '
        Me.TopRaLibBindingSource.DataMember = "RaLib"
        Me.TopRaLibBindingSource.DataSource = Me.TopRailsDataSet
        '
        'TopRailsDataSet
        '
        Me.TopRailsDataSet.DataSetName = "TopRailsDataSet"
        Me.TopRailsDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(52, 59)
        Me.Label5.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(26, 13)
        Me.Label5.TabIndex = 107
        Me.Label5.Text = "WD"
        '
        'TopRailHeight
        '
        Me.TopRailHeight.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TopRaLibBindingSource, "Height", True))
        Me.TopRailHeight.Location = New System.Drawing.Point(6, 36)
        Me.TopRailHeight.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.TopRailHeight.Name = "TopRailHeight"
        Me.TopRailHeight.Size = New System.Drawing.Size(44, 20)
        Me.TopRailHeight.TabIndex = 14
        Me.TopRailHeight.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(52, 39)
        Me.Label7.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(22, 13)
        Me.Label7.TabIndex = 104
        Me.Label7.Text = "HT"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(52, 79)
        Me.Label11.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(29, 13)
        Me.Label11.TabIndex = 105
        Me.Label11.Text = "THK"
        '
        'TopRailThick
        '
        Me.TopRailThick.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TopRaLibBindingSource, "Thickness", True))
        Me.TopRailThick.Location = New System.Drawing.Point(6, 78)
        Me.TopRailThick.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.TopRailThick.Name = "TopRailThick"
        Me.TopRailThick.Size = New System.Drawing.Size(44, 20)
        Me.TopRailThick.TabIndex = 16
        Me.TopRailThick.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'TopRailWidth
        '
        Me.TopRailWidth.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TopRaLibBindingSource, "Width", True))
        Me.TopRailWidth.Location = New System.Drawing.Point(6, 57)
        Me.TopRailWidth.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.TopRailWidth.Name = "TopRailWidth"
        Me.TopRailWidth.Size = New System.Drawing.Size(44, 20)
        Me.TopRailWidth.TabIndex = 15
        Me.TopRailWidth.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'GroupBox6
        '
        Me.GroupBox6.BackColor = System.Drawing.Color.Transparent
        Me.GroupBox6.Controls.Add(Me.BotRailWidth)
        Me.GroupBox6.Controls.Add(Me.Label18)
        Me.GroupBox6.Controls.Add(Me.BotRailThick)
        Me.GroupBox6.Controls.Add(Me.ComboBox2)
        Me.GroupBox6.Controls.Add(Me.Label32)
        Me.GroupBox6.Controls.Add(Me.Label33)
        Me.GroupBox6.Controls.Add(Me.BotRailHeight)
        Me.GroupBox6.Location = New System.Drawing.Point(105, 128)
        Me.GroupBox6.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.GroupBox6.Name = "GroupBox6"
        Me.GroupBox6.Padding = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.GroupBox6.Size = New System.Drawing.Size(89, 103)
        Me.GroupBox6.TabIndex = 72
        Me.GroupBox6.TabStop = False
        Me.GroupBox6.Text = "Bottom Rail"
        '
        'BotRailWidth
        '
        Me.BotRailWidth.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.BotRaLibBindingSource, "Width", True))
        Me.BotRailWidth.Location = New System.Drawing.Point(6, 57)
        Me.BotRailWidth.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.BotRailWidth.Name = "BotRailWidth"
        Me.BotRailWidth.Size = New System.Drawing.Size(44, 20)
        Me.BotRailWidth.TabIndex = 20
        Me.BotRailWidth.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'BotRaLibBindingSource
        '
        Me.BotRaLibBindingSource.DataMember = "RaLib"
        Me.BotRaLibBindingSource.DataSource = Me.BottomRailsDBDataSet
        '
        'BottomRailsDBDataSet
        '
        Me.BottomRailsDBDataSet.DataSetName = "BottomRailsDBDataSet"
        Me.BottomRailsDBDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Location = New System.Drawing.Point(52, 59)
        Me.Label18.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(26, 13)
        Me.Label18.TabIndex = 121
        Me.Label18.Text = "WD"
        '
        'BotRailThick
        '
        Me.BotRailThick.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.BotRaLibBindingSource, "Thickness", True))
        Me.BotRailThick.Location = New System.Drawing.Point(6, 78)
        Me.BotRailThick.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.BotRailThick.Name = "BotRailThick"
        Me.BotRailThick.Size = New System.Drawing.Size(44, 20)
        Me.BotRailThick.TabIndex = 21
        Me.BotRailThick.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'ComboBox2
        '
        Me.ComboBox2.DataSource = Me.BotRaLibBindingSource
        Me.ComboBox2.DisplayMember = "ID"
        Me.ComboBox2.FormattingEnabled = True
        Me.ComboBox2.Location = New System.Drawing.Point(5, 14)
        Me.ComboBox2.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.ComboBox2.Name = "ComboBox2"
        Me.ComboBox2.Size = New System.Drawing.Size(77, 21)
        Me.ComboBox2.TabIndex = 18
        '
        'Label32
        '
        Me.Label32.AutoSize = True
        Me.Label32.Location = New System.Drawing.Point(52, 39)
        Me.Label32.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label32.Name = "Label32"
        Me.Label32.Size = New System.Drawing.Size(22, 13)
        Me.Label32.TabIndex = 118
        Me.Label32.Text = "HT"
        '
        'Label33
        '
        Me.Label33.AutoSize = True
        Me.Label33.Location = New System.Drawing.Point(52, 79)
        Me.Label33.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(29, 13)
        Me.Label33.TabIndex = 119
        Me.Label33.Text = "THK"
        '
        'BotRailHeight
        '
        Me.BotRailHeight.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.BotRaLibBindingSource, "Height", True))
        Me.BotRailHeight.Location = New System.Drawing.Point(6, 36)
        Me.BotRailHeight.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.BotRailHeight.Name = "BotRailHeight"
        Me.BotRailHeight.Size = New System.Drawing.Size(44, 20)
        Me.BotRailHeight.TabIndex = 19
        Me.BotRailHeight.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'GroupBox7
        '
        Me.GroupBox7.Controls.Add(Me.PicketComboBox)
        Me.GroupBox7.Controls.Add(Me.PicketHeight)
        Me.GroupBox7.Controls.Add(Me.Label22)
        Me.GroupBox7.Controls.Add(Me.Label21)
        Me.GroupBox7.Controls.Add(Me.PicketWidth)
        Me.GroupBox7.Controls.Add(Me.PicketThick)
        Me.GroupBox7.Controls.Add(Me.Label20)
        Me.GroupBox7.Location = New System.Drawing.Point(329, 12)
        Me.GroupBox7.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.GroupBox7.Name = "GroupBox7"
        Me.GroupBox7.Padding = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.GroupBox7.Size = New System.Drawing.Size(89, 103)
        Me.GroupBox7.TabIndex = 70
        Me.GroupBox7.TabStop = False
        Me.GroupBox7.Text = "Picket Type"
        '
        'PicketComboBox
        '
        Me.PicketComboBox.DataSource = Me.PicketLibBindingSource
        Me.PicketComboBox.DisplayMember = "ID"
        Me.PicketComboBox.DropDownWidth = 66
        Me.PicketComboBox.FormattingEnabled = True
        Me.PicketComboBox.Location = New System.Drawing.Point(5, 14)
        Me.PicketComboBox.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.PicketComboBox.Name = "PicketComboBox"
        Me.PicketComboBox.Size = New System.Drawing.Size(77, 21)
        Me.PicketComboBox.TabIndex = 104
        '
        'PicketLibBindingSource
        '
        Me.PicketLibBindingSource.DataMember = "PicketLib"
        Me.PicketLibBindingSource.DataSource = Me.PicketsDataSet
        '
        'PicketsDataSet
        '
        Me.PicketsDataSet.DataSetName = "PicketsDataSet"
        Me.PicketsDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'PicketHeight
        '
        Me.PicketHeight.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.PicketLibBindingSource, "Height", True))
        Me.PicketHeight.Location = New System.Drawing.Point(6, 36)
        Me.PicketHeight.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.PicketHeight.Name = "PicketHeight"
        Me.PicketHeight.Size = New System.Drawing.Size(44, 20)
        Me.PicketHeight.TabIndex = 123
        Me.PicketHeight.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Location = New System.Drawing.Point(52, 79)
        Me.Label22.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(29, 13)
        Me.Label22.TabIndex = 127
        Me.Label22.Text = "THK"
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Location = New System.Drawing.Point(52, 39)
        Me.Label21.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(22, 13)
        Me.Label21.TabIndex = 126
        Me.Label21.Text = "HT"
        '
        'PicketWidth
        '
        Me.PicketWidth.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.PicketLibBindingSource, "Width", True))
        Me.PicketWidth.Location = New System.Drawing.Point(6, 57)
        Me.PicketWidth.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.PicketWidth.Name = "PicketWidth"
        Me.PicketWidth.Size = New System.Drawing.Size(44, 20)
        Me.PicketWidth.TabIndex = 124
        Me.PicketWidth.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'PicketThick
        '
        Me.PicketThick.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.PicketLibBindingSource, "Thickness", True))
        Me.PicketThick.Location = New System.Drawing.Point(6, 78)
        Me.PicketThick.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.PicketThick.Name = "PicketThick"
        Me.PicketThick.Size = New System.Drawing.Size(44, 20)
        Me.PicketThick.TabIndex = 125
        Me.PicketThick.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Location = New System.Drawing.Point(52, 59)
        Me.Label20.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(26, 13)
        Me.Label20.TabIndex = 128
        Me.Label20.Text = "WD"
        '
        'DesPicketSpc
        '
        Me.DesPicketSpc.Location = New System.Drawing.Point(53, 16)
        Me.DesPicketSpc.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.DesPicketSpc.Name = "DesPicketSpc"
        Me.DesPicketSpc.Size = New System.Drawing.Size(44, 20)
        Me.DesPicketSpc.TabIndex = 11
        Me.DesPicketSpc.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'DistanceToBottom
        '
        Me.DistanceToBottom.Location = New System.Drawing.Point(53, 16)
        Me.DistanceToBottom.Name = "DistanceToBottom"
        Me.DistanceToBottom.Size = New System.Drawing.Size(44, 20)
        Me.DistanceToBottom.TabIndex = 138
        '
        'DistanceFromTop
        '
        Me.DistanceFromTop.Location = New System.Drawing.Point(53, 16)
        Me.DistanceFromTop.Name = "DistanceFromTop"
        Me.DistanceFromTop.Size = New System.Drawing.Size(44, 20)
        Me.DistanceFromTop.TabIndex = 135
        '
        'InBetweenDistance
        '
        Me.InBetweenDistance.Location = New System.Drawing.Point(53, 16)
        Me.InBetweenDistance.Name = "InBetweenDistance"
        Me.InBetweenDistance.Size = New System.Drawing.Size(44, 20)
        Me.InBetweenDistance.TabIndex = 132
        '
        'RailHeight
        '
        Me.RailHeight.Location = New System.Drawing.Point(53, 16)
        Me.RailHeight.Name = "RailHeight"
        Me.RailHeight.Size = New System.Drawing.Size(44, 20)
        Me.RailHeight.TabIndex = 129
        '
        'GroupBox11
        '
        Me.GroupBox11.Controls.Add(Me.InbetweenDistanceDownSelect)
        Me.GroupBox11.Controls.Add(Me.InBetweenDistanceUpSelect)
        Me.GroupBox11.Controls.Add(Me.InBetweenDistance)
        Me.GroupBox11.Location = New System.Drawing.Point(199, 188)
        Me.GroupBox11.Name = "GroupBox11"
        Me.GroupBox11.Size = New System.Drawing.Size(107, 43)
        Me.GroupBox11.TabIndex = 137
        Me.GroupBox11.TabStop = False
        Me.GroupBox11.Text = "Section Length"
        '
        'InbetweenDistanceDownSelect
        '
        Me.InbetweenDistanceDownSelect.BackColor = System.Drawing.Color.White
        Me.InbetweenDistanceDownSelect.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.InbetweenDistanceDownSelect.FlatAppearance.BorderSize = 0
        Me.InbetweenDistanceDownSelect.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.InbetweenDistanceDownSelect.Location = New System.Drawing.Point(7, 16)
        Me.InbetweenDistanceDownSelect.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.InbetweenDistanceDownSelect.Name = "InbetweenDistanceDownSelect"
        Me.InbetweenDistanceDownSelect.Size = New System.Drawing.Size(20, 20)
        Me.InbetweenDistanceDownSelect.TabIndex = 131
        Me.InbetweenDistanceDownSelect.Text = "<"
        Me.InbetweenDistanceDownSelect.UseVisualStyleBackColor = False
        '
        'InBetweenDistanceUpSelect
        '
        Me.InBetweenDistanceUpSelect.BackColor = System.Drawing.Color.White
        Me.InBetweenDistanceUpSelect.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.InBetweenDistanceUpSelect.Location = New System.Drawing.Point(29, 16)
        Me.InBetweenDistanceUpSelect.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.InBetweenDistanceUpSelect.Name = "InBetweenDistanceUpSelect"
        Me.InBetweenDistanceUpSelect.Size = New System.Drawing.Size(20, 20)
        Me.InBetweenDistanceUpSelect.TabIndex = 130
        Me.InBetweenDistanceUpSelect.Text = ">"
        Me.InBetweenDistanceUpSelect.UseVisualStyleBackColor = False
        '
        'CheckBox2
        '
        Me.CheckBox2.AutoSize = True
        Me.CheckBox2.Location = New System.Drawing.Point(14, 35)
        Me.CheckBox2.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.CheckBox2.Name = "CheckBox2"
        Me.CheckBox2.Size = New System.Drawing.Size(61, 17)
        Me.CheckBox2.TabIndex = 135
        Me.CheckBox2.Text = "Aligned"
        Me.CheckBox2.UseVisualStyleBackColor = True
        '
        'CheckBox1
        '
        Me.CheckBox1.AutoSize = True
        Me.CheckBox1.Location = New System.Drawing.Point(14, 14)
        Me.CheckBox1.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.CheckBox1.Name = "CheckBox1"
        Me.CheckBox1.Size = New System.Drawing.Size(53, 17)
        Me.CheckBox1.TabIndex = 142
        Me.CheckBox1.Text = "Slope"
        Me.CheckBox1.UseVisualStyleBackColor = True
        '
        'GroupBox10
        '
        Me.GroupBox10.Controls.Add(Me.RailHeightDownSelect)
        Me.GroupBox10.Controls.Add(Me.RailHeight)
        Me.GroupBox10.Controls.Add(Me.RailHeightUpSelect)
        Me.GroupBox10.Location = New System.Drawing.Point(199, 128)
        Me.GroupBox10.Name = "GroupBox10"
        Me.GroupBox10.Size = New System.Drawing.Size(107, 43)
        Me.GroupBox10.TabIndex = 136
        Me.GroupBox10.TabStop = False
        Me.GroupBox10.Text = "Railing Height"
        '
        'RailHeightDownSelect
        '
        Me.RailHeightDownSelect.BackColor = System.Drawing.Color.White
        Me.RailHeightDownSelect.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.RailHeightDownSelect.Cursor = System.Windows.Forms.Cursors.Default
        Me.RailHeightDownSelect.FlatAppearance.BorderSize = 0
        Me.RailHeightDownSelect.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RailHeightDownSelect.Location = New System.Drawing.Point(7, 16)
        Me.RailHeightDownSelect.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.RailHeightDownSelect.Name = "RailHeightDownSelect"
        Me.RailHeightDownSelect.Size = New System.Drawing.Size(20, 20)
        Me.RailHeightDownSelect.TabIndex = 128
        Me.RailHeightDownSelect.Text = "<"
        Me.RailHeightDownSelect.UseVisualStyleBackColor = False
        '
        'RailHeightUpSelect
        '
        Me.RailHeightUpSelect.BackColor = System.Drawing.Color.White
        Me.RailHeightUpSelect.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.RailHeightUpSelect.Cursor = System.Windows.Forms.Cursors.Default
        Me.RailHeightUpSelect.FlatAppearance.BorderSize = 0
        Me.RailHeightUpSelect.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RailHeightUpSelect.Location = New System.Drawing.Point(29, 16)
        Me.RailHeightUpSelect.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.RailHeightUpSelect.Name = "RailHeightUpSelect"
        Me.RailHeightUpSelect.Size = New System.Drawing.Size(20, 20)
        Me.RailHeightUpSelect.TabIndex = 134
        Me.RailHeightUpSelect.Text = ">"
        Me.RailHeightUpSelect.UseVisualStyleBackColor = False
        '
        'GroupBox9
        '
        Me.GroupBox9.Controls.Add(Me.PicSpaceDownSelect)
        Me.GroupBox9.Controls.Add(Me.PicSpaceUpSelect)
        Me.GroupBox9.Controls.Add(Me.DesPicketSpc)
        Me.GroupBox9.Location = New System.Drawing.Point(423, 12)
        Me.GroupBox9.Name = "GroupBox9"
        Me.GroupBox9.Size = New System.Drawing.Size(107, 43)
        Me.GroupBox9.TabIndex = 137
        Me.GroupBox9.TabStop = False
        Me.GroupBox9.Text = "Picket Spacing"
        '
        'PicSpaceDownSelect
        '
        Me.PicSpaceDownSelect.BackColor = System.Drawing.Color.White
        Me.PicSpaceDownSelect.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.PicSpaceDownSelect.Cursor = System.Windows.Forms.Cursors.Default
        Me.PicSpaceDownSelect.FlatAppearance.BorderSize = 0
        Me.PicSpaceDownSelect.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.PicSpaceDownSelect.Location = New System.Drawing.Point(7, 16)
        Me.PicSpaceDownSelect.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.PicSpaceDownSelect.Name = "PicSpaceDownSelect"
        Me.PicSpaceDownSelect.Size = New System.Drawing.Size(20, 20)
        Me.PicSpaceDownSelect.TabIndex = 135
        Me.PicSpaceDownSelect.Text = "<"
        Me.PicSpaceDownSelect.UseVisualStyleBackColor = False
        '
        'PicSpaceUpSelect
        '
        Me.PicSpaceUpSelect.BackColor = System.Drawing.Color.White
        Me.PicSpaceUpSelect.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.PicSpaceUpSelect.Cursor = System.Windows.Forms.Cursors.Default
        Me.PicSpaceUpSelect.FlatAppearance.BorderSize = 0
        Me.PicSpaceUpSelect.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.PicSpaceUpSelect.Location = New System.Drawing.Point(29, 16)
        Me.PicSpaceUpSelect.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.PicSpaceUpSelect.Name = "PicSpaceUpSelect"
        Me.PicSpaceUpSelect.Size = New System.Drawing.Size(20, 20)
        Me.PicSpaceUpSelect.TabIndex = 136
        Me.PicSpaceUpSelect.Text = ">"
        Me.PicSpaceUpSelect.UseVisualStyleBackColor = False
        '
        'GroupBox20
        '
        Me.GroupBox20.Controls.Add(Me.HoleClearanceDownSel)
        Me.GroupBox20.Controls.Add(Me.HoleClearanceUpSel)
        Me.GroupBox20.Controls.Add(Me.PostHoleClearance)
        Me.GroupBox20.Location = New System.Drawing.Point(375, 134)
        Me.GroupBox20.Name = "GroupBox20"
        Me.GroupBox20.Size = New System.Drawing.Size(107, 43)
        Me.GroupBox20.TabIndex = 122
        Me.GroupBox20.TabStop = False
        Me.GroupBox20.Text = "Hole Clearance"
        '
        'HoleClearanceDownSel
        '
        Me.HoleClearanceDownSel.BackColor = System.Drawing.Color.White
        Me.HoleClearanceDownSel.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.HoleClearanceDownSel.FlatAppearance.BorderSize = 0
        Me.HoleClearanceDownSel.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.HoleClearanceDownSel.Location = New System.Drawing.Point(7, 16)
        Me.HoleClearanceDownSel.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.HoleClearanceDownSel.Name = "HoleClearanceDownSel"
        Me.HoleClearanceDownSel.Size = New System.Drawing.Size(20, 20)
        Me.HoleClearanceDownSel.TabIndex = 148
        Me.HoleClearanceDownSel.Text = "<"
        Me.HoleClearanceDownSel.UseVisualStyleBackColor = False
        '
        'HoleClearanceUpSel
        '
        Me.HoleClearanceUpSel.BackColor = System.Drawing.Color.White
        Me.HoleClearanceUpSel.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.HoleClearanceUpSel.Location = New System.Drawing.Point(29, 16)
        Me.HoleClearanceUpSel.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.HoleClearanceUpSel.Name = "HoleClearanceUpSel"
        Me.HoleClearanceUpSel.Size = New System.Drawing.Size(20, 20)
        Me.HoleClearanceUpSel.TabIndex = 149
        Me.HoleClearanceUpSel.Text = ">"
        Me.HoleClearanceUpSel.UseVisualStyleBackColor = False
        '
        'GroupBoxPostToStep
        '
        Me.GroupBoxPostToStep.Controls.Add(Me.Post2FirstStepDownSel)
        Me.GroupBoxPostToStep.Controls.Add(Me.StepEdge)
        Me.GroupBoxPostToStep.Controls.Add(Me.Post2FirstStepUpSel)
        Me.GroupBoxPostToStep.Location = New System.Drawing.Point(424, 128)
        Me.GroupBoxPostToStep.Name = "GroupBoxPostToStep"
        Me.GroupBoxPostToStep.Size = New System.Drawing.Size(107, 43)
        Me.GroupBoxPostToStep.TabIndex = 149
        Me.GroupBoxPostToStep.TabStop = False
        Me.GroupBoxPostToStep.Text = "Post To Step"
        '
        'Post2FirstStepDownSel
        '
        Me.Post2FirstStepDownSel.BackColor = System.Drawing.Color.White
        Me.Post2FirstStepDownSel.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.Post2FirstStepDownSel.FlatAppearance.BorderSize = 0
        Me.Post2FirstStepDownSel.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Post2FirstStepDownSel.Location = New System.Drawing.Point(7, 16)
        Me.Post2FirstStepDownSel.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.Post2FirstStepDownSel.Name = "Post2FirstStepDownSel"
        Me.Post2FirstStepDownSel.Size = New System.Drawing.Size(20, 20)
        Me.Post2FirstStepDownSel.TabIndex = 141
        Me.Post2FirstStepDownSel.Text = "<"
        Me.Post2FirstStepDownSel.UseVisualStyleBackColor = False
        '
        'StepEdge
        '
        Me.StepEdge.Location = New System.Drawing.Point(53, 16)
        Me.StepEdge.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.StepEdge.Name = "StepEdge"
        Me.StepEdge.Size = New System.Drawing.Size(44, 20)
        Me.StepEdge.TabIndex = 143
        Me.StepEdge.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Post2FirstStepUpSel
        '
        Me.Post2FirstStepUpSel.BackColor = System.Drawing.Color.White
        Me.Post2FirstStepUpSel.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Post2FirstStepUpSel.Location = New System.Drawing.Point(29, 16)
        Me.Post2FirstStepUpSel.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.Post2FirstStepUpSel.Name = "Post2FirstStepUpSel"
        Me.Post2FirstStepUpSel.Size = New System.Drawing.Size(20, 20)
        Me.Post2FirstStepUpSel.TabIndex = 142
        Me.Post2FirstStepUpSel.Text = ">"
        Me.Post2FirstStepUpSel.UseVisualStyleBackColor = False
        '
        'GroupBoxDeckToPost
        '
        Me.GroupBoxDeckToPost.Controls.Add(Me.DeckEdge2PostDownSel)
        Me.GroupBoxDeckToPost.Controls.Add(Me.DeckEdge)
        Me.GroupBoxDeckToPost.Controls.Add(Me.DeckEdge2PostUpSel)
        Me.GroupBoxDeckToPost.Location = New System.Drawing.Point(424, 188)
        Me.GroupBoxDeckToPost.Name = "GroupBoxDeckToPost"
        Me.GroupBoxDeckToPost.Size = New System.Drawing.Size(107, 43)
        Me.GroupBoxDeckToPost.TabIndex = 148
        Me.GroupBoxDeckToPost.TabStop = False
        Me.GroupBoxDeckToPost.Text = "Deck To Post"
        '
        'DeckEdge2PostDownSel
        '
        Me.DeckEdge2PostDownSel.BackColor = System.Drawing.Color.White
        Me.DeckEdge2PostDownSel.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.DeckEdge2PostDownSel.FlatAppearance.BorderSize = 0
        Me.DeckEdge2PostDownSel.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DeckEdge2PostDownSel.Location = New System.Drawing.Point(7, 16)
        Me.DeckEdge2PostDownSel.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.DeckEdge2PostDownSel.Name = "DeckEdge2PostDownSel"
        Me.DeckEdge2PostDownSel.Size = New System.Drawing.Size(20, 20)
        Me.DeckEdge2PostDownSel.TabIndex = 146
        Me.DeckEdge2PostDownSel.Text = "<"
        Me.DeckEdge2PostDownSel.UseVisualStyleBackColor = False
        '
        'DeckEdge
        '
        Me.DeckEdge.Location = New System.Drawing.Point(53, 16)
        Me.DeckEdge.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.DeckEdge.Name = "DeckEdge"
        Me.DeckEdge.Size = New System.Drawing.Size(44, 20)
        Me.DeckEdge.TabIndex = 142
        Me.DeckEdge.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'DeckEdge2PostUpSel
        '
        Me.DeckEdge2PostUpSel.BackColor = System.Drawing.Color.White
        Me.DeckEdge2PostUpSel.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DeckEdge2PostUpSel.Location = New System.Drawing.Point(29, 16)
        Me.DeckEdge2PostUpSel.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.DeckEdge2PostUpSel.Name = "DeckEdge2PostUpSel"
        Me.DeckEdge2PostUpSel.Size = New System.Drawing.Size(20, 20)
        Me.DeckEdge2PostUpSel.TabIndex = 147
        Me.DeckEdge2PostUpSel.Text = ">"
        Me.DeckEdge2PostUpSel.UseVisualStyleBackColor = False
        '
        'GroupBox17
        '
        Me.GroupBox17.Controls.Add(Me.DistanceToBottom)
        Me.GroupBox17.Controls.Add(Me.DTBUpSelect)
        Me.GroupBox17.Controls.Add(Me.DTBDownSelect)
        Me.GroupBox17.Location = New System.Drawing.Point(105, 72)
        Me.GroupBox17.Name = "GroupBox17"
        Me.GroupBox17.Size = New System.Drawing.Size(107, 43)
        Me.GroupBox17.TabIndex = 122
        Me.GroupBox17.TabStop = False
        Me.GroupBox17.Text = "Dist To Bottom"
        '
        'DTBUpSelect
        '
        Me.DTBUpSelect.BackColor = System.Drawing.Color.White
        Me.DTBUpSelect.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DTBUpSelect.Location = New System.Drawing.Point(29, 16)
        Me.DTBUpSelect.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.DTBUpSelect.Name = "DTBUpSelect"
        Me.DTBUpSelect.Size = New System.Drawing.Size(20, 20)
        Me.DTBUpSelect.TabIndex = 136
        Me.DTBUpSelect.Text = ">"
        Me.DTBUpSelect.UseVisualStyleBackColor = False
        '
        'DTBDownSelect
        '
        Me.DTBDownSelect.BackColor = System.Drawing.Color.White
        Me.DTBDownSelect.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.DTBDownSelect.FlatAppearance.BorderSize = 0
        Me.DTBDownSelect.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DTBDownSelect.Location = New System.Drawing.Point(7, 16)
        Me.DTBDownSelect.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.DTBDownSelect.Name = "DTBDownSelect"
        Me.DTBDownSelect.Size = New System.Drawing.Size(20, 20)
        Me.DTBDownSelect.TabIndex = 137
        Me.DTBDownSelect.Text = "<"
        Me.DTBDownSelect.UseVisualStyleBackColor = False
        '
        'GroupBox16
        '
        Me.GroupBox16.Controls.Add(Me.DFTDownSelect)
        Me.GroupBox16.Controls.Add(Me.DistanceFromTop)
        Me.GroupBox16.Controls.Add(Me.DFTUpSelect)
        Me.GroupBox16.Location = New System.Drawing.Point(105, 12)
        Me.GroupBox16.Name = "GroupBox16"
        Me.GroupBox16.Size = New System.Drawing.Size(107, 43)
        Me.GroupBox16.TabIndex = 145
        Me.GroupBox16.TabStop = False
        Me.GroupBox16.Text = "Dist From Top"
        '
        'DFTDownSelect
        '
        Me.DFTDownSelect.BackColor = System.Drawing.Color.White
        Me.DFTDownSelect.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.DFTDownSelect.FlatAppearance.BorderSize = 0
        Me.DFTDownSelect.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DFTDownSelect.Location = New System.Drawing.Point(7, 16)
        Me.DFTDownSelect.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.DFTDownSelect.Name = "DFTDownSelect"
        Me.DFTDownSelect.Size = New System.Drawing.Size(20, 20)
        Me.DFTDownSelect.TabIndex = 134
        Me.DFTDownSelect.Text = "<"
        Me.DFTDownSelect.UseVisualStyleBackColor = False
        '
        'DFTUpSelect
        '
        Me.DFTUpSelect.BackColor = System.Drawing.Color.White
        Me.DFTUpSelect.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DFTUpSelect.Location = New System.Drawing.Point(29, 16)
        Me.DFTUpSelect.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.DFTUpSelect.Name = "DFTUpSelect"
        Me.DFTUpSelect.Size = New System.Drawing.Size(20, 20)
        Me.DFTUpSelect.TabIndex = 140
        Me.DFTUpSelect.Text = ">"
        Me.DFTUpSelect.UseVisualStyleBackColor = False
        '
        'StrRun
        '
        Me.StrRun.Location = New System.Drawing.Point(53, 16)
        Me.StrRun.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.StrRun.Name = "StrRun"
        Me.StrRun.Size = New System.Drawing.Size(44, 20)
        Me.StrRun.TabIndex = 141
        Me.StrRun.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'StrRise
        '
        Me.StrRise.Location = New System.Drawing.Point(53, 16)
        Me.StrRise.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.StrRise.Name = "StrRise"
        Me.StrRise.Size = New System.Drawing.Size(44, 20)
        Me.StrRise.TabIndex = 140
        Me.StrRise.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'DataGridView1
        '
        Me.DataGridView1.AllowUserToAddRows = False
        Me.DataGridView1.AllowUserToDeleteRows = False
        Me.DataGridView1.AllowUserToResizeColumns = False
        Me.DataGridView1.AllowUserToResizeRows = False
        Me.DataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells
        Me.DataGridView1.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells
        Me.DataGridView1.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.Raised
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing
        Me.DataGridView1.ColumnHeadersVisible = False
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        DataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle1.Format = "N3"
        DataGridViewCellStyle1.NullValue = "N/A"
        DataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.DataGridView1.DefaultCellStyle = DataGridViewCellStyle1
        Me.DataGridView1.Location = New System.Drawing.Point(10, 278)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.RowHeadersVisible = False
        Me.DataGridView1.Size = New System.Drawing.Size(547, 150)
        Me.DataGridView1.TabIndex = 0
        '
        'RaLibTableAdapter1
        '
        Me.RaLibTableAdapter1.ClearBeforeFill = True
        '
        'PicketLibTableAdapter
        '
        Me.PicketLibTableAdapter.ClearBeforeFill = True
        '
        'PoLibTableAdapter1
        '
        Me.PoLibTableAdapter1.ClearBeforeFill = True
        '
        'RaLibTableAdapter
        '
        Me.RaLibTableAdapter.ClearBeforeFill = True
        '
        'TabPage1
        '
        Me.TabPage1.Controls.Add(Me.Label4)
        Me.TabPage1.Controls.Add(Me.RiseIncrement)
        Me.TabPage1.Controls.Add(Me.RunIncrement)
        Me.TabPage1.Controls.Add(Me.Label8)
        Me.TabPage1.Controls.Add(Me.Label24)
        Me.TabPage1.Controls.Add(Me.RailingDB)
        Me.TabPage1.Controls.Add(Me.HoleClearanceInc)
        Me.TabPage1.Controls.Add(Me.AmtInGroundInc)
        Me.TabPage1.Controls.Add(Me.ExtraEndMat)
        Me.TabPage1.Controls.Add(Me.GroupBox20)
        Me.TabPage1.Controls.Add(Me.DeckEdgeIncrement)
        Me.TabPage1.Controls.Add(Me.PicketClear)
        Me.TabPage1.Controls.Add(Me.IBDIncrement)
        Me.TabPage1.Controls.Add(Me.StepEdgeIncrement)
        Me.TabPage1.Controls.Add(Me.DPSIncrement)
        Me.TabPage1.Controls.Add(Me.RailHeightIncrement)
        Me.TabPage1.Controls.Add(Me.DTBIncrement)
        Me.TabPage1.Controls.Add(Me.DFTIncrement)
        Me.TabPage1.Controls.Add(Me.Label35)
        Me.TabPage1.Controls.Add(Me.Label13)
        Me.TabPage1.Controls.Add(Me.Label6)
        Me.TabPage1.Controls.Add(Me.Label12)
        Me.TabPage1.Controls.Add(Me.PostDB)
        Me.TabPage1.Controls.Add(Me.Label1)
        Me.TabPage1.Controls.Add(Me.Label19)
        Me.TabPage1.Controls.Add(Me.Label42)
        Me.TabPage1.Controls.Add(Me.PicketsDB)
        Me.TabPage1.Controls.Add(Me.Label44)
        Me.TabPage1.Controls.Add(Me.label99)
        Me.TabPage1.Controls.Add(Me.Label43)
        Me.TabPage1.Location = New System.Drawing.Point(4, 22)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Size = New System.Drawing.Size(539, 239)
        Me.TabPage1.TabIndex = 4
        Me.TabPage1.Text = "Settings"
        Me.TabPage1.UseVisualStyleBackColor = True
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(226, 103)
        Me.Label4.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(49, 13)
        Me.Label4.TabIndex = 144
        Me.Label4.Text = "Rise Inc."
        '
        'RiseIncrement
        '
        Me.RiseIncrement.Location = New System.Drawing.Point(188, 99)
        Me.RiseIncrement.Name = "RiseIncrement"
        Me.RiseIncrement.Size = New System.Drawing.Size(35, 20)
        Me.RiseIncrement.TabIndex = 143
        Me.RiseIncrement.Text = ".5"
        Me.RiseIncrement.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'RunIncrement
        '
        Me.RunIncrement.Location = New System.Drawing.Point(188, 120)
        Me.RunIncrement.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.RunIncrement.Name = "RunIncrement"
        Me.RunIncrement.Size = New System.Drawing.Size(35, 20)
        Me.RunIncrement.TabIndex = 141
        Me.RunIncrement.Text = ".5"
        Me.RunIncrement.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(226, 124)
        Me.Label8.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(48, 13)
        Me.Label8.TabIndex = 142
        Me.Label8.Text = "Run Inc."
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.Location = New System.Drawing.Point(348, 34)
        Me.Label24.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(125, 13)
        Me.Label24.TabIndex = 140
        Me.Label24.Text = "Post Hole Clearance Inc."
        '
        'RailingDB
        '
        Me.RailingDB.Location = New System.Drawing.Point(5, 7)
        Me.RailingDB.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.RailingDB.Name = "RailingDB"
        Me.RailingDB.Size = New System.Drawing.Size(58, 23)
        Me.RailingDB.TabIndex = 0
        Me.RailingDB.Text = "Railings"
        Me.RailingDB.UseVisualStyleBackColor = True
        '
        'HoleClearanceInc
        '
        Me.HoleClearanceInc.Location = New System.Drawing.Point(310, 30)
        Me.HoleClearanceInc.Name = "HoleClearanceInc"
        Me.HoleClearanceInc.Size = New System.Drawing.Size(35, 20)
        Me.HoleClearanceInc.TabIndex = 139
        Me.HoleClearanceInc.Text = ".75"
        Me.HoleClearanceInc.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'AmtInGroundInc
        '
        Me.AmtInGroundInc.Location = New System.Drawing.Point(189, 72)
        Me.AmtInGroundInc.Name = "AmtInGroundInc"
        Me.AmtInGroundInc.Size = New System.Drawing.Size(35, 20)
        Me.AmtInGroundInc.TabIndex = 137
        Me.AmtInGroundInc.Text = ".75"
        Me.AmtInGroundInc.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'ExtraEndMat
        '
        Me.ExtraEndMat.Location = New System.Drawing.Point(310, 9)
        Me.ExtraEndMat.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.ExtraEndMat.Name = "ExtraEndMat"
        Me.ExtraEndMat.Size = New System.Drawing.Size(35, 20)
        Me.ExtraEndMat.TabIndex = 17
        Me.ExtraEndMat.Text = "1"
        Me.ExtraEndMat.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'DeckEdgeIncrement
        '
        Me.DeckEdgeIncrement.Location = New System.Drawing.Point(68, 51)
        Me.DeckEdgeIncrement.Name = "DeckEdgeIncrement"
        Me.DeckEdgeIncrement.Size = New System.Drawing.Size(35, 20)
        Me.DeckEdgeIncrement.TabIndex = 135
        Me.DeckEdgeIncrement.Text = ".01"
        Me.DeckEdgeIncrement.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'PicketClear
        '
        Me.PicketClear.Location = New System.Drawing.Point(310, 51)
        Me.PicketClear.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.PicketClear.Name = "PicketClear"
        Me.PicketClear.Size = New System.Drawing.Size(35, 20)
        Me.PicketClear.TabIndex = 12
        Me.PicketClear.Text = ".625"
        Me.PicketClear.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'IBDIncrement
        '
        Me.IBDIncrement.Location = New System.Drawing.Point(189, 9)
        Me.IBDIncrement.Name = "IBDIncrement"
        Me.IBDIncrement.Size = New System.Drawing.Size(35, 20)
        Me.IBDIncrement.TabIndex = 122
        Me.IBDIncrement.Text = ".125"
        Me.IBDIncrement.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'StepEdgeIncrement
        '
        Me.StepEdgeIncrement.Location = New System.Drawing.Point(68, 30)
        Me.StepEdgeIncrement.Name = "StepEdgeIncrement"
        Me.StepEdgeIncrement.Size = New System.Drawing.Size(35, 20)
        Me.StepEdgeIncrement.TabIndex = 133
        Me.StepEdgeIncrement.Text = ".01"
        Me.StepEdgeIncrement.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'DPSIncrement
        '
        Me.DPSIncrement.Location = New System.Drawing.Point(68, 9)
        Me.DPSIncrement.Name = "DPSIncrement"
        Me.DPSIncrement.Size = New System.Drawing.Size(35, 20)
        Me.DPSIncrement.TabIndex = 131
        Me.DPSIncrement.Text = ".01"
        Me.DPSIncrement.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'RailHeightIncrement
        '
        Me.RailHeightIncrement.Location = New System.Drawing.Point(189, 30)
        Me.RailHeightIncrement.Name = "RailHeightIncrement"
        Me.RailHeightIncrement.Size = New System.Drawing.Size(35, 20)
        Me.RailHeightIncrement.TabIndex = 125
        Me.RailHeightIncrement.Text = "1"
        Me.RailHeightIncrement.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'DTBIncrement
        '
        Me.DTBIncrement.Location = New System.Drawing.Point(189, 51)
        Me.DTBIncrement.Name = "DTBIncrement"
        Me.DTBIncrement.Size = New System.Drawing.Size(35, 20)
        Me.DTBIncrement.TabIndex = 129
        Me.DTBIncrement.Text = ".75"
        Me.DTBIncrement.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'DFTIncrement
        '
        Me.DFTIncrement.Location = New System.Drawing.Point(68, 72)
        Me.DFTIncrement.Name = "DFTIncrement"
        Me.DFTIncrement.Size = New System.Drawing.Size(35, 20)
        Me.DFTIncrement.TabIndex = 127
        Me.DFTIncrement.Text = ".5"
        Me.DFTIncrement.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label35
        '
        Me.Label35.AutoSize = True
        Me.Label35.Location = New System.Drawing.Point(348, 55)
        Me.Label35.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label35.Name = "Label35"
        Me.Label35.Size = New System.Drawing.Size(88, 13)
        Me.Label35.TabIndex = 55
        Me.Label35.Text = "Picket Clearance"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(226, 76)
        Me.Label13.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(80, 13)
        Me.Label13.TabIndex = 138
        Me.Label13.Text = "Amt in Gnd Inc,"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(348, 13)
        Me.Label6.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(93, 13)
        Me.Label6.TabIndex = 106
        Me.Label6.Text = "Extra End Material"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(105, 54)
        Me.Label12.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(79, 13)
        Me.Label12.TabIndex = 136
        Me.Label12.Text = "DeckEdge Inc."
        '
        'PostDB
        '
        Me.PostDB.Location = New System.Drawing.Point(5, 35)
        Me.PostDB.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.PostDB.Name = "PostDB"
        Me.PostDB.Size = New System.Drawing.Size(58, 23)
        Me.PostDB.TabIndex = 1
        Me.PostDB.Text = "Posts"
        Me.PostDB.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(105, 33)
        Me.Label1.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(78, 13)
        Me.Label1.TabIndex = 134
        Me.Label1.Text = "Step Edge Inc."
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Location = New System.Drawing.Point(226, 13)
        Me.Label19.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(46, 13)
        Me.Label19.TabIndex = 123
        Me.Label19.Text = "IBD Inc."
        '
        'Label42
        '
        Me.Label42.AutoSize = True
        Me.Label42.Location = New System.Drawing.Point(105, 12)
        Me.Label42.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label42.Name = "Label42"
        Me.Label42.Size = New System.Drawing.Size(50, 13)
        Me.Label42.TabIndex = 132
        Me.Label42.Text = "DPS Inc."
        '
        'PicketsDB
        '
        Me.PicketsDB.Location = New System.Drawing.Point(5, 64)
        Me.PicketsDB.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.PicketsDB.Name = "PicketsDB"
        Me.PicketsDB.Size = New System.Drawing.Size(58, 23)
        Me.PicketsDB.TabIndex = 124
        Me.PicketsDB.Text = "Pickets"
        Me.PicketsDB.UseVisualStyleBackColor = True
        '
        'Label44
        '
        Me.Label44.AutoSize = True
        Me.Label44.Location = New System.Drawing.Point(226, 55)
        Me.Label44.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label44.Name = "Label44"
        Me.Label44.Size = New System.Drawing.Size(50, 13)
        Me.Label44.TabIndex = 130
        Me.Label44.Text = "DTB Inc."
        '
        'label99
        '
        Me.label99.AutoSize = True
        Me.label99.Location = New System.Drawing.Point(226, 34)
        Me.label99.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.label99.Name = "label99"
        Me.label99.Size = New System.Drawing.Size(80, 13)
        Me.label99.TabIndex = 126
        Me.label99.Text = "Rail Height Inc."
        '
        'Label43
        '
        Me.Label43.AutoSize = True
        Me.Label43.Location = New System.Drawing.Point(105, 75)
        Me.Label43.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label43.Name = "Label43"
        Me.Label43.Size = New System.Drawing.Size(49, 13)
        Me.Label43.TabIndex = 128
        Me.Label43.Text = "DFT Inc."
        '
        'TabPage3
        '
        Me.TabPage3.Controls.Add(Me.GroupBox5)
        Me.TabPage3.Controls.Add(Me.GroupBox4)
        Me.TabPage3.Controls.Add(Me.GroupBox7)
        Me.TabPage3.Controls.Add(Me.GroupBox15)
        Me.TabPage3.Controls.Add(Me.GroupBoxRun)
        Me.TabPage3.Controls.Add(Me.GroupBox16)
        Me.TabPage3.Controls.Add(Me.Options)
        Me.TabPage3.Controls.Add(Me.GroupBox17)
        Me.TabPage3.Controls.Add(Me.GroupBox9)
        Me.TabPage3.Controls.Add(Me.GroupBox6)
        Me.TabPage3.Controls.Add(Me.GroupBoxRise)
        Me.TabPage3.Controls.Add(Me.GroupBox2)
        Me.TabPage3.Controls.Add(Me.GroupBoxPostToStep)
        Me.TabPage3.Controls.Add(Me.GroupBox10)
        Me.TabPage3.Controls.Add(Me.GroupBoxDeckToPost)
        Me.TabPage3.Controls.Add(Me.GroupBox11)
        Me.TabPage3.Location = New System.Drawing.Point(4, 22)
        Me.TabPage3.Name = "TabPage3"
        Me.TabPage3.Size = New System.Drawing.Size(539, 239)
        Me.TabPage3.TabIndex = 2
        Me.TabPage3.Text = "Railing"
        Me.TabPage3.UseVisualStyleBackColor = True
        '
        'GroupBox5
        '
        Me.GroupBox5.Controls.Add(Me.Label3)
        Me.GroupBox5.Controls.Add(Me.Label2)
        Me.GroupBox5.Controls.Add(Me.ActPicketSpc)
        Me.GroupBox5.Controls.Add(Me.Label17)
        Me.GroupBox5.Location = New System.Drawing.Point(423, 63)
        Me.GroupBox5.Name = "GroupBox5"
        Me.GroupBox5.Size = New System.Drawing.Size(107, 52)
        Me.GroupBox5.TabIndex = 120
        Me.GroupBox5.TabStop = False
        Me.GroupBox5.Text = "Info"
        '
        'Label3
        '
        Me.Label3.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(4, 33)
        Me.Label3.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(63, 13)
        Me.Label3.TabIndex = 120
        Me.Label3.Text = "Aligned IBD"
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'GroupBox4
        '
        Me.GroupBox4.Controls.Add(Me.CheckBox1)
        Me.GroupBox4.Controls.Add(Me.CheckBox2)
        Me.GroupBox4.Controls.Add(Me.AngleRef)
        Me.GroupBox4.Location = New System.Drawing.Point(217, 59)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(107, 56)
        Me.GroupBox4.TabIndex = 146
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "Options"
        '
        'GroupBoxRun
        '
        Me.GroupBoxRun.Controls.Add(Me.RunDownSelect)
        Me.GroupBoxRun.Controls.Add(Me.RunUpSelect)
        Me.GroupBoxRun.Controls.Add(Me.StrRun)
        Me.GroupBoxRun.Location = New System.Drawing.Point(311, 188)
        Me.GroupBoxRun.Name = "GroupBoxRun"
        Me.GroupBoxRun.Size = New System.Drawing.Size(107, 43)
        Me.GroupBoxRun.TabIndex = 150
        Me.GroupBoxRun.TabStop = False
        Me.GroupBoxRun.Text = "Run"
        '
        'RunDownSelect
        '
        Me.RunDownSelect.BackColor = System.Drawing.Color.White
        Me.RunDownSelect.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.RunDownSelect.FlatAppearance.BorderSize = 0
        Me.RunDownSelect.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RunDownSelect.Location = New System.Drawing.Point(7, 16)
        Me.RunDownSelect.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.RunDownSelect.Name = "RunDownSelect"
        Me.RunDownSelect.Size = New System.Drawing.Size(20, 20)
        Me.RunDownSelect.TabIndex = 148
        Me.RunDownSelect.Text = "<"
        Me.RunDownSelect.UseVisualStyleBackColor = False
        '
        'RunUpSelect
        '
        Me.RunUpSelect.BackColor = System.Drawing.Color.White
        Me.RunUpSelect.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RunUpSelect.Location = New System.Drawing.Point(29, 16)
        Me.RunUpSelect.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.RunUpSelect.Name = "RunUpSelect"
        Me.RunUpSelect.Size = New System.Drawing.Size(20, 20)
        Me.RunUpSelect.TabIndex = 148
        Me.RunUpSelect.Text = ">"
        Me.RunUpSelect.UseVisualStyleBackColor = False
        '
        'GroupBoxRise
        '
        Me.GroupBoxRise.Controls.Add(Me.StrRise)
        Me.GroupBoxRise.Controls.Add(Me.RiseDownSelect)
        Me.GroupBoxRise.Controls.Add(Me.RiseUpSelect)
        Me.GroupBoxRise.Location = New System.Drawing.Point(311, 128)
        Me.GroupBoxRise.Name = "GroupBoxRise"
        Me.GroupBoxRise.Size = New System.Drawing.Size(107, 43)
        Me.GroupBoxRise.TabIndex = 149
        Me.GroupBoxRise.TabStop = False
        Me.GroupBoxRise.Text = "Rise"
        '
        'RiseDownSelect
        '
        Me.RiseDownSelect.BackColor = System.Drawing.Color.White
        Me.RiseDownSelect.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.RiseDownSelect.FlatAppearance.BorderSize = 0
        Me.RiseDownSelect.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RiseDownSelect.Location = New System.Drawing.Point(7, 16)
        Me.RiseDownSelect.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.RiseDownSelect.Name = "RiseDownSelect"
        Me.RiseDownSelect.Size = New System.Drawing.Size(20, 20)
        Me.RiseDownSelect.TabIndex = 148
        Me.RiseDownSelect.Text = "<"
        Me.RiseDownSelect.UseVisualStyleBackColor = False
        '
        'RiseUpSelect
        '
        Me.RiseUpSelect.BackColor = System.Drawing.Color.White
        Me.RiseUpSelect.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RiseUpSelect.Location = New System.Drawing.Point(29, 16)
        Me.RiseUpSelect.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.RiseUpSelect.Name = "RiseUpSelect"
        Me.RiseUpSelect.Size = New System.Drawing.Size(20, 20)
        Me.RiseUpSelect.TabIndex = 148
        Me.RiseUpSelect.Text = ">"
        Me.RiseUpSelect.UseVisualStyleBackColor = False
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.PostHeight)
        Me.GroupBox2.Controls.Add(Me.ComboBox3)
        Me.GroupBox2.Controls.Add(Me.Label14)
        Me.GroupBox2.Controls.Add(Me.Label15)
        Me.GroupBox2.Controls.Add(Me.PostWidth)
        Me.GroupBox2.Controls.Add(Me.PostThick)
        Me.GroupBox2.Controls.Add(Me.Label16)
        Me.GroupBox2.Location = New System.Drawing.Point(12, 12)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(89, 103)
        Me.GroupBox2.TabIndex = 147
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Post"
        '
        'TabControl2
        '
        Me.TabControl2.Controls.Add(Me.TabPage3)
        Me.TabControl2.Controls.Add(Me.TabPage1)
        Me.TabControl2.Location = New System.Drawing.Point(10, 3)
        Me.TabControl2.Name = "TabControl2"
        Me.TabControl2.SelectedIndex = 0
        Me.TabControl2.Size = New System.Drawing.Size(547, 265)
        Me.TabControl2.TabIndex = 119
        '
        'BottomRailsDBDataSet1
        '
        Me.BottomRailsDBDataSet1.DataSetName = "BottomRailsDBDataSet"
        Me.BottomRailsDBDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'MainPage
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.WhiteSmoke
        Me.ClientSize = New System.Drawing.Size(566, 467)
        Me.Controls.Add(Me.TabControl2)
        Me.Controls.Add(Me.StairCalc)
        Me.Controls.Add(Me.StairReset)
        Me.Controls.Add(Me.DataGridView1)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.Name = "MainPage"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "FenceBuilder"
        Me.Options.ResumeLayout(False)
        Me.Options.PerformLayout()
        CType(Me.PoLibBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PostsDBDataSet1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox15.ResumeLayout(False)
        Me.GroupBox15.PerformLayout()
        CType(Me.TopRaLibBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TopRailsDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox6.ResumeLayout(False)
        Me.GroupBox6.PerformLayout()
        CType(Me.BotRaLibBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.BottomRailsDBDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox7.ResumeLayout(False)
        Me.GroupBox7.PerformLayout()
        CType(Me.PicketLibBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PicketsDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox11.ResumeLayout(False)
        Me.GroupBox11.PerformLayout()
        Me.GroupBox10.ResumeLayout(False)
        Me.GroupBox10.PerformLayout()
        Me.GroupBox9.ResumeLayout(False)
        Me.GroupBox9.PerformLayout()
        Me.GroupBox20.ResumeLayout(False)
        Me.GroupBox20.PerformLayout()
        Me.GroupBoxPostToStep.ResumeLayout(False)
        Me.GroupBoxPostToStep.PerformLayout()
        Me.GroupBoxDeckToPost.ResumeLayout(False)
        Me.GroupBoxDeckToPost.PerformLayout()
        Me.GroupBox17.ResumeLayout(False)
        Me.GroupBox17.PerformLayout()
        Me.GroupBox16.ResumeLayout(False)
        Me.GroupBox16.PerformLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage1.ResumeLayout(False)
        Me.TabPage1.PerformLayout()
        Me.TabPage3.ResumeLayout(False)
        Me.GroupBox5.ResumeLayout(False)
        Me.GroupBox5.PerformLayout()
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox4.PerformLayout()
        Me.GroupBoxRun.ResumeLayout(False)
        Me.GroupBoxRun.PerformLayout()
        Me.GroupBoxRise.ResumeLayout(False)
        Me.GroupBoxRise.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.TabControl2.ResumeLayout(False)
        CType(Me.BottomRailsDBDataSet1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents GroupBox7 As GroupBox
    Friend WithEvents DesPicketSpc As TextBox
    Friend WithEvents GroupBox6 As GroupBox
    Friend WithEvents StairCalc As Button
    Friend WithEvents StairReset As Button
    Friend WithEvents ComboBox1 As ComboBox
    Friend WithEvents TopRailHeight As TextBox
    Friend WithEvents TopRailThick As TextBox
    Friend WithEvents TopRailWidth As TextBox
    Friend WithEvents BotRailThick As TextBox
    Friend WithEvents BotRailWidth As TextBox
    Friend WithEvents BotRailHeight As TextBox
    Friend WithEvents ComboBox2 As ComboBox
    Friend WithEvents PostsDBDataSet As PostsDBDataSet
    Friend WithEvents PoLibTableAdapter As PostsDBDataSetTableAdapters.PoLibTableAdapter
    Friend WithEvents GroupBox15 As GroupBox
    Friend WithEvents AngleRef As Label
    Friend WithEvents ActPicketSpc As Label
    Friend WithEvents PostHeight As TextBox
    Friend WithEvents Label14 As Label
    Friend WithEvents PostThick As TextBox
    Friend WithEvents Label16 As Label
    Friend WithEvents ComboBox3 As ComboBox
    Friend WithEvents PostWidth As TextBox
    Friend WithEvents Label15 As Label
    Friend WithEvents PostHoleClearance As TextBox
    Friend WithEvents PostBelowGround As TextBox
    Friend WithEvents Options As GroupBox
    Friend WithEvents Label5 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents Label18 As Label
    Friend WithEvents Label32 As Label
    Friend WithEvents Label33 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label17 As Label
    Friend WithEvents PicketComboBox As ComboBox
    Friend WithEvents PicketWidth As TextBox
    Friend WithEvents Label20 As Label
    Friend WithEvents PicketThick As TextBox
    Friend WithEvents Label21 As Label
    Friend WithEvents Label22 As Label
    Friend WithEvents PicketHeight As TextBox
    Friend WithEvents DistanceToBottom As TextBox
    Friend WithEvents DFTDownSelect As Button
    Friend WithEvents DTBDownSelect As Button
    Friend WithEvents DistanceFromTop As TextBox
    Friend WithEvents DTBUpSelect As Button
    Friend WithEvents InBetweenDistance As TextBox
    Friend WithEvents RailHeightDownSelect As Button
    Friend WithEvents RailHeight As TextBox
    Friend WithEvents InBetweenDistanceUpSelect As Button
    Friend WithEvents InbetweenDistanceDownSelect As Button
    Friend WithEvents DFTUpSelect As Button
    Friend WithEvents RailHeightUpSelect As Button
    Friend WithEvents PicSpaceUpSelect As Button
    Friend WithEvents PicSpaceDownSelect As Button
    Friend WithEvents DeckEdge As TextBox
    Friend WithEvents StepEdge As TextBox
    Friend WithEvents CheckBox2 As CheckBox
    Friend WithEvents GroupBox9 As GroupBox
    Friend WithEvents StrRun As TextBox
    Friend WithEvents CheckBox1 As CheckBox
    Friend WithEvents StrRise As TextBox
    Friend WithEvents GroupBox11 As GroupBox
    Friend WithEvents GroupBox10 As GroupBox
    Friend WithEvents GroupBoxPostToStep As GroupBox
    Friend WithEvents Post2FirstStepDownSel As Button
    Friend WithEvents Post2FirstStepUpSel As Button
    Friend WithEvents GroupBoxDeckToPost As GroupBox
    Friend WithEvents DeckEdge2PostDownSel As Button
    Friend WithEvents DeckEdge2PostUpSel As Button
    Friend WithEvents GroupBox17 As GroupBox
    Friend WithEvents GroupBox16 As GroupBox
    'Friend WithEvents RaLibTableAdapter2 As RailsDBDataSet5TableAdapters.RaLibTableAdapter
    Friend WithEvents AmtInGroundDownSel As Button
    Friend WithEvents AmtInGroundUpSel As Button
    Friend WithEvents GroupBox20 As GroupBox
    Friend WithEvents HoleClearanceDownSel As Button
    Friend WithEvents HoleClearanceUpSel As Button
    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents TopRailsDataSet As TopRailsDataSet
    Friend WithEvents TopRaLibBindingSource As BindingSource
    Friend WithEvents RaLibTableAdapter1 As TopRailsDataSetTableAdapters.RaLibTableAdapter
    Friend WithEvents PicketsDataSet As PicketsDataSet
    Friend WithEvents PicketLibBindingSource As BindingSource
    Friend WithEvents PicketLibTableAdapter As PicketsDataSetTableAdapters.PicketLibTableAdapter
    Friend WithEvents PostsDBDataSet1 As PostsDBDataSet1
    Friend WithEvents PoLibBindingSource As BindingSource
    Friend WithEvents PoLibTableAdapter1 As PostsDBDataSet1TableAdapters.PoLibTableAdapter
    Friend WithEvents BottomRailsDBDataSet As BottomRailsDBDataSet1
    Friend WithEvents BotRaLibBindingSource As BindingSource
    Friend WithEvents RaLibTableAdapter As BottomRailsDBDataSet1TableAdapters.RaLibTableAdapter
    Friend WithEvents TopStrRailCutL As Label
    Friend WithEvents BotStrRailCutL As Label
    Friend WithEvents TabPage1 As TabPage
    Friend WithEvents Label24 As Label
    Friend WithEvents RailingDB As Button
    Friend WithEvents HoleClearanceInc As TextBox
    Friend WithEvents AmtInGroundInc As TextBox
    Friend WithEvents ExtraEndMat As TextBox
    Friend WithEvents DeckEdgeIncrement As TextBox
    Friend WithEvents PicketClear As TextBox
    Friend WithEvents IBDIncrement As TextBox
    Friend WithEvents StepEdgeIncrement As TextBox
    Friend WithEvents DPSIncrement As TextBox
    Friend WithEvents RailHeightIncrement As TextBox
    Friend WithEvents DTBIncrement As TextBox
    Friend WithEvents DFTIncrement As TextBox
    Friend WithEvents Label35 As Label
    Friend WithEvents Label13 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents PostDB As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents Label19 As Label
    Friend WithEvents Label42 As Label
    Friend WithEvents PicketsDB As Button
    Friend WithEvents Label44 As Label
    Friend WithEvents label99 As Label
    Friend WithEvents Label43 As Label
    Friend WithEvents TabPage3 As TabPage
    Friend WithEvents TabControl2 As TabControl
    Friend WithEvents BottomRailsDBDataSet1 As BottomRailsDBDataSet
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents RiseDownSelect As Button
    Friend WithEvents RiseUpSelect As Button
    Friend WithEvents GroupBoxRise As GroupBox
    Friend WithEvents GroupBoxRun As GroupBox
    Friend WithEvents RunDownSelect As Button
    Friend WithEvents RunUpSelect As Button
    Friend WithEvents GroupBox5 As GroupBox
    Friend WithEvents GroupBox4 As GroupBox
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents RiseIncrement As TextBox
    Friend WithEvents RunIncrement As TextBox
    Friend WithEvents Label8 As Label
End Class
