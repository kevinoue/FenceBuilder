﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class MainPage
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(MainPage))
        Me.GroupBox4 = New System.Windows.Forms.GroupBox()
        Me.BetweenHolesNoSlope = New System.Windows.Forms.Label()
        Me.Label38 = New System.Windows.Forms.Label()
        Me.Label50 = New System.Windows.Forms.Label()
        Me.PostCutLength = New System.Windows.Forms.Label()
        Me.GroupBox23 = New System.Windows.Forms.GroupBox()
        Me.BetweenHolesSlope = New System.Windows.Forms.Label()
        Me.Label62 = New System.Windows.Forms.Label()
        Me.PostSecondHole = New System.Windows.Forms.Label()
        Me.Label60 = New System.Windows.Forms.Label()
        Me.PostFirstHole = New System.Windows.Forms.Label()
        Me.Label59 = New System.Windows.Forms.Label()
        Me.GroupBox22 = New System.Windows.Forms.GroupBox()
        Me.Label92 = New System.Windows.Forms.Label()
        Me.Label94 = New System.Windows.Forms.Label()
        Me.TopPostFirstHole2 = New System.Windows.Forms.Label()
        Me.TopPostCutLength = New System.Windows.Forms.Label()
        Me.GroupBox13 = New System.Windows.Forms.GroupBox()
        Me.Label65 = New System.Windows.Forms.Label()
        Me.Label66 = New System.Windows.Forms.Label()
        Me.BotPostFirstHole2 = New System.Windows.Forms.Label()
        Me.BotPostCutLength = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.Label31 = New System.Windows.Forms.Label()
        Me.GroupBox8 = New System.Windows.Forms.GroupBox()
        Me.Label45 = New System.Windows.Forms.Label()
        Me.Label48 = New System.Windows.Forms.Label()
        Me.Label46 = New System.Windows.Forms.Label()
        Me.Label47 = New System.Windows.Forms.Label()
        Me.TopStrRailPicSpace = New System.Windows.Forms.Label()
        Me.TopStrRailDisFirstHole = New System.Windows.Forms.Label()
        Me.TopStrRailCutL = New System.Windows.Forms.Label()
        Me.TopRailHole = New System.Windows.Forms.Label()
        Me.GroupBox5 = New System.Windows.Forms.GroupBox()
        Me.Label49 = New System.Windows.Forms.Label()
        Me.Label51 = New System.Windows.Forms.Label()
        Me.PicketCutL = New System.Windows.Forms.Label()
        Me.NumPicketHoles = New System.Windows.Forms.Label()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.BotStrRailPicSpace = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.BotRailHole = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.BotStrRailDisFirstHole = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.BotStrRailCutL = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.HoleClearanceInc = New System.Windows.Forms.TextBox()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.AmtInGroundInc = New System.Windows.Forms.TextBox()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.DeckEdgeIncrement = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.StepEdgeIncrement = New System.Windows.Forms.TextBox()
        Me.Label42 = New System.Windows.Forms.Label()
        Me.DPSIncrement = New System.Windows.Forms.TextBox()
        Me.Label44 = New System.Windows.Forms.Label()
        Me.DTBIncrement = New System.Windows.Forms.TextBox()
        Me.Label43 = New System.Windows.Forms.Label()
        Me.DFTIncrement = New System.Windows.Forms.TextBox()
        Me.label99 = New System.Windows.Forms.Label()
        Me.RailHeightIncrement = New System.Windows.Forms.TextBox()
        Me.PicketsDB = New System.Windows.Forms.Button()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.IBDIncrement = New System.Windows.Forms.TextBox()
        Me.PicketClear = New System.Windows.Forms.TextBox()
        Me.PostDB = New System.Windows.Forms.Button()
        Me.RailingDB = New System.Windows.Forms.Button()
        Me.ExtraEndMat = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label35 = New System.Windows.Forms.Label()
        Me.Options = New System.Windows.Forms.GroupBox()
        Me.AmtInGroundDownSel = New System.Windows.Forms.Button()
        Me.AmtInGroundUpSel = New System.Windows.Forms.Button()
        Me.PostBelowGround = New System.Windows.Forms.TextBox()
        Me.PostHoleClearance = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.AngleRef = New System.Windows.Forms.Label()
        Me.StairCalc = New System.Windows.Forms.Button()
        Me.StairReset = New System.Windows.Forms.Button()
        Me.PostOptions = New System.Windows.Forms.GroupBox()
        Me.PostHeight = New System.Windows.Forms.TextBox()
        Me.PoLibBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.PostsDBDataSet1 = New FenceBuilderRootNmspc.PostsDBDataSet1()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.PostThick = New System.Windows.Forms.TextBox()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.ComboBox3 = New System.Windows.Forms.ComboBox()
        Me.PostWidth = New System.Windows.Forms.TextBox()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.GroupBox15 = New System.Windows.Forms.GroupBox()
        Me.ComboBox1 = New System.Windows.Forms.ComboBox()
        Me.TopRaLibBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.TopRailsDataSet = New FenceBuilderRootNmspc.TopRailsDataSet()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.TopRailHeight = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.TopRailThick = New System.Windows.Forms.TextBox()
        Me.TopRailWidth = New System.Windows.Forms.TextBox()
        Me.GroupBox6 = New System.Windows.Forms.GroupBox()
        Me.BotRailWidth = New System.Windows.Forms.TextBox()
        Me.BotRaLibBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.BottomRailsDBDataSet = New FenceBuilderRootNmspc.BottomRailsDBDataSet1()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.BotRailThick = New System.Windows.Forms.TextBox()
        Me.ComboBox2 = New System.Windows.Forms.ComboBox()
        Me.Label32 = New System.Windows.Forms.Label()
        Me.Label33 = New System.Windows.Forms.Label()
        Me.BotRailHeight = New System.Windows.Forms.TextBox()
        Me.GroupBox7 = New System.Windows.Forms.GroupBox()
        Me.PicketComboBox = New System.Windows.Forms.ComboBox()
        Me.PicketLibBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.PicketsDataSet = New FenceBuilderRootNmspc.PicketsDataSet()
        Me.PicketHeight = New System.Windows.Forms.TextBox()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.PicketWidth = New System.Windows.Forms.TextBox()
        Me.PicketThick = New System.Windows.Forms.TextBox()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.DesPicketSpc = New System.Windows.Forms.TextBox()
        Me.DistanceToBottom = New System.Windows.Forms.TextBox()
        Me.DistanceFromTop = New System.Windows.Forms.TextBox()
        Me.InBetweenDistance = New System.Windows.Forms.TextBox()
        Me.RailHeight = New System.Windows.Forms.TextBox()
        Me.TabControl2 = New System.Windows.Forms.TabControl()
        Me.TabPage3 = New System.Windows.Forms.TabPage()
        Me.GroupBox11 = New System.Windows.Forms.GroupBox()
        Me.InbetweenDistanceDownSelect = New System.Windows.Forms.Button()
        Me.InBetweenDistanceUpSelect = New System.Windows.Forms.Button()
        Me.CheckBox2 = New System.Windows.Forms.CheckBox()
        Me.GroupBox10 = New System.Windows.Forms.GroupBox()
        Me.RailHeightDownSelect = New System.Windows.Forms.Button()
        Me.RailHeightUpSelect = New System.Windows.Forms.Button()
        Me.TabPage4 = New System.Windows.Forms.TabPage()
        Me.GroupBox9 = New System.Windows.Forms.GroupBox()
        Me.PicSpaceDownSelect = New System.Windows.Forms.Button()
        Me.PicSpaceUpSelect = New System.Windows.Forms.Button()
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.GroupBox17 = New System.Windows.Forms.GroupBox()
        Me.DTBUpSelect = New System.Windows.Forms.Button()
        Me.DTBDownSelect = New System.Windows.Forms.Button()
        Me.GroupBox16 = New System.Windows.Forms.GroupBox()
        Me.DFTDownSelect = New System.Windows.Forms.Button()
        Me.DFTUpSelect = New System.Windows.Forms.Button()
        Me.GroupBox20 = New System.Windows.Forms.GroupBox()
        Me.HoleClearanceDownSel = New System.Windows.Forms.Button()
        Me.HoleClearanceUpSel = New System.Windows.Forms.Button()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.GroupBox19 = New System.Windows.Forms.GroupBox()
        Me.Post2FirstStepDownSel = New System.Windows.Forms.Button()
        Me.StepEdge = New System.Windows.Forms.TextBox()
        Me.Post2FirstStepUpSel = New System.Windows.Forms.Button()
        Me.GroupBox18 = New System.Windows.Forms.GroupBox()
        Me.DeckEdge2PostDownSel = New System.Windows.Forms.Button()
        Me.DeckEdge = New System.Windows.Forms.TextBox()
        Me.DeckEdge2PostUpSel = New System.Windows.Forms.Button()
        Me.GroupBox12 = New System.Windows.Forms.GroupBox()
        Me.RadioButton2 = New System.Windows.Forms.RadioButton()
        Me.GroupBox26 = New System.Windows.Forms.GroupBox()
        Me.StrRun = New System.Windows.Forms.TextBox()
        Me.RunDownSel = New System.Windows.Forms.Button()
        Me.RunUpSel = New System.Windows.Forms.Button()
        Me.RadioButton1 = New System.Windows.Forms.RadioButton()
        Me.GroupBox25 = New System.Windows.Forms.GroupBox()
        Me.StrRise = New System.Windows.Forms.TextBox()
        Me.RiseDownSel = New System.Windows.Forms.Button()
        Me.RiseUpSel = New System.Windows.Forms.Button()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.RaLibTableAdapter1 = New FenceBuilderRootNmspc.TopRailsDataSetTableAdapters.RaLibTableAdapter()
        Me.PicketLibTableAdapter = New FenceBuilderRootNmspc.PicketsDataSetTableAdapters.PicketLibTableAdapter()
        Me.PoLibTableAdapter1 = New FenceBuilderRootNmspc.PostsDBDataSet1TableAdapters.PoLibTableAdapter()
        Me.RaLibTableAdapter = New FenceBuilderRootNmspc.BottomRailsDBDataSet1TableAdapters.RaLibTableAdapter()
        Me.GroupBox24 = New System.Windows.Forms.GroupBox()
        Me.StanDistFirstHole = New System.Windows.Forms.Label()
        Me.StanRailCutL = New System.Windows.Forms.Label()
        Me.PicketSpaceNoSlope = New System.Windows.Forms.Label()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.GroupBox27 = New System.Windows.Forms.GroupBox()
        Me.GroupBox4.SuspendLayout()
        Me.GroupBox23.SuspendLayout()
        Me.GroupBox22.SuspendLayout()
        Me.GroupBox13.SuspendLayout()
        Me.GroupBox8.SuspendLayout()
        Me.GroupBox5.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.Options.SuspendLayout()
        Me.PostOptions.SuspendLayout()
        CType(Me.PoLibBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PostsDBDataSet1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox15.SuspendLayout()
        CType(Me.TopRaLibBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TopRailsDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox6.SuspendLayout()
        CType(Me.BotRaLibBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.BottomRailsDBDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox7.SuspendLayout()
        CType(Me.PicketLibBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PicketsDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabControl2.SuspendLayout()
        Me.TabPage3.SuspendLayout()
        Me.GroupBox11.SuspendLayout()
        Me.GroupBox10.SuspendLayout()
        Me.TabPage4.SuspendLayout()
        Me.GroupBox9.SuspendLayout()
        Me.TabPage2.SuspendLayout()
        Me.GroupBox17.SuspendLayout()
        Me.GroupBox16.SuspendLayout()
        Me.GroupBox20.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        Me.GroupBox19.SuspendLayout()
        Me.GroupBox18.SuspendLayout()
        Me.GroupBox12.SuspendLayout()
        Me.GroupBox26.SuspendLayout()
        Me.GroupBox25.SuspendLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox24.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox27.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox4
        '
        Me.GroupBox4.Controls.Add(Me.BetweenHolesNoSlope)
        Me.GroupBox4.Controls.Add(Me.Label38)
        Me.GroupBox4.Controls.Add(Me.Label50)
        Me.GroupBox4.Controls.Add(Me.PostCutLength)
        Me.GroupBox4.Location = New System.Drawing.Point(521, 230)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(120, 53)
        Me.GroupBox4.TabIndex = 144
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "Post"
        '
        'BetweenHolesNoSlope
        '
        Me.BetweenHolesNoSlope.AutoSize = True
        Me.BetweenHolesNoSlope.Location = New System.Drawing.Point(80, 33)
        Me.BetweenHolesNoSlope.Name = "BetweenHolesNoSlope"
        Me.BetweenHolesNoSlope.Size = New System.Drawing.Size(34, 13)
        Me.BetweenHolesNoSlope.TabIndex = 130
        Me.BetweenHolesNoSlope.Text = "0.000"
        '
        'Label38
        '
        Me.Label38.AutoSize = True
        Me.Label38.Location = New System.Drawing.Point(16, 16)
        Me.Label38.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label38.Name = "Label38"
        Me.Label38.Size = New System.Drawing.Size(59, 13)
        Me.Label38.TabIndex = 120
        Me.Label38.Text = "Cut Length"
        '
        'Label50
        '
        Me.Label50.AutoSize = True
        Me.Label50.Location = New System.Drawing.Point(16, 32)
        Me.Label50.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label50.Name = "Label50"
        Me.Label50.Size = New System.Drawing.Size(46, 13)
        Me.Label50.TabIndex = 122
        Me.Label50.Text = "Spacing"
        '
        'PostCutLength
        '
        Me.PostCutLength.AutoSize = True
        Me.PostCutLength.Location = New System.Drawing.Point(80, 16)
        Me.PostCutLength.Name = "PostCutLength"
        Me.PostCutLength.Size = New System.Drawing.Size(34, 13)
        Me.PostCutLength.TabIndex = 129
        Me.PostCutLength.Text = "0.000"
        '
        'GroupBox23
        '
        Me.GroupBox23.Controls.Add(Me.BetweenHolesSlope)
        Me.GroupBox23.Controls.Add(Me.Label62)
        Me.GroupBox23.Controls.Add(Me.PostSecondHole)
        Me.GroupBox23.Controls.Add(Me.Label60)
        Me.GroupBox23.Controls.Add(Me.PostFirstHole)
        Me.GroupBox23.Controls.Add(Me.Label59)
        Me.GroupBox23.Location = New System.Drawing.Point(525, 159)
        Me.GroupBox23.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.GroupBox23.Name = "GroupBox23"
        Me.GroupBox23.Padding = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.GroupBox23.Size = New System.Drawing.Size(120, 67)
        Me.GroupBox23.TabIndex = 128
        Me.GroupBox23.TabStop = False
        Me.GroupBox23.Text = "Post Holes"
        '
        'BetweenHolesSlope
        '
        Me.BetweenHolesSlope.AutoSize = True
        Me.BetweenHolesSlope.Location = New System.Drawing.Point(80, 50)
        Me.BetweenHolesSlope.Name = "BetweenHolesSlope"
        Me.BetweenHolesSlope.Size = New System.Drawing.Size(34, 13)
        Me.BetweenHolesSlope.TabIndex = 141
        Me.BetweenHolesSlope.Text = "0.000"
        '
        'Label62
        '
        Me.Label62.AutoSize = True
        Me.Label62.Location = New System.Drawing.Point(16, 16)
        Me.Label62.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label62.Name = "Label62"
        Me.Label62.Size = New System.Drawing.Size(46, 13)
        Me.Label62.TabIndex = 41
        Me.Label62.Text = "1st Hole"
        '
        'PostSecondHole
        '
        Me.PostSecondHole.AutoSize = True
        Me.PostSecondHole.Location = New System.Drawing.Point(80, 33)
        Me.PostSecondHole.Name = "PostSecondHole"
        Me.PostSecondHole.Size = New System.Drawing.Size(34, 13)
        Me.PostSecondHole.TabIndex = 140
        Me.PostSecondHole.Text = "0.000"
        '
        'Label60
        '
        Me.Label60.AutoSize = True
        Me.Label60.Location = New System.Drawing.Point(16, 48)
        Me.Label60.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label60.Name = "Label60"
        Me.Label60.Size = New System.Drawing.Size(46, 13)
        Me.Label60.TabIndex = 45
        Me.Label60.Text = "Spacing"
        '
        'PostFirstHole
        '
        Me.PostFirstHole.AutoSize = True
        Me.PostFirstHole.Location = New System.Drawing.Point(80, 16)
        Me.PostFirstHole.Name = "PostFirstHole"
        Me.PostFirstHole.Size = New System.Drawing.Size(34, 13)
        Me.PostFirstHole.TabIndex = 139
        Me.PostFirstHole.Text = "0.000"
        '
        'Label59
        '
        Me.Label59.AutoSize = True
        Me.Label59.Location = New System.Drawing.Point(16, 32)
        Me.Label59.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label59.Name = "Label59"
        Me.Label59.Size = New System.Drawing.Size(50, 13)
        Me.Label59.TabIndex = 43
        Me.Label59.Text = "2nd Hole"
        '
        'GroupBox22
        '
        Me.GroupBox22.Controls.Add(Me.Label92)
        Me.GroupBox22.Controls.Add(Me.Label94)
        Me.GroupBox22.Controls.Add(Me.TopPostFirstHole2)
        Me.GroupBox22.Controls.Add(Me.TopPostCutLength)
        Me.GroupBox22.Location = New System.Drawing.Point(525, 59)
        Me.GroupBox22.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.GroupBox22.Name = "GroupBox22"
        Me.GroupBox22.Padding = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.GroupBox22.Size = New System.Drawing.Size(120, 50)
        Me.GroupBox22.TabIndex = 80
        Me.GroupBox22.TabStop = False
        Me.GroupBox22.Text = "Top Post"
        '
        'Label92
        '
        Me.Label92.AutoSize = True
        Me.Label92.Location = New System.Drawing.Point(16, 16)
        Me.Label92.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label92.Name = "Label92"
        Me.Label92.Size = New System.Drawing.Size(51, 13)
        Me.Label92.TabIndex = 37
        Me.Label92.Text = "First Hole"
        '
        'Label94
        '
        Me.Label94.AutoSize = True
        Me.Label94.Location = New System.Drawing.Point(16, 32)
        Me.Label94.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label94.Name = "Label94"
        Me.Label94.Size = New System.Drawing.Size(59, 13)
        Me.Label94.TabIndex = 39
        Me.Label94.Text = "Cut Length"
        '
        'TopPostFirstHole2
        '
        Me.TopPostFirstHole2.AutoSize = True
        Me.TopPostFirstHole2.Location = New System.Drawing.Point(79, 16)
        Me.TopPostFirstHole2.Name = "TopPostFirstHole2"
        Me.TopPostFirstHole2.Size = New System.Drawing.Size(34, 13)
        Me.TopPostFirstHole2.TabIndex = 135
        Me.TopPostFirstHole2.Text = "0.000"
        '
        'TopPostCutLength
        '
        Me.TopPostCutLength.AutoSize = True
        Me.TopPostCutLength.Location = New System.Drawing.Point(79, 33)
        Me.TopPostCutLength.Name = "TopPostCutLength"
        Me.TopPostCutLength.Size = New System.Drawing.Size(34, 13)
        Me.TopPostCutLength.TabIndex = 136
        Me.TopPostCutLength.Text = "0.000"
        '
        'GroupBox13
        '
        Me.GroupBox13.Controls.Add(Me.Label65)
        Me.GroupBox13.Controls.Add(Me.Label66)
        Me.GroupBox13.Controls.Add(Me.BotPostFirstHole2)
        Me.GroupBox13.Controls.Add(Me.BotPostCutLength)
        Me.GroupBox13.Location = New System.Drawing.Point(525, 109)
        Me.GroupBox13.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.GroupBox13.Name = "GroupBox13"
        Me.GroupBox13.Padding = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.GroupBox13.Size = New System.Drawing.Size(120, 50)
        Me.GroupBox13.TabIndex = 82
        Me.GroupBox13.TabStop = False
        Me.GroupBox13.Text = "Bottom Post"
        '
        'Label65
        '
        Me.Label65.AutoSize = True
        Me.Label65.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!)
        Me.Label65.Location = New System.Drawing.Point(16, 16)
        Me.Label65.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label65.Name = "Label65"
        Me.Label65.Size = New System.Drawing.Size(51, 13)
        Me.Label65.TabIndex = 40
        Me.Label65.Text = "First Hole"
        '
        'Label66
        '
        Me.Label66.AutoSize = True
        Me.Label66.Location = New System.Drawing.Point(16, 32)
        Me.Label66.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label66.Name = "Label66"
        Me.Label66.Size = New System.Drawing.Size(55, 13)
        Me.Label66.TabIndex = 41
        Me.Label66.Text = "Cut length"
        '
        'BotPostFirstHole2
        '
        Me.BotPostFirstHole2.AutoSize = True
        Me.BotPostFirstHole2.Location = New System.Drawing.Point(79, 16)
        Me.BotPostFirstHole2.Name = "BotPostFirstHole2"
        Me.BotPostFirstHole2.Size = New System.Drawing.Size(34, 13)
        Me.BotPostFirstHole2.TabIndex = 137
        Me.BotPostFirstHole2.Text = "0.000"
        '
        'BotPostCutLength
        '
        Me.BotPostCutLength.AutoSize = True
        Me.BotPostCutLength.Location = New System.Drawing.Point(79, 33)
        Me.BotPostCutLength.Name = "BotPostCutLength"
        Me.BotPostCutLength.Size = New System.Drawing.Size(34, 13)
        Me.BotPostCutLength.TabIndex = 138
        Me.BotPostCutLength.Text = "0.000"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(16, 48)
        Me.Label3.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(46, 13)
        Me.Label3.TabIndex = 119
        Me.Label3.Text = "Spacing"
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.Location = New System.Drawing.Point(16, 32)
        Me.Label26.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(51, 13)
        Me.Label26.TabIndex = 51
        Me.Label26.Text = "First Hole"
        '
        'Label31
        '
        Me.Label31.AutoSize = True
        Me.Label31.Location = New System.Drawing.Point(16, 16)
        Me.Label31.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(59, 13)
        Me.Label31.TabIndex = 47
        Me.Label31.Text = "Cut Length"
        '
        'GroupBox8
        '
        Me.GroupBox8.Controls.Add(Me.Label45)
        Me.GroupBox8.Controls.Add(Me.Label48)
        Me.GroupBox8.Controls.Add(Me.Label46)
        Me.GroupBox8.Controls.Add(Me.Label47)
        Me.GroupBox8.Controls.Add(Me.TopStrRailPicSpace)
        Me.GroupBox8.Controls.Add(Me.TopStrRailDisFirstHole)
        Me.GroupBox8.Controls.Add(Me.TopStrRailCutL)
        Me.GroupBox8.Controls.Add(Me.TopRailHole)
        Me.GroupBox8.Location = New System.Drawing.Point(525, 345)
        Me.GroupBox8.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.GroupBox8.Name = "GroupBox8"
        Me.GroupBox8.Padding = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.GroupBox8.Size = New System.Drawing.Size(120, 84)
        Me.GroupBox8.TabIndex = 16
        Me.GroupBox8.TabStop = False
        Me.GroupBox8.Text = "Top Railing"
        '
        'Label45
        '
        Me.Label45.AutoSize = True
        Me.Label45.Location = New System.Drawing.Point(16, 16)
        Me.Label45.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label45.Name = "Label45"
        Me.Label45.Size = New System.Drawing.Size(59, 13)
        Me.Label45.TabIndex = 47
        Me.Label45.Text = "Cut Length"
        '
        'Label48
        '
        Me.Label48.AutoSize = True
        Me.Label48.Location = New System.Drawing.Point(16, 64)
        Me.Label48.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label48.Name = "Label48"
        Me.Label48.Size = New System.Drawing.Size(46, 13)
        Me.Label48.TabIndex = 53
        Me.Label48.Text = "Spacing"
        '
        'Label46
        '
        Me.Label46.AutoSize = True
        Me.Label46.Location = New System.Drawing.Point(16, 32)
        Me.Label46.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label46.Name = "Label46"
        Me.Label46.Size = New System.Drawing.Size(52, 13)
        Me.Label46.TabIndex = 49
        Me.Label46.Text = "Hole Size"
        '
        'Label47
        '
        Me.Label47.AutoSize = True
        Me.Label47.Location = New System.Drawing.Point(16, 48)
        Me.Label47.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label47.Name = "Label47"
        Me.Label47.Size = New System.Drawing.Size(51, 13)
        Me.Label47.TabIndex = 51
        Me.Label47.Text = "First Hole"
        '
        'TopStrRailPicSpace
        '
        Me.TopStrRailPicSpace.AutoSize = True
        Me.TopStrRailPicSpace.Location = New System.Drawing.Point(80, 65)
        Me.TopStrRailPicSpace.Name = "TopStrRailPicSpace"
        Me.TopStrRailPicSpace.Size = New System.Drawing.Size(34, 13)
        Me.TopStrRailPicSpace.TabIndex = 132
        Me.TopStrRailPicSpace.Text = "0.000"
        '
        'TopStrRailDisFirstHole
        '
        Me.TopStrRailDisFirstHole.AutoSize = True
        Me.TopStrRailDisFirstHole.Location = New System.Drawing.Point(80, 49)
        Me.TopStrRailDisFirstHole.Name = "TopStrRailDisFirstHole"
        Me.TopStrRailDisFirstHole.Size = New System.Drawing.Size(34, 13)
        Me.TopStrRailDisFirstHole.TabIndex = 131
        Me.TopStrRailDisFirstHole.Text = "0.000"
        '
        'TopStrRailCutL
        '
        Me.TopStrRailCutL.AutoSize = True
        Me.TopStrRailCutL.Location = New System.Drawing.Point(80, 15)
        Me.TopStrRailCutL.Name = "TopStrRailCutL"
        Me.TopStrRailCutL.Size = New System.Drawing.Size(34, 13)
        Me.TopStrRailCutL.TabIndex = 129
        Me.TopStrRailCutL.Text = "0.000"
        '
        'TopRailHole
        '
        Me.TopRailHole.AutoSize = True
        Me.TopRailHole.Location = New System.Drawing.Point(80, 32)
        Me.TopRailHole.Name = "TopRailHole"
        Me.TopRailHole.Size = New System.Drawing.Size(34, 13)
        Me.TopRailHole.TabIndex = 130
        Me.TopRailHole.Text = "0.000"
        '
        'GroupBox5
        '
        Me.GroupBox5.Controls.Add(Me.Label49)
        Me.GroupBox5.Controls.Add(Me.Label51)
        Me.GroupBox5.Controls.Add(Me.PicketCutL)
        Me.GroupBox5.Controls.Add(Me.NumPicketHoles)
        Me.GroupBox5.Location = New System.Drawing.Point(524, 6)
        Me.GroupBox5.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.GroupBox5.Name = "GroupBox5"
        Me.GroupBox5.Padding = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.GroupBox5.Size = New System.Drawing.Size(120, 54)
        Me.GroupBox5.TabIndex = 66
        Me.GroupBox5.TabStop = False
        Me.GroupBox5.Text = "Pickets"
        '
        'Label49
        '
        Me.Label49.AutoSize = True
        Me.Label49.Location = New System.Drawing.Point(16, 32)
        Me.Label49.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label49.Name = "Label49"
        Me.Label49.Size = New System.Drawing.Size(46, 13)
        Me.Label49.TabIndex = 55
        Me.Label49.Text = "Quantity"
        '
        'Label51
        '
        Me.Label51.AutoSize = True
        Me.Label51.Location = New System.Drawing.Point(16, 16)
        Me.Label51.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label51.Name = "Label51"
        Me.Label51.Size = New System.Drawing.Size(59, 13)
        Me.Label51.TabIndex = 59
        Me.Label51.Text = "Cut Length"
        '
        'PicketCutL
        '
        Me.PicketCutL.AutoSize = True
        Me.PicketCutL.Location = New System.Drawing.Point(79, 17)
        Me.PicketCutL.Name = "PicketCutL"
        Me.PicketCutL.Size = New System.Drawing.Size(34, 13)
        Me.PicketCutL.TabIndex = 133
        Me.PicketCutL.Text = "0.000"
        '
        'NumPicketHoles
        '
        Me.NumPicketHoles.AutoSize = True
        Me.NumPicketHoles.Location = New System.Drawing.Point(79, 34)
        Me.NumPicketHoles.Name = "NumPicketHoles"
        Me.NumPicketHoles.Size = New System.Drawing.Size(34, 13)
        Me.NumPicketHoles.TabIndex = 134
        Me.NumPicketHoles.Text = "0.000"
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.BotStrRailPicSpace)
        Me.GroupBox2.Controls.Add(Me.Label4)
        Me.GroupBox2.Controls.Add(Me.BotRailHole)
        Me.GroupBox2.Controls.Add(Me.Label8)
        Me.GroupBox2.Controls.Add(Me.BotStrRailDisFirstHole)
        Me.GroupBox2.Controls.Add(Me.Label9)
        Me.GroupBox2.Controls.Add(Me.BotStrRailCutL)
        Me.GroupBox2.Controls.Add(Me.Label10)
        Me.GroupBox2.Location = New System.Drawing.Point(525, 429)
        Me.GroupBox2.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Padding = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.GroupBox2.Size = New System.Drawing.Size(120, 84)
        Me.GroupBox2.TabIndex = 65
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Bottom Railing"
        '
        'BotStrRailPicSpace
        '
        Me.BotStrRailPicSpace.AutoSize = True
        Me.BotStrRailPicSpace.Location = New System.Drawing.Point(79, 65)
        Me.BotStrRailPicSpace.Name = "BotStrRailPicSpace"
        Me.BotStrRailPicSpace.Size = New System.Drawing.Size(34, 13)
        Me.BotStrRailPicSpace.TabIndex = 136
        Me.BotStrRailPicSpace.Text = "0.000"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(16, 16)
        Me.Label4.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(59, 13)
        Me.Label4.TabIndex = 97
        Me.Label4.Text = "Cut Length"
        '
        'BotRailHole
        '
        Me.BotRailHole.AutoSize = True
        Me.BotRailHole.Location = New System.Drawing.Point(79, 32)
        Me.BotRailHole.Name = "BotRailHole"
        Me.BotRailHole.Size = New System.Drawing.Size(34, 13)
        Me.BotRailHole.TabIndex = 135
        Me.BotRailHole.Text = "0.000"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(16, 64)
        Me.Label8.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(46, 13)
        Me.Label8.TabIndex = 100
        Me.Label8.Text = "Spacing"
        '
        'BotStrRailDisFirstHole
        '
        Me.BotStrRailDisFirstHole.AutoSize = True
        Me.BotStrRailDisFirstHole.Location = New System.Drawing.Point(79, 49)
        Me.BotStrRailDisFirstHole.Name = "BotStrRailDisFirstHole"
        Me.BotStrRailDisFirstHole.Size = New System.Drawing.Size(34, 13)
        Me.BotStrRailDisFirstHole.TabIndex = 134
        Me.BotStrRailDisFirstHole.Text = "0.000"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(16, 32)
        Me.Label9.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(52, 13)
        Me.Label9.TabIndex = 98
        Me.Label9.Text = "Hole Size"
        '
        'BotStrRailCutL
        '
        Me.BotStrRailCutL.AutoSize = True
        Me.BotStrRailCutL.Location = New System.Drawing.Point(79, 15)
        Me.BotStrRailCutL.Name = "BotStrRailCutL"
        Me.BotStrRailCutL.Size = New System.Drawing.Size(34, 13)
        Me.BotStrRailCutL.TabIndex = 133
        Me.BotStrRailCutL.Text = "0.000"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(16, 48)
        Me.Label10.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(51, 13)
        Me.Label10.TabIndex = 99
        Me.Label10.Text = "First Hole"
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.Location = New System.Drawing.Point(348, 34)
        Me.Label24.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(125, 13)
        Me.Label24.TabIndex = 140
        Me.Label24.Text = "Post Hole Clearance Inc."
        '
        'HoleClearanceInc
        '
        Me.HoleClearanceInc.Location = New System.Drawing.Point(310, 30)
        Me.HoleClearanceInc.Name = "HoleClearanceInc"
        Me.HoleClearanceInc.Size = New System.Drawing.Size(35, 20)
        Me.HoleClearanceInc.TabIndex = 139
        Me.HoleClearanceInc.Text = ".75"
        Me.HoleClearanceInc.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(226, 76)
        Me.Label13.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(80, 13)
        Me.Label13.TabIndex = 138
        Me.Label13.Text = "Amt in Gnd Inc,"
        '
        'AmtInGroundInc
        '
        Me.AmtInGroundInc.Location = New System.Drawing.Point(189, 72)
        Me.AmtInGroundInc.Name = "AmtInGroundInc"
        Me.AmtInGroundInc.Size = New System.Drawing.Size(35, 20)
        Me.AmtInGroundInc.TabIndex = 137
        Me.AmtInGroundInc.Text = ".75"
        Me.AmtInGroundInc.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(105, 54)
        Me.Label12.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(79, 13)
        Me.Label12.TabIndex = 136
        Me.Label12.Text = "DeckEdge Inc."
        '
        'DeckEdgeIncrement
        '
        Me.DeckEdgeIncrement.Location = New System.Drawing.Point(68, 51)
        Me.DeckEdgeIncrement.Name = "DeckEdgeIncrement"
        Me.DeckEdgeIncrement.Size = New System.Drawing.Size(35, 20)
        Me.DeckEdgeIncrement.TabIndex = 135
        Me.DeckEdgeIncrement.Text = ".01"
        Me.DeckEdgeIncrement.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(105, 33)
        Me.Label1.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(78, 13)
        Me.Label1.TabIndex = 134
        Me.Label1.Text = "Step Edge Inc."
        '
        'StepEdgeIncrement
        '
        Me.StepEdgeIncrement.Location = New System.Drawing.Point(68, 30)
        Me.StepEdgeIncrement.Name = "StepEdgeIncrement"
        Me.StepEdgeIncrement.Size = New System.Drawing.Size(35, 20)
        Me.StepEdgeIncrement.TabIndex = 133
        Me.StepEdgeIncrement.Text = ".01"
        Me.StepEdgeIncrement.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label42
        '
        Me.Label42.AutoSize = True
        Me.Label42.Location = New System.Drawing.Point(105, 12)
        Me.Label42.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label42.Name = "Label42"
        Me.Label42.Size = New System.Drawing.Size(50, 13)
        Me.Label42.TabIndex = 132
        Me.Label42.Text = "DPS Inc."
        '
        'DPSIncrement
        '
        Me.DPSIncrement.Location = New System.Drawing.Point(68, 9)
        Me.DPSIncrement.Name = "DPSIncrement"
        Me.DPSIncrement.Size = New System.Drawing.Size(35, 20)
        Me.DPSIncrement.TabIndex = 131
        Me.DPSIncrement.Text = ".01"
        Me.DPSIncrement.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label44
        '
        Me.Label44.AutoSize = True
        Me.Label44.Location = New System.Drawing.Point(226, 55)
        Me.Label44.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label44.Name = "Label44"
        Me.Label44.Size = New System.Drawing.Size(50, 13)
        Me.Label44.TabIndex = 130
        Me.Label44.Text = "DTB Inc."
        '
        'DTBIncrement
        '
        Me.DTBIncrement.Location = New System.Drawing.Point(189, 51)
        Me.DTBIncrement.Name = "DTBIncrement"
        Me.DTBIncrement.Size = New System.Drawing.Size(35, 20)
        Me.DTBIncrement.TabIndex = 129
        Me.DTBIncrement.Text = ".75"
        Me.DTBIncrement.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label43
        '
        Me.Label43.AutoSize = True
        Me.Label43.Location = New System.Drawing.Point(105, 75)
        Me.Label43.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label43.Name = "Label43"
        Me.Label43.Size = New System.Drawing.Size(49, 13)
        Me.Label43.TabIndex = 128
        Me.Label43.Text = "DFT Inc."
        '
        'DFTIncrement
        '
        Me.DFTIncrement.Location = New System.Drawing.Point(68, 72)
        Me.DFTIncrement.Name = "DFTIncrement"
        Me.DFTIncrement.Size = New System.Drawing.Size(35, 20)
        Me.DFTIncrement.TabIndex = 127
        Me.DFTIncrement.Text = ".5"
        Me.DFTIncrement.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'label99
        '
        Me.label99.AutoSize = True
        Me.label99.Location = New System.Drawing.Point(226, 34)
        Me.label99.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.label99.Name = "label99"
        Me.label99.Size = New System.Drawing.Size(80, 13)
        Me.label99.TabIndex = 126
        Me.label99.Text = "Rail Height Inc."
        '
        'RailHeightIncrement
        '
        Me.RailHeightIncrement.Location = New System.Drawing.Point(189, 30)
        Me.RailHeightIncrement.Name = "RailHeightIncrement"
        Me.RailHeightIncrement.Size = New System.Drawing.Size(35, 20)
        Me.RailHeightIncrement.TabIndex = 125
        Me.RailHeightIncrement.Text = "1"
        Me.RailHeightIncrement.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'PicketsDB
        '
        Me.PicketsDB.Location = New System.Drawing.Point(5, 64)
        Me.PicketsDB.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.PicketsDB.Name = "PicketsDB"
        Me.PicketsDB.Size = New System.Drawing.Size(58, 23)
        Me.PicketsDB.TabIndex = 124
        Me.PicketsDB.Text = "Pickets"
        Me.PicketsDB.UseVisualStyleBackColor = True
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Location = New System.Drawing.Point(226, 13)
        Me.Label19.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(46, 13)
        Me.Label19.TabIndex = 123
        Me.Label19.Text = "IBD Inc."
        '
        'IBDIncrement
        '
        Me.IBDIncrement.Location = New System.Drawing.Point(189, 9)
        Me.IBDIncrement.Name = "IBDIncrement"
        Me.IBDIncrement.Size = New System.Drawing.Size(35, 20)
        Me.IBDIncrement.TabIndex = 122
        Me.IBDIncrement.Text = ".125"
        Me.IBDIncrement.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'PicketClear
        '
        Me.PicketClear.Location = New System.Drawing.Point(310, 51)
        Me.PicketClear.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.PicketClear.Name = "PicketClear"
        Me.PicketClear.Size = New System.Drawing.Size(35, 20)
        Me.PicketClear.TabIndex = 12
        Me.PicketClear.Text = ".625"
        Me.PicketClear.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'PostDB
        '
        Me.PostDB.Location = New System.Drawing.Point(5, 35)
        Me.PostDB.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.PostDB.Name = "PostDB"
        Me.PostDB.Size = New System.Drawing.Size(58, 23)
        Me.PostDB.TabIndex = 1
        Me.PostDB.Text = "Posts"
        Me.PostDB.UseVisualStyleBackColor = True
        '
        'RailingDB
        '
        Me.RailingDB.Location = New System.Drawing.Point(5, 7)
        Me.RailingDB.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.RailingDB.Name = "RailingDB"
        Me.RailingDB.Size = New System.Drawing.Size(58, 23)
        Me.RailingDB.TabIndex = 0
        Me.RailingDB.Text = "Railings"
        Me.RailingDB.UseVisualStyleBackColor = True
        '
        'ExtraEndMat
        '
        Me.ExtraEndMat.Location = New System.Drawing.Point(310, 9)
        Me.ExtraEndMat.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.ExtraEndMat.Name = "ExtraEndMat"
        Me.ExtraEndMat.Size = New System.Drawing.Size(35, 20)
        Me.ExtraEndMat.TabIndex = 17
        Me.ExtraEndMat.Text = "1"
        Me.ExtraEndMat.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(348, 13)
        Me.Label6.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(93, 13)
        Me.Label6.TabIndex = 106
        Me.Label6.Text = "Extra End Material"
        '
        'Label35
        '
        Me.Label35.AutoSize = True
        Me.Label35.Location = New System.Drawing.Point(348, 55)
        Me.Label35.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label35.Name = "Label35"
        Me.Label35.Size = New System.Drawing.Size(88, 13)
        Me.Label35.TabIndex = 55
        Me.Label35.Text = "Picket Clearance"
        '
        'Options
        '
        Me.Options.Controls.Add(Me.AmtInGroundDownSel)
        Me.Options.Controls.Add(Me.AmtInGroundUpSel)
        Me.Options.Controls.Add(Me.PostBelowGround)
        Me.Options.Location = New System.Drawing.Point(245, 6)
        Me.Options.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.Options.Name = "Options"
        Me.Options.Padding = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.Options.Size = New System.Drawing.Size(115, 43)
        Me.Options.TabIndex = 125
        Me.Options.TabStop = False
        Me.Options.Text = "Amount In Ground"
        '
        'AmtInGroundDownSel
        '
        Me.AmtInGroundDownSel.BackColor = System.Drawing.Color.White
        Me.AmtInGroundDownSel.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.AmtInGroundDownSel.FlatAppearance.BorderSize = 0
        Me.AmtInGroundDownSel.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.AmtInGroundDownSel.Location = New System.Drawing.Point(12, 17)
        Me.AmtInGroundDownSel.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.AmtInGroundDownSel.Name = "AmtInGroundDownSel"
        Me.AmtInGroundDownSel.Size = New System.Drawing.Size(20, 20)
        Me.AmtInGroundDownSel.TabIndex = 148
        Me.AmtInGroundDownSel.Text = "<"
        Me.AmtInGroundDownSel.UseVisualStyleBackColor = False
        '
        'AmtInGroundUpSel
        '
        Me.AmtInGroundUpSel.BackColor = System.Drawing.Color.White
        Me.AmtInGroundUpSel.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.AmtInGroundUpSel.Location = New System.Drawing.Point(31, 17)
        Me.AmtInGroundUpSel.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.AmtInGroundUpSel.Name = "AmtInGroundUpSel"
        Me.AmtInGroundUpSel.Size = New System.Drawing.Size(20, 20)
        Me.AmtInGroundUpSel.TabIndex = 149
        Me.AmtInGroundUpSel.Text = ">"
        Me.AmtInGroundUpSel.UseVisualStyleBackColor = False
        '
        'PostBelowGround
        '
        Me.PostBelowGround.Location = New System.Drawing.Point(57, 17)
        Me.PostBelowGround.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.PostBelowGround.Name = "PostBelowGround"
        Me.PostBelowGround.Size = New System.Drawing.Size(44, 20)
        Me.PostBelowGround.TabIndex = 116
        Me.PostBelowGround.Text = "0"
        Me.PostBelowGround.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'PostHoleClearance
        '
        Me.PostHoleClearance.Location = New System.Drawing.Point(58, 15)
        Me.PostHoleClearance.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.PostHoleClearance.Name = "PostHoleClearance"
        Me.PostHoleClearance.Size = New System.Drawing.Size(44, 20)
        Me.PostHoleClearance.TabIndex = 117
        Me.PostHoleClearance.Text = "0"
        Me.PostHoleClearance.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label2
        '
        Me.Label2.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.Transparent
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(45, 16)
        Me.Label2.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(32, 25)
        Me.Label2.TabIndex = 98
        Me.Label2.Tag = "input1"
        Me.Label2.Text = "-.-"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'AngleRef
        '
        Me.AngleRef.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.AngleRef.AutoSize = True
        Me.AngleRef.BackColor = System.Drawing.Color.Transparent
        Me.AngleRef.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.AngleRef.Location = New System.Drawing.Point(45, 13)
        Me.AngleRef.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.AngleRef.Name = "AngleRef"
        Me.AngleRef.Size = New System.Drawing.Size(32, 25)
        Me.AngleRef.TabIndex = 98
        Me.AngleRef.Tag = "input1"
        Me.AngleRef.Text = "-.-"
        Me.AngleRef.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'StairCalc
        '
        Me.StairCalc.Location = New System.Drawing.Point(361, 459)
        Me.StairCalc.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.StairCalc.Name = "StairCalc"
        Me.StairCalc.Size = New System.Drawing.Size(72, 23)
        Me.StairCalc.TabIndex = 74
        Me.StairCalc.Text = "Calculate"
        Me.StairCalc.UseVisualStyleBackColor = True
        '
        'StairReset
        '
        Me.StairReset.Location = New System.Drawing.Point(439, 459)
        Me.StairReset.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.StairReset.Name = "StairReset"
        Me.StairReset.Size = New System.Drawing.Size(74, 23)
        Me.StairReset.TabIndex = 75
        Me.StairReset.Text = "Reset"
        Me.StairReset.UseVisualStyleBackColor = True
        '
        'PostOptions
        '
        Me.PostOptions.Controls.Add(Me.PostHeight)
        Me.PostOptions.Controls.Add(Me.Label14)
        Me.PostOptions.Controls.Add(Me.PostThick)
        Me.PostOptions.Controls.Add(Me.Label16)
        Me.PostOptions.Controls.Add(Me.ComboBox3)
        Me.PostOptions.Controls.Add(Me.PostWidth)
        Me.PostOptions.Controls.Add(Me.Label15)
        Me.PostOptions.Location = New System.Drawing.Point(5, 6)
        Me.PostOptions.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.PostOptions.Name = "PostOptions"
        Me.PostOptions.Padding = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.PostOptions.Size = New System.Drawing.Size(110, 101)
        Me.PostOptions.TabIndex = 82
        Me.PostOptions.TabStop = False
        Me.PostOptions.Text = "Post Type"
        '
        'PostHeight
        '
        Me.PostHeight.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.PoLibBindingSource, "Height", True))
        Me.PostHeight.Location = New System.Drawing.Point(6, 35)
        Me.PostHeight.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.PostHeight.Name = "PostHeight"
        Me.PostHeight.Size = New System.Drawing.Size(44, 20)
        Me.PostHeight.TabIndex = 6
        Me.PostHeight.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'PoLibBindingSource
        '
        Me.PoLibBindingSource.DataMember = "PoLib"
        Me.PoLibBindingSource.DataSource = Me.PostsDBDataSet1
        '
        'PostsDBDataSet1
        '
        Me.PostsDBDataSet1.DataSetName = "PostsDBDataSet1"
        Me.PostsDBDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(52, 59)
        Me.Label14.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(35, 13)
        Me.Label14.TabIndex = 102
        Me.Label14.Text = "Width"
        '
        'PostThick
        '
        Me.PostThick.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.PoLibBindingSource, "Thickness", True))
        Me.PostThick.Location = New System.Drawing.Point(6, 75)
        Me.PostThick.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.PostThick.Name = "PostThick"
        Me.PostThick.Size = New System.Drawing.Size(44, 20)
        Me.PostThick.TabIndex = 8
        Me.PostThick.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(52, 39)
        Me.Label16.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(38, 13)
        Me.Label16.TabIndex = 95
        Me.Label16.Text = "Height"
        '
        'ComboBox3
        '
        Me.ComboBox3.DataSource = Me.PoLibBindingSource
        Me.ComboBox3.DisplayMember = "ID"
        Me.ComboBox3.DropDownWidth = 66
        Me.ComboBox3.FormattingEnabled = True
        Me.ComboBox3.Location = New System.Drawing.Point(5, 14)
        Me.ComboBox3.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.ComboBox3.Name = "ComboBox3"
        Me.ComboBox3.Size = New System.Drawing.Size(77, 21)
        Me.ComboBox3.TabIndex = 5
        '
        'PostWidth
        '
        Me.PostWidth.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.PoLibBindingSource, "Width", True))
        Me.PostWidth.Location = New System.Drawing.Point(6, 55)
        Me.PostWidth.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.PostWidth.Name = "PostWidth"
        Me.PostWidth.Size = New System.Drawing.Size(44, 20)
        Me.PostWidth.TabIndex = 7
        Me.PostWidth.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(52, 79)
        Me.Label15.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(56, 13)
        Me.Label15.TabIndex = 96
        Me.Label15.Text = "Thickness"
        '
        'GroupBox15
        '
        Me.GroupBox15.Controls.Add(Me.ComboBox1)
        Me.GroupBox15.Controls.Add(Me.Label5)
        Me.GroupBox15.Controls.Add(Me.TopRailHeight)
        Me.GroupBox15.Controls.Add(Me.Label7)
        Me.GroupBox15.Controls.Add(Me.Label11)
        Me.GroupBox15.Controls.Add(Me.TopRailThick)
        Me.GroupBox15.Controls.Add(Me.TopRailWidth)
        Me.GroupBox15.Location = New System.Drawing.Point(117, 7)
        Me.GroupBox15.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.GroupBox15.Name = "GroupBox15"
        Me.GroupBox15.Padding = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.GroupBox15.Size = New System.Drawing.Size(110, 101)
        Me.GroupBox15.TabIndex = 71
        Me.GroupBox15.TabStop = False
        Me.GroupBox15.Text = "Top Rail"
        '
        'ComboBox1
        '
        Me.ComboBox1.DataSource = Me.TopRaLibBindingSource
        Me.ComboBox1.DisplayMember = "ID"
        Me.ComboBox1.FormattingEnabled = True
        Me.ComboBox1.Location = New System.Drawing.Point(5, 14)
        Me.ComboBox1.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.ComboBox1.Name = "ComboBox1"
        Me.ComboBox1.Size = New System.Drawing.Size(77, 21)
        Me.ComboBox1.TabIndex = 13
        '
        'TopRaLibBindingSource
        '
        Me.TopRaLibBindingSource.DataMember = "RaLib"
        Me.TopRaLibBindingSource.DataSource = Me.TopRailsDataSet
        '
        'TopRailsDataSet
        '
        Me.TopRailsDataSet.DataSetName = "TopRailsDataSet"
        Me.TopRailsDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(52, 59)
        Me.Label5.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(35, 13)
        Me.Label5.TabIndex = 107
        Me.Label5.Text = "Width"
        '
        'TopRailHeight
        '
        Me.TopRailHeight.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TopRaLibBindingSource, "Height", True))
        Me.TopRailHeight.Location = New System.Drawing.Point(6, 35)
        Me.TopRailHeight.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.TopRailHeight.Name = "TopRailHeight"
        Me.TopRailHeight.Size = New System.Drawing.Size(44, 20)
        Me.TopRailHeight.TabIndex = 14
        Me.TopRailHeight.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(52, 39)
        Me.Label7.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(38, 13)
        Me.Label7.TabIndex = 104
        Me.Label7.Text = "Height"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(52, 79)
        Me.Label11.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(56, 13)
        Me.Label11.TabIndex = 105
        Me.Label11.Text = "Thickness"
        '
        'TopRailThick
        '
        Me.TopRailThick.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TopRaLibBindingSource, "Thickness", True))
        Me.TopRailThick.Location = New System.Drawing.Point(6, 75)
        Me.TopRailThick.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.TopRailThick.Name = "TopRailThick"
        Me.TopRailThick.Size = New System.Drawing.Size(44, 20)
        Me.TopRailThick.TabIndex = 16
        Me.TopRailThick.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'TopRailWidth
        '
        Me.TopRailWidth.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TopRaLibBindingSource, "Width", True))
        Me.TopRailWidth.Location = New System.Drawing.Point(6, 55)
        Me.TopRailWidth.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.TopRailWidth.Name = "TopRailWidth"
        Me.TopRailWidth.Size = New System.Drawing.Size(44, 20)
        Me.TopRailWidth.TabIndex = 15
        Me.TopRailWidth.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'GroupBox6
        '
        Me.GroupBox6.BackColor = System.Drawing.Color.Transparent
        Me.GroupBox6.Controls.Add(Me.BotRailWidth)
        Me.GroupBox6.Controls.Add(Me.Label18)
        Me.GroupBox6.Controls.Add(Me.BotRailThick)
        Me.GroupBox6.Controls.Add(Me.ComboBox2)
        Me.GroupBox6.Controls.Add(Me.Label32)
        Me.GroupBox6.Controls.Add(Me.Label33)
        Me.GroupBox6.Controls.Add(Me.BotRailHeight)
        Me.GroupBox6.Location = New System.Drawing.Point(231, 7)
        Me.GroupBox6.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.GroupBox6.Name = "GroupBox6"
        Me.GroupBox6.Padding = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.GroupBox6.Size = New System.Drawing.Size(110, 101)
        Me.GroupBox6.TabIndex = 72
        Me.GroupBox6.TabStop = False
        Me.GroupBox6.Text = "Bottom Rail"
        '
        'BotRailWidth
        '
        Me.BotRailWidth.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.BotRaLibBindingSource, "Width", True))
        Me.BotRailWidth.Location = New System.Drawing.Point(6, 55)
        Me.BotRailWidth.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.BotRailWidth.Name = "BotRailWidth"
        Me.BotRailWidth.Size = New System.Drawing.Size(44, 20)
        Me.BotRailWidth.TabIndex = 20
        Me.BotRailWidth.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'BotRaLibBindingSource
        '
        Me.BotRaLibBindingSource.DataMember = "RaLib"
        Me.BotRaLibBindingSource.DataSource = Me.BottomRailsDBDataSet
        '
        'BottomRailsDBDataSet
        '
        Me.BottomRailsDBDataSet.DataSetName = "BottomRailsDBDataSet"
        Me.BottomRailsDBDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Location = New System.Drawing.Point(52, 59)
        Me.Label18.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(35, 13)
        Me.Label18.TabIndex = 121
        Me.Label18.Text = "Width"
        '
        'BotRailThick
        '
        Me.BotRailThick.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.BotRaLibBindingSource, "Thickness", True))
        Me.BotRailThick.Location = New System.Drawing.Point(6, 75)
        Me.BotRailThick.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.BotRailThick.Name = "BotRailThick"
        Me.BotRailThick.Size = New System.Drawing.Size(44, 20)
        Me.BotRailThick.TabIndex = 21
        Me.BotRailThick.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'ComboBox2
        '
        Me.ComboBox2.DataSource = Me.BotRaLibBindingSource
        Me.ComboBox2.DisplayMember = "ID"
        Me.ComboBox2.FormattingEnabled = True
        Me.ComboBox2.Location = New System.Drawing.Point(5, 14)
        Me.ComboBox2.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.ComboBox2.Name = "ComboBox2"
        Me.ComboBox2.Size = New System.Drawing.Size(77, 21)
        Me.ComboBox2.TabIndex = 18
        '
        'Label32
        '
        Me.Label32.AutoSize = True
        Me.Label32.Location = New System.Drawing.Point(52, 39)
        Me.Label32.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label32.Name = "Label32"
        Me.Label32.Size = New System.Drawing.Size(38, 13)
        Me.Label32.TabIndex = 118
        Me.Label32.Text = "Height"
        '
        'Label33
        '
        Me.Label33.AutoSize = True
        Me.Label33.Location = New System.Drawing.Point(52, 79)
        Me.Label33.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(56, 13)
        Me.Label33.TabIndex = 119
        Me.Label33.Text = "Thickness"
        '
        'BotRailHeight
        '
        Me.BotRailHeight.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.BotRaLibBindingSource, "Height", True))
        Me.BotRailHeight.Location = New System.Drawing.Point(6, 35)
        Me.BotRailHeight.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.BotRailHeight.Name = "BotRailHeight"
        Me.BotRailHeight.Size = New System.Drawing.Size(44, 20)
        Me.BotRailHeight.TabIndex = 19
        Me.BotRailHeight.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'GroupBox7
        '
        Me.GroupBox7.Controls.Add(Me.PicketComboBox)
        Me.GroupBox7.Controls.Add(Me.PicketHeight)
        Me.GroupBox7.Controls.Add(Me.Label22)
        Me.GroupBox7.Controls.Add(Me.Label21)
        Me.GroupBox7.Controls.Add(Me.PicketWidth)
        Me.GroupBox7.Controls.Add(Me.PicketThick)
        Me.GroupBox7.Controls.Add(Me.Label20)
        Me.GroupBox7.Location = New System.Drawing.Point(5, 6)
        Me.GroupBox7.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.GroupBox7.Name = "GroupBox7"
        Me.GroupBox7.Padding = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.GroupBox7.Size = New System.Drawing.Size(110, 101)
        Me.GroupBox7.TabIndex = 70
        Me.GroupBox7.TabStop = False
        Me.GroupBox7.Text = "Picket Type"
        '
        'PicketComboBox
        '
        Me.PicketComboBox.DataSource = Me.PicketLibBindingSource
        Me.PicketComboBox.DisplayMember = "ID"
        Me.PicketComboBox.DropDownWidth = 66
        Me.PicketComboBox.FormattingEnabled = True
        Me.PicketComboBox.Location = New System.Drawing.Point(5, 14)
        Me.PicketComboBox.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.PicketComboBox.Name = "PicketComboBox"
        Me.PicketComboBox.Size = New System.Drawing.Size(77, 21)
        Me.PicketComboBox.TabIndex = 104
        '
        'PicketLibBindingSource
        '
        Me.PicketLibBindingSource.DataMember = "PicketLib"
        Me.PicketLibBindingSource.DataSource = Me.PicketsDataSet
        '
        'PicketsDataSet
        '
        Me.PicketsDataSet.DataSetName = "PicketsDataSet"
        Me.PicketsDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'PicketHeight
        '
        Me.PicketHeight.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.PicketLibBindingSource, "Height", True))
        Me.PicketHeight.Location = New System.Drawing.Point(6, 35)
        Me.PicketHeight.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.PicketHeight.Name = "PicketHeight"
        Me.PicketHeight.Size = New System.Drawing.Size(44, 20)
        Me.PicketHeight.TabIndex = 123
        Me.PicketHeight.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Location = New System.Drawing.Point(52, 79)
        Me.Label22.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(56, 13)
        Me.Label22.TabIndex = 127
        Me.Label22.Text = "Thickness"
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Location = New System.Drawing.Point(52, 39)
        Me.Label21.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(38, 13)
        Me.Label21.TabIndex = 126
        Me.Label21.Text = "Height"
        '
        'PicketWidth
        '
        Me.PicketWidth.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.PicketLibBindingSource, "Width", True))
        Me.PicketWidth.Location = New System.Drawing.Point(6, 55)
        Me.PicketWidth.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.PicketWidth.Name = "PicketWidth"
        Me.PicketWidth.Size = New System.Drawing.Size(44, 20)
        Me.PicketWidth.TabIndex = 124
        Me.PicketWidth.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'PicketThick
        '
        Me.PicketThick.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.PicketLibBindingSource, "Thickness", True))
        Me.PicketThick.Location = New System.Drawing.Point(6, 75)
        Me.PicketThick.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.PicketThick.Name = "PicketThick"
        Me.PicketThick.Size = New System.Drawing.Size(44, 20)
        Me.PicketThick.TabIndex = 125
        Me.PicketThick.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Location = New System.Drawing.Point(52, 59)
        Me.Label20.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(35, 13)
        Me.Label20.TabIndex = 128
        Me.Label20.Text = "Width"
        '
        'DesPicketSpc
        '
        Me.DesPicketSpc.Location = New System.Drawing.Point(54, 16)
        Me.DesPicketSpc.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.DesPicketSpc.Name = "DesPicketSpc"
        Me.DesPicketSpc.Size = New System.Drawing.Size(44, 20)
        Me.DesPicketSpc.TabIndex = 11
        Me.DesPicketSpc.Text = "3.5"
        Me.DesPicketSpc.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'DistanceToBottom
        '
        Me.DistanceToBottom.Location = New System.Drawing.Point(54, 15)
        Me.DistanceToBottom.Name = "DistanceToBottom"
        Me.DistanceToBottom.Size = New System.Drawing.Size(44, 20)
        Me.DistanceToBottom.TabIndex = 138
        '
        'DistanceFromTop
        '
        Me.DistanceFromTop.Location = New System.Drawing.Point(54, 16)
        Me.DistanceFromTop.Name = "DistanceFromTop"
        Me.DistanceFromTop.Size = New System.Drawing.Size(44, 20)
        Me.DistanceFromTop.TabIndex = 135
        '
        'InBetweenDistance
        '
        Me.InBetweenDistance.Location = New System.Drawing.Point(52, 16)
        Me.InBetweenDistance.Name = "InBetweenDistance"
        Me.InBetweenDistance.Size = New System.Drawing.Size(50, 20)
        Me.InBetweenDistance.TabIndex = 132
        '
        'RailHeight
        '
        Me.RailHeight.Location = New System.Drawing.Point(53, 16)
        Me.RailHeight.Name = "RailHeight"
        Me.RailHeight.Size = New System.Drawing.Size(50, 20)
        Me.RailHeight.TabIndex = 129
        '
        'TabControl2
        '
        Me.TabControl2.Controls.Add(Me.TabPage3)
        Me.TabControl2.Controls.Add(Me.TabPage4)
        Me.TabControl2.Controls.Add(Me.TabPage2)
        Me.TabControl2.Controls.Add(Me.TabPage1)
        Me.TabControl2.Location = New System.Drawing.Point(7, 153)
        Me.TabControl2.Name = "TabControl2"
        Me.TabControl2.SelectedIndex = 0
        Me.TabControl2.Size = New System.Drawing.Size(512, 142)
        Me.TabControl2.TabIndex = 119
        '
        'TabPage3
        '
        Me.TabPage3.Controls.Add(Me.GroupBox11)
        Me.TabPage3.Controls.Add(Me.GroupBox10)
        Me.TabPage3.Controls.Add(Me.GroupBox15)
        Me.TabPage3.Controls.Add(Me.GroupBox6)
        Me.TabPage3.Location = New System.Drawing.Point(4, 22)
        Me.TabPage3.Name = "TabPage3"
        Me.TabPage3.Size = New System.Drawing.Size(504, 116)
        Me.TabPage3.TabIndex = 2
        Me.TabPage3.Text = "Railing"
        Me.TabPage3.UseVisualStyleBackColor = True
        '
        'GroupBox11
        '
        Me.GroupBox11.Controls.Add(Me.InbetweenDistanceDownSelect)
        Me.GroupBox11.Controls.Add(Me.InBetweenDistanceUpSelect)
        Me.GroupBox11.Controls.Add(Me.CheckBox2)
        Me.GroupBox11.Controls.Add(Me.InBetweenDistance)
        Me.GroupBox11.Location = New System.Drawing.Point(5, 49)
        Me.GroupBox11.Name = "GroupBox11"
        Me.GroupBox11.Size = New System.Drawing.Size(107, 59)
        Me.GroupBox11.TabIndex = 137
        Me.GroupBox11.TabStop = False
        Me.GroupBox11.Text = "Section Length"
        '
        'InbetweenDistanceDownSelect
        '
        Me.InbetweenDistanceDownSelect.BackColor = System.Drawing.Color.White
        Me.InbetweenDistanceDownSelect.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.InbetweenDistanceDownSelect.FlatAppearance.BorderSize = 0
        Me.InbetweenDistanceDownSelect.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.InbetweenDistanceDownSelect.Location = New System.Drawing.Point(5, 16)
        Me.InbetweenDistanceDownSelect.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.InbetweenDistanceDownSelect.Name = "InbetweenDistanceDownSelect"
        Me.InbetweenDistanceDownSelect.Size = New System.Drawing.Size(20, 20)
        Me.InbetweenDistanceDownSelect.TabIndex = 131
        Me.InbetweenDistanceDownSelect.Text = "<"
        Me.InbetweenDistanceDownSelect.UseVisualStyleBackColor = False
        '
        'InBetweenDistanceUpSelect
        '
        Me.InBetweenDistanceUpSelect.BackColor = System.Drawing.Color.White
        Me.InBetweenDistanceUpSelect.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.InBetweenDistanceUpSelect.Location = New System.Drawing.Point(24, 16)
        Me.InBetweenDistanceUpSelect.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.InBetweenDistanceUpSelect.Name = "InBetweenDistanceUpSelect"
        Me.InBetweenDistanceUpSelect.Size = New System.Drawing.Size(20, 20)
        Me.InBetweenDistanceUpSelect.TabIndex = 130
        Me.InBetweenDistanceUpSelect.Text = ">"
        Me.InBetweenDistanceUpSelect.UseVisualStyleBackColor = False
        '
        'CheckBox2
        '
        Me.CheckBox2.AutoSize = True
        Me.CheckBox2.Checked = True
        Me.CheckBox2.CheckState = System.Windows.Forms.CheckState.Checked
        Me.CheckBox2.Location = New System.Drawing.Point(7, 38)
        Me.CheckBox2.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.CheckBox2.Name = "CheckBox2"
        Me.CheckBox2.Size = New System.Drawing.Size(82, 17)
        Me.CheckBox2.TabIndex = 135
        Me.CheckBox2.Text = "Aligned IBD"
        Me.CheckBox2.UseVisualStyleBackColor = True
        '
        'GroupBox10
        '
        Me.GroupBox10.Controls.Add(Me.RailHeightDownSelect)
        Me.GroupBox10.Controls.Add(Me.RailHeight)
        Me.GroupBox10.Controls.Add(Me.RailHeightUpSelect)
        Me.GroupBox10.Location = New System.Drawing.Point(5, 7)
        Me.GroupBox10.Name = "GroupBox10"
        Me.GroupBox10.Size = New System.Drawing.Size(107, 43)
        Me.GroupBox10.TabIndex = 136
        Me.GroupBox10.TabStop = False
        Me.GroupBox10.Text = "Railing Height"
        '
        'RailHeightDownSelect
        '
        Me.RailHeightDownSelect.BackColor = System.Drawing.Color.White
        Me.RailHeightDownSelect.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.RailHeightDownSelect.Cursor = System.Windows.Forms.Cursors.Default
        Me.RailHeightDownSelect.FlatAppearance.BorderSize = 0
        Me.RailHeightDownSelect.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RailHeightDownSelect.Location = New System.Drawing.Point(6, 16)
        Me.RailHeightDownSelect.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.RailHeightDownSelect.Name = "RailHeightDownSelect"
        Me.RailHeightDownSelect.Size = New System.Drawing.Size(20, 20)
        Me.RailHeightDownSelect.TabIndex = 128
        Me.RailHeightDownSelect.Text = "<"
        Me.RailHeightDownSelect.UseVisualStyleBackColor = False
        '
        'RailHeightUpSelect
        '
        Me.RailHeightUpSelect.BackColor = System.Drawing.Color.White
        Me.RailHeightUpSelect.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.RailHeightUpSelect.Cursor = System.Windows.Forms.Cursors.Default
        Me.RailHeightUpSelect.FlatAppearance.BorderSize = 0
        Me.RailHeightUpSelect.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RailHeightUpSelect.Location = New System.Drawing.Point(25, 16)
        Me.RailHeightUpSelect.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.RailHeightUpSelect.Name = "RailHeightUpSelect"
        Me.RailHeightUpSelect.Size = New System.Drawing.Size(20, 20)
        Me.RailHeightUpSelect.TabIndex = 134
        Me.RailHeightUpSelect.Text = ">"
        Me.RailHeightUpSelect.UseVisualStyleBackColor = False
        '
        'TabPage4
        '
        Me.TabPage4.Controls.Add(Me.GroupBox9)
        Me.TabPage4.Controls.Add(Me.GroupBox7)
        Me.TabPage4.Location = New System.Drawing.Point(4, 22)
        Me.TabPage4.Name = "TabPage4"
        Me.TabPage4.Size = New System.Drawing.Size(504, 116)
        Me.TabPage4.TabIndex = 3
        Me.TabPage4.Text = "Picket"
        Me.TabPage4.UseVisualStyleBackColor = True
        '
        'GroupBox9
        '
        Me.GroupBox9.Controls.Add(Me.PicSpaceDownSelect)
        Me.GroupBox9.Controls.Add(Me.PicSpaceUpSelect)
        Me.GroupBox9.Controls.Add(Me.DesPicketSpc)
        Me.GroupBox9.Location = New System.Drawing.Point(125, 6)
        Me.GroupBox9.Name = "GroupBox9"
        Me.GroupBox9.Size = New System.Drawing.Size(107, 43)
        Me.GroupBox9.TabIndex = 137
        Me.GroupBox9.TabStop = False
        Me.GroupBox9.Text = "Picket Spacing"
        '
        'PicSpaceDownSelect
        '
        Me.PicSpaceDownSelect.BackColor = System.Drawing.Color.White
        Me.PicSpaceDownSelect.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.PicSpaceDownSelect.Cursor = System.Windows.Forms.Cursors.Default
        Me.PicSpaceDownSelect.FlatAppearance.BorderSize = 0
        Me.PicSpaceDownSelect.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.PicSpaceDownSelect.Location = New System.Drawing.Point(7, 16)
        Me.PicSpaceDownSelect.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.PicSpaceDownSelect.Name = "PicSpaceDownSelect"
        Me.PicSpaceDownSelect.Size = New System.Drawing.Size(20, 20)
        Me.PicSpaceDownSelect.TabIndex = 135
        Me.PicSpaceDownSelect.Text = "<"
        Me.PicSpaceDownSelect.UseVisualStyleBackColor = False
        '
        'PicSpaceUpSelect
        '
        Me.PicSpaceUpSelect.BackColor = System.Drawing.Color.White
        Me.PicSpaceUpSelect.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.PicSpaceUpSelect.Cursor = System.Windows.Forms.Cursors.Default
        Me.PicSpaceUpSelect.FlatAppearance.BorderSize = 0
        Me.PicSpaceUpSelect.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.PicSpaceUpSelect.Location = New System.Drawing.Point(26, 16)
        Me.PicSpaceUpSelect.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.PicSpaceUpSelect.Name = "PicSpaceUpSelect"
        Me.PicSpaceUpSelect.Size = New System.Drawing.Size(20, 20)
        Me.PicSpaceUpSelect.TabIndex = 136
        Me.PicSpaceUpSelect.Text = ">"
        Me.PicSpaceUpSelect.UseVisualStyleBackColor = False
        '
        'TabPage2
        '
        Me.TabPage2.Controls.Add(Me.GroupBox17)
        Me.TabPage2.Controls.Add(Me.GroupBox16)
        Me.TabPage2.Controls.Add(Me.GroupBox20)
        Me.TabPage2.Controls.Add(Me.PostOptions)
        Me.TabPage2.Controls.Add(Me.Options)
        Me.TabPage2.Location = New System.Drawing.Point(4, 22)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(504, 116)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "Post"
        Me.TabPage2.UseVisualStyleBackColor = True
        '
        'GroupBox17
        '
        Me.GroupBox17.Controls.Add(Me.DistanceToBottom)
        Me.GroupBox17.Controls.Add(Me.DTBUpSelect)
        Me.GroupBox17.Controls.Add(Me.DTBDownSelect)
        Me.GroupBox17.Location = New System.Drawing.Point(125, 64)
        Me.GroupBox17.Name = "GroupBox17"
        Me.GroupBox17.Size = New System.Drawing.Size(115, 43)
        Me.GroupBox17.TabIndex = 122
        Me.GroupBox17.TabStop = False
        Me.GroupBox17.Text = "Dist To Bottom"
        '
        'DTBUpSelect
        '
        Me.DTBUpSelect.BackColor = System.Drawing.Color.White
        Me.DTBUpSelect.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DTBUpSelect.Location = New System.Drawing.Point(26, 15)
        Me.DTBUpSelect.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.DTBUpSelect.Name = "DTBUpSelect"
        Me.DTBUpSelect.Size = New System.Drawing.Size(20, 20)
        Me.DTBUpSelect.TabIndex = 136
        Me.DTBUpSelect.Text = ">"
        Me.DTBUpSelect.UseVisualStyleBackColor = False
        '
        'DTBDownSelect
        '
        Me.DTBDownSelect.BackColor = System.Drawing.Color.White
        Me.DTBDownSelect.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.DTBDownSelect.FlatAppearance.BorderSize = 0
        Me.DTBDownSelect.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DTBDownSelect.Location = New System.Drawing.Point(7, 15)
        Me.DTBDownSelect.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.DTBDownSelect.Name = "DTBDownSelect"
        Me.DTBDownSelect.Size = New System.Drawing.Size(20, 20)
        Me.DTBDownSelect.TabIndex = 137
        Me.DTBDownSelect.Text = "<"
        Me.DTBDownSelect.UseVisualStyleBackColor = False
        '
        'GroupBox16
        '
        Me.GroupBox16.Controls.Add(Me.DFTDownSelect)
        Me.GroupBox16.Controls.Add(Me.DistanceFromTop)
        Me.GroupBox16.Controls.Add(Me.DFTUpSelect)
        Me.GroupBox16.Location = New System.Drawing.Point(125, 6)
        Me.GroupBox16.Name = "GroupBox16"
        Me.GroupBox16.Size = New System.Drawing.Size(115, 43)
        Me.GroupBox16.TabIndex = 145
        Me.GroupBox16.TabStop = False
        Me.GroupBox16.Text = "Dist From Top"
        '
        'DFTDownSelect
        '
        Me.DFTDownSelect.BackColor = System.Drawing.Color.White
        Me.DFTDownSelect.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.DFTDownSelect.FlatAppearance.BorderSize = 0
        Me.DFTDownSelect.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DFTDownSelect.Location = New System.Drawing.Point(7, 16)
        Me.DFTDownSelect.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.DFTDownSelect.Name = "DFTDownSelect"
        Me.DFTDownSelect.Size = New System.Drawing.Size(20, 20)
        Me.DFTDownSelect.TabIndex = 134
        Me.DFTDownSelect.Text = "<"
        Me.DFTDownSelect.UseVisualStyleBackColor = False
        '
        'DFTUpSelect
        '
        Me.DFTUpSelect.BackColor = System.Drawing.Color.White
        Me.DFTUpSelect.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DFTUpSelect.Location = New System.Drawing.Point(26, 16)
        Me.DFTUpSelect.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.DFTUpSelect.Name = "DFTUpSelect"
        Me.DFTUpSelect.Size = New System.Drawing.Size(20, 20)
        Me.DFTUpSelect.TabIndex = 140
        Me.DFTUpSelect.Text = ">"
        Me.DFTUpSelect.UseVisualStyleBackColor = False
        '
        'GroupBox20
        '
        Me.GroupBox20.Controls.Add(Me.HoleClearanceDownSel)
        Me.GroupBox20.Controls.Add(Me.HoleClearanceUpSel)
        Me.GroupBox20.Controls.Add(Me.PostHoleClearance)
        Me.GroupBox20.Location = New System.Drawing.Point(245, 64)
        Me.GroupBox20.Name = "GroupBox20"
        Me.GroupBox20.Size = New System.Drawing.Size(115, 43)
        Me.GroupBox20.TabIndex = 122
        Me.GroupBox20.TabStop = False
        Me.GroupBox20.Text = "Hole Clearance"
        '
        'HoleClearanceDownSel
        '
        Me.HoleClearanceDownSel.BackColor = System.Drawing.Color.White
        Me.HoleClearanceDownSel.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.HoleClearanceDownSel.FlatAppearance.BorderSize = 0
        Me.HoleClearanceDownSel.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.HoleClearanceDownSel.Location = New System.Drawing.Point(12, 15)
        Me.HoleClearanceDownSel.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.HoleClearanceDownSel.Name = "HoleClearanceDownSel"
        Me.HoleClearanceDownSel.Size = New System.Drawing.Size(20, 20)
        Me.HoleClearanceDownSel.TabIndex = 148
        Me.HoleClearanceDownSel.Text = "<"
        Me.HoleClearanceDownSel.UseVisualStyleBackColor = False
        '
        'HoleClearanceUpSel
        '
        Me.HoleClearanceUpSel.BackColor = System.Drawing.Color.White
        Me.HoleClearanceUpSel.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.HoleClearanceUpSel.Location = New System.Drawing.Point(31, 15)
        Me.HoleClearanceUpSel.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.HoleClearanceUpSel.Name = "HoleClearanceUpSel"
        Me.HoleClearanceUpSel.Size = New System.Drawing.Size(20, 20)
        Me.HoleClearanceUpSel.TabIndex = 149
        Me.HoleClearanceUpSel.Text = ">"
        Me.HoleClearanceUpSel.UseVisualStyleBackColor = False
        '
        'TabPage1
        '
        Me.TabPage1.Controls.Add(Me.Label24)
        Me.TabPage1.Controls.Add(Me.RailingDB)
        Me.TabPage1.Controls.Add(Me.HoleClearanceInc)
        Me.TabPage1.Controls.Add(Me.Label35)
        Me.TabPage1.Controls.Add(Me.Label13)
        Me.TabPage1.Controls.Add(Me.Label6)
        Me.TabPage1.Controls.Add(Me.AmtInGroundInc)
        Me.TabPage1.Controls.Add(Me.ExtraEndMat)
        Me.TabPage1.Controls.Add(Me.Label12)
        Me.TabPage1.Controls.Add(Me.PostDB)
        Me.TabPage1.Controls.Add(Me.DeckEdgeIncrement)
        Me.TabPage1.Controls.Add(Me.PicketClear)
        Me.TabPage1.Controls.Add(Me.Label1)
        Me.TabPage1.Controls.Add(Me.IBDIncrement)
        Me.TabPage1.Controls.Add(Me.StepEdgeIncrement)
        Me.TabPage1.Controls.Add(Me.Label19)
        Me.TabPage1.Controls.Add(Me.Label42)
        Me.TabPage1.Controls.Add(Me.PicketsDB)
        Me.TabPage1.Controls.Add(Me.DPSIncrement)
        Me.TabPage1.Controls.Add(Me.RailHeightIncrement)
        Me.TabPage1.Controls.Add(Me.Label44)
        Me.TabPage1.Controls.Add(Me.label99)
        Me.TabPage1.Controls.Add(Me.DTBIncrement)
        Me.TabPage1.Controls.Add(Me.DFTIncrement)
        Me.TabPage1.Controls.Add(Me.Label43)
        Me.TabPage1.Location = New System.Drawing.Point(4, 22)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Size = New System.Drawing.Size(504, 116)
        Me.TabPage1.TabIndex = 4
        Me.TabPage1.Text = "Settings"
        Me.TabPage1.UseVisualStyleBackColor = True
        '
        'GroupBox19
        '
        Me.GroupBox19.Controls.Add(Me.Post2FirstStepDownSel)
        Me.GroupBox19.Controls.Add(Me.StepEdge)
        Me.GroupBox19.Controls.Add(Me.Post2FirstStepUpSel)
        Me.GroupBox19.Location = New System.Drawing.Point(126, 80)
        Me.GroupBox19.Name = "GroupBox19"
        Me.GroupBox19.Size = New System.Drawing.Size(115, 43)
        Me.GroupBox19.TabIndex = 149
        Me.GroupBox19.TabStop = False
        Me.GroupBox19.Text = "Post To First Step"
        '
        'Post2FirstStepDownSel
        '
        Me.Post2FirstStepDownSel.BackColor = System.Drawing.Color.White
        Me.Post2FirstStepDownSel.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.Post2FirstStepDownSel.FlatAppearance.BorderSize = 0
        Me.Post2FirstStepDownSel.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Post2FirstStepDownSel.Location = New System.Drawing.Point(12, 16)
        Me.Post2FirstStepDownSel.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.Post2FirstStepDownSel.Name = "Post2FirstStepDownSel"
        Me.Post2FirstStepDownSel.Size = New System.Drawing.Size(20, 20)
        Me.Post2FirstStepDownSel.TabIndex = 141
        Me.Post2FirstStepDownSel.Text = "<"
        Me.Post2FirstStepDownSel.UseVisualStyleBackColor = False
        '
        'StepEdge
        '
        Me.StepEdge.Location = New System.Drawing.Point(58, 16)
        Me.StepEdge.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.StepEdge.Name = "StepEdge"
        Me.StepEdge.Size = New System.Drawing.Size(44, 20)
        Me.StepEdge.TabIndex = 143
        Me.StepEdge.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Post2FirstStepUpSel
        '
        Me.Post2FirstStepUpSel.BackColor = System.Drawing.Color.White
        Me.Post2FirstStepUpSel.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Post2FirstStepUpSel.Location = New System.Drawing.Point(31, 16)
        Me.Post2FirstStepUpSel.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.Post2FirstStepUpSel.Name = "Post2FirstStepUpSel"
        Me.Post2FirstStepUpSel.Size = New System.Drawing.Size(20, 20)
        Me.Post2FirstStepUpSel.TabIndex = 142
        Me.Post2FirstStepUpSel.Text = ">"
        Me.Post2FirstStepUpSel.UseVisualStyleBackColor = False
        '
        'GroupBox18
        '
        Me.GroupBox18.Controls.Add(Me.DeckEdge2PostDownSel)
        Me.GroupBox18.Controls.Add(Me.DeckEdge)
        Me.GroupBox18.Controls.Add(Me.DeckEdge2PostUpSel)
        Me.GroupBox18.Location = New System.Drawing.Point(126, 37)
        Me.GroupBox18.Name = "GroupBox18"
        Me.GroupBox18.Size = New System.Drawing.Size(115, 43)
        Me.GroupBox18.TabIndex = 148
        Me.GroupBox18.TabStop = False
        Me.GroupBox18.Text = "Deck Edge To Post"
        '
        'DeckEdge2PostDownSel
        '
        Me.DeckEdge2PostDownSel.BackColor = System.Drawing.Color.White
        Me.DeckEdge2PostDownSel.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.DeckEdge2PostDownSel.FlatAppearance.BorderSize = 0
        Me.DeckEdge2PostDownSel.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DeckEdge2PostDownSel.Location = New System.Drawing.Point(12, 16)
        Me.DeckEdge2PostDownSel.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.DeckEdge2PostDownSel.Name = "DeckEdge2PostDownSel"
        Me.DeckEdge2PostDownSel.Size = New System.Drawing.Size(20, 20)
        Me.DeckEdge2PostDownSel.TabIndex = 146
        Me.DeckEdge2PostDownSel.Text = "<"
        Me.DeckEdge2PostDownSel.UseVisualStyleBackColor = False
        '
        'DeckEdge
        '
        Me.DeckEdge.Location = New System.Drawing.Point(58, 16)
        Me.DeckEdge.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.DeckEdge.Name = "DeckEdge"
        Me.DeckEdge.Size = New System.Drawing.Size(44, 20)
        Me.DeckEdge.TabIndex = 142
        Me.DeckEdge.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'DeckEdge2PostUpSel
        '
        Me.DeckEdge2PostUpSel.BackColor = System.Drawing.Color.White
        Me.DeckEdge2PostUpSel.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DeckEdge2PostUpSel.Location = New System.Drawing.Point(31, 16)
        Me.DeckEdge2PostUpSel.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.DeckEdge2PostUpSel.Name = "DeckEdge2PostUpSel"
        Me.DeckEdge2PostUpSel.Size = New System.Drawing.Size(20, 20)
        Me.DeckEdge2PostUpSel.TabIndex = 147
        Me.DeckEdge2PostUpSel.Text = ">"
        Me.DeckEdge2PostUpSel.UseVisualStyleBackColor = False
        '
        'GroupBox12
        '
        Me.GroupBox12.Controls.Add(Me.GroupBox27)
        Me.GroupBox12.Controls.Add(Me.GroupBox1)
        Me.GroupBox12.Controls.Add(Me.RadioButton2)
        Me.GroupBox12.Controls.Add(Me.GroupBox26)
        Me.GroupBox12.Controls.Add(Me.RadioButton1)
        Me.GroupBox12.Controls.Add(Me.GroupBox25)
        Me.GroupBox12.Controls.Add(Me.GroupBox18)
        Me.GroupBox12.Controls.Add(Me.GroupBox19)
        Me.GroupBox12.Location = New System.Drawing.Point(7, 6)
        Me.GroupBox12.Name = "GroupBox12"
        Me.GroupBox12.Size = New System.Drawing.Size(506, 130)
        Me.GroupBox12.TabIndex = 143
        Me.GroupBox12.TabStop = False
        Me.GroupBox12.Text = "Slope"
        '
        'RadioButton2
        '
        Me.RadioButton2.AutoSize = True
        Me.RadioButton2.Location = New System.Drawing.Point(66, 16)
        Me.RadioButton2.Name = "RadioButton2"
        Me.RadioButton2.Size = New System.Drawing.Size(60, 17)
        Me.RadioButton2.TabIndex = 145
        Me.RadioButton2.TabStop = True
        Me.RadioButton2.Text = "Disable"
        Me.RadioButton2.UseVisualStyleBackColor = True
        '
        'GroupBox26
        '
        Me.GroupBox26.Controls.Add(Me.StrRun)
        Me.GroupBox26.Controls.Add(Me.RunDownSel)
        Me.GroupBox26.Controls.Add(Me.RunUpSel)
        Me.GroupBox26.Location = New System.Drawing.Point(4, 80)
        Me.GroupBox26.Name = "GroupBox26"
        Me.GroupBox26.Size = New System.Drawing.Size(115, 43)
        Me.GroupBox26.TabIndex = 151
        Me.GroupBox26.TabStop = False
        Me.GroupBox26.Text = "Run"
        '
        'StrRun
        '
        Me.StrRun.Location = New System.Drawing.Point(58, 16)
        Me.StrRun.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.StrRun.Name = "StrRun"
        Me.StrRun.Size = New System.Drawing.Size(44, 20)
        Me.StrRun.TabIndex = 141
        Me.StrRun.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'RunDownSel
        '
        Me.RunDownSel.BackColor = System.Drawing.Color.White
        Me.RunDownSel.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.RunDownSel.FlatAppearance.BorderSize = 0
        Me.RunDownSel.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RunDownSel.Location = New System.Drawing.Point(12, 16)
        Me.RunDownSel.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.RunDownSel.Name = "RunDownSel"
        Me.RunDownSel.Size = New System.Drawing.Size(20, 20)
        Me.RunDownSel.TabIndex = 146
        Me.RunDownSel.Text = "<"
        Me.RunDownSel.UseVisualStyleBackColor = False
        '
        'RunUpSel
        '
        Me.RunUpSel.BackColor = System.Drawing.Color.White
        Me.RunUpSel.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RunUpSel.Location = New System.Drawing.Point(31, 16)
        Me.RunUpSel.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.RunUpSel.Name = "RunUpSel"
        Me.RunUpSel.Size = New System.Drawing.Size(20, 20)
        Me.RunUpSel.TabIndex = 147
        Me.RunUpSel.Text = ">"
        Me.RunUpSel.UseVisualStyleBackColor = False
        '
        'RadioButton1
        '
        Me.RadioButton1.AutoSize = True
        Me.RadioButton1.Location = New System.Drawing.Point(8, 16)
        Me.RadioButton1.Name = "RadioButton1"
        Me.RadioButton1.Size = New System.Drawing.Size(58, 17)
        Me.RadioButton1.TabIndex = 144
        Me.RadioButton1.TabStop = True
        Me.RadioButton1.Text = "Enable"
        Me.RadioButton1.UseVisualStyleBackColor = True
        '
        'GroupBox25
        '
        Me.GroupBox25.Controls.Add(Me.StrRise)
        Me.GroupBox25.Controls.Add(Me.RiseDownSel)
        Me.GroupBox25.Controls.Add(Me.RiseUpSel)
        Me.GroupBox25.Location = New System.Drawing.Point(4, 37)
        Me.GroupBox25.Name = "GroupBox25"
        Me.GroupBox25.Size = New System.Drawing.Size(115, 43)
        Me.GroupBox25.TabIndex = 150
        Me.GroupBox25.TabStop = False
        Me.GroupBox25.Text = "Rise"
        '
        'StrRise
        '
        Me.StrRise.Location = New System.Drawing.Point(58, 16)
        Me.StrRise.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.StrRise.Name = "StrRise"
        Me.StrRise.Size = New System.Drawing.Size(44, 20)
        Me.StrRise.TabIndex = 140
        Me.StrRise.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'RiseDownSel
        '
        Me.RiseDownSel.BackColor = System.Drawing.Color.White
        Me.RiseDownSel.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.RiseDownSel.FlatAppearance.BorderSize = 0
        Me.RiseDownSel.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RiseDownSel.Location = New System.Drawing.Point(12, 16)
        Me.RiseDownSel.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.RiseDownSel.Name = "RiseDownSel"
        Me.RiseDownSel.Size = New System.Drawing.Size(20, 20)
        Me.RiseDownSel.TabIndex = 144
        Me.RiseDownSel.Text = "<"
        Me.RiseDownSel.UseVisualStyleBackColor = False
        '
        'RiseUpSel
        '
        Me.RiseUpSel.BackColor = System.Drawing.Color.White
        Me.RiseUpSel.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RiseUpSel.Location = New System.Drawing.Point(31, 16)
        Me.RiseUpSel.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.RiseUpSel.Name = "RiseUpSel"
        Me.RiseUpSel.Size = New System.Drawing.Size(20, 20)
        Me.RiseUpSel.TabIndex = 145
        Me.RiseUpSel.Text = ">"
        Me.RiseUpSel.UseVisualStyleBackColor = False
        '
        'DataGridView1
        '
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Location = New System.Drawing.Point(7, 299)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.Size = New System.Drawing.Size(510, 150)
        Me.DataGridView1.TabIndex = 0
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(7, 455)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(75, 23)
        Me.Button1.TabIndex = 122
        Me.Button1.Text = "Add Line"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'RaLibTableAdapter1
        '
        Me.RaLibTableAdapter1.ClearBeforeFill = True
        '
        'PicketLibTableAdapter
        '
        Me.PicketLibTableAdapter.ClearBeforeFill = True
        '
        'PoLibTableAdapter1
        '
        Me.PoLibTableAdapter1.ClearBeforeFill = True
        '
        'RaLibTableAdapter
        '
        Me.RaLibTableAdapter.ClearBeforeFill = True
        '
        'GroupBox24
        '
        Me.GroupBox24.Controls.Add(Me.Label31)
        Me.GroupBox24.Controls.Add(Me.Label26)
        Me.GroupBox24.Controls.Add(Me.StanDistFirstHole)
        Me.GroupBox24.Controls.Add(Me.Label3)
        Me.GroupBox24.Controls.Add(Me.StanRailCutL)
        Me.GroupBox24.Controls.Add(Me.PicketSpaceNoSlope)
        Me.GroupBox24.Location = New System.Drawing.Point(525, 280)
        Me.GroupBox24.Name = "GroupBox24"
        Me.GroupBox24.Size = New System.Drawing.Size(120, 65)
        Me.GroupBox24.TabIndex = 144
        Me.GroupBox24.TabStop = False
        Me.GroupBox24.Text = "Railing"
        '
        'StanDistFirstHole
        '
        Me.StanDistFirstHole.AutoSize = True
        Me.StanDistFirstHole.Location = New System.Drawing.Point(79, 31)
        Me.StanDistFirstHole.Name = "StanDistFirstHole"
        Me.StanDistFirstHole.Size = New System.Drawing.Size(34, 13)
        Me.StanDistFirstHole.TabIndex = 130
        Me.StanDistFirstHole.Text = "0.000"
        '
        'StanRailCutL
        '
        Me.StanRailCutL.AutoSize = True
        Me.StanRailCutL.Location = New System.Drawing.Point(79, 16)
        Me.StanRailCutL.Name = "StanRailCutL"
        Me.StanRailCutL.Size = New System.Drawing.Size(34, 13)
        Me.StanRailCutL.TabIndex = 129
        Me.StanRailCutL.Text = "0.000"
        '
        'PicketSpaceNoSlope
        '
        Me.PicketSpaceNoSlope.AutoSize = True
        Me.PicketSpaceNoSlope.Location = New System.Drawing.Point(79, 46)
        Me.PicketSpaceNoSlope.Name = "PicketSpaceNoSlope"
        Me.PicketSpaceNoSlope.Size = New System.Drawing.Size(34, 13)
        Me.PicketSpaceNoSlope.TabIndex = 132
        Me.PicketSpaceNoSlope.Text = "0.000"
        '
        'GroupBox1
        '
        Me.GroupBox1.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.GroupBox1.Controls.Add(Me.AngleRef)
        Me.GroupBox1.Location = New System.Drawing.Point(248, 37)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(115, 43)
        Me.GroupBox1.TabIndex = 152
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Angle"
        '
        'GroupBox27
        '
        Me.GroupBox27.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.GroupBox27.Controls.Add(Me.Label2)
        Me.GroupBox27.Location = New System.Drawing.Point(248, 80)
        Me.GroupBox27.Name = "GroupBox27"
        Me.GroupBox27.Size = New System.Drawing.Size(115, 43)
        Me.GroupBox27.TabIndex = 153
        Me.GroupBox27.TabStop = False
        Me.GroupBox27.Text = "Aligned IBD"
        '
        'MainPage
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.WhiteSmoke
        Me.ClientSize = New System.Drawing.Size(657, 527)
        Me.Controls.Add(Me.GroupBox24)
        Me.Controls.Add(Me.GroupBox8)
        Me.Controls.Add(Me.GroupBox4)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox23)
        Me.Controls.Add(Me.GroupBox12)
        Me.Controls.Add(Me.GroupBox22)
        Me.Controls.Add(Me.GroupBox13)
        Me.Controls.Add(Me.GroupBox5)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.DataGridView1)
        Me.Controls.Add(Me.TabControl2)
        Me.Controls.Add(Me.StairCalc)
        Me.Controls.Add(Me.StairReset)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.Name = "MainPage"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "FenceBuilder"
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox4.PerformLayout()
        Me.GroupBox23.ResumeLayout(False)
        Me.GroupBox23.PerformLayout()
        Me.GroupBox22.ResumeLayout(False)
        Me.GroupBox22.PerformLayout()
        Me.GroupBox13.ResumeLayout(False)
        Me.GroupBox13.PerformLayout()
        Me.GroupBox8.ResumeLayout(False)
        Me.GroupBox8.PerformLayout()
        Me.GroupBox5.ResumeLayout(False)
        Me.GroupBox5.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.Options.ResumeLayout(False)
        Me.Options.PerformLayout()
        Me.PostOptions.ResumeLayout(False)
        Me.PostOptions.PerformLayout()
        CType(Me.PoLibBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PostsDBDataSet1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox15.ResumeLayout(False)
        Me.GroupBox15.PerformLayout()
        CType(Me.TopRaLibBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TopRailsDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox6.ResumeLayout(False)
        Me.GroupBox6.PerformLayout()
        CType(Me.BotRaLibBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.BottomRailsDBDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox7.ResumeLayout(False)
        Me.GroupBox7.PerformLayout()
        CType(Me.PicketLibBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PicketsDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabControl2.ResumeLayout(False)
        Me.TabPage3.ResumeLayout(False)
        Me.GroupBox11.ResumeLayout(False)
        Me.GroupBox11.PerformLayout()
        Me.GroupBox10.ResumeLayout(False)
        Me.GroupBox10.PerformLayout()
        Me.TabPage4.ResumeLayout(False)
        Me.GroupBox9.ResumeLayout(False)
        Me.GroupBox9.PerformLayout()
        Me.TabPage2.ResumeLayout(False)
        Me.GroupBox17.ResumeLayout(False)
        Me.GroupBox17.PerformLayout()
        Me.GroupBox16.ResumeLayout(False)
        Me.GroupBox16.PerformLayout()
        Me.GroupBox20.ResumeLayout(False)
        Me.GroupBox20.PerformLayout()
        Me.TabPage1.ResumeLayout(False)
        Me.TabPage1.PerformLayout()
        Me.GroupBox19.ResumeLayout(False)
        Me.GroupBox19.PerformLayout()
        Me.GroupBox18.ResumeLayout(False)
        Me.GroupBox18.PerformLayout()
        Me.GroupBox12.ResumeLayout(False)
        Me.GroupBox12.PerformLayout()
        Me.GroupBox26.ResumeLayout(False)
        Me.GroupBox26.PerformLayout()
        Me.GroupBox25.ResumeLayout(False)
        Me.GroupBox25.PerformLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox24.ResumeLayout(False)
        Me.GroupBox24.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox27.ResumeLayout(False)
        Me.GroupBox27.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents GroupBox7 As GroupBox
    Friend WithEvents PicketClear As TextBox
    Friend WithEvents Label35 As Label
    Friend WithEvents DesPicketSpc As TextBox
    Friend WithEvents GroupBox6 As GroupBox
    Friend WithEvents StairCalc As Button
    Friend WithEvents GroupBox5 As GroupBox
    Friend WithEvents Label49 As Label
    Friend WithEvents Label51 As Label
    Friend WithEvents GroupBox8 As GroupBox
    Friend WithEvents Label47 As Label
    Friend WithEvents Label46 As Label
    Friend WithEvents Label45 As Label
    Friend WithEvents Label48 As Label
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents StairReset As Button
    Friend WithEvents ComboBox1 As ComboBox
    Friend WithEvents TopRailHeight As TextBox
    Friend WithEvents TopRailThick As TextBox
    Friend WithEvents TopRailWidth As TextBox
    Friend WithEvents RailingDB As Button
    Friend WithEvents BotRailThick As TextBox
    Friend WithEvents BotRailWidth As TextBox
    Friend WithEvents BotRailHeight As TextBox
    Friend WithEvents ComboBox2 As ComboBox
    '  Friend WithEvents RailsDBDataSet3 As RailsDBDataSet3
    ' Friend WithEvents RaLibTableAdapter As RailsDBDataSet3TableAdapters.RaLibTableAdapter
    Friend WithEvents PostDB As Button
    Friend WithEvents PostsDBDataSet As PostsDBDataSet
    Friend WithEvents PoLibTableAdapter As PostsDBDataSetTableAdapters.PoLibTableAdapter
    Friend WithEvents GroupBox15 As GroupBox
    Friend WithEvents AngleRef As Label
    Friend WithEvents ExtraEndMat As TextBox
    Friend WithEvents Label26 As Label
    Friend WithEvents Label31 As Label
    Friend WithEvents PostOptions As GroupBox
    Friend WithEvents PostHeight As TextBox
    Friend WithEvents Label14 As Label
    Friend WithEvents PostThick As TextBox
    Friend WithEvents Label16 As Label
    Friend WithEvents ComboBox3 As ComboBox
    Friend WithEvents PostWidth As TextBox
    Friend WithEvents Label15 As Label
    Friend WithEvents Label50 As Label
    Friend WithEvents Label38 As Label
    Friend WithEvents PostHoleClearance As TextBox
    Friend WithEvents PostBelowGround As TextBox
    Friend WithEvents Options As GroupBox
    Friend WithEvents Label5 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents Label18 As Label
    Friend WithEvents Label32 As Label
    Friend WithEvents Label33 As Label
    Friend WithEvents Label59 As Label
    Friend WithEvents Label60 As Label
    Friend WithEvents Label62 As Label
    Friend WithEvents GroupBox13 As GroupBox
    Friend WithEvents Label65 As Label
    Friend WithEvents Label66 As Label
    Friend WithEvents GroupBox22 As GroupBox
    Friend WithEvents Label92 As Label
    Friend WithEvents Label94 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents IBDIncrement As TextBox
    Friend WithEvents Label19 As Label
    Friend WithEvents PicketComboBox As ComboBox
    ' Friend WithEvents PicketLibTableAdapter As PicketsDBDataSetTableAdapters.PicketLibTableAdapter
    Friend WithEvents PicketsDB As Button
    Friend WithEvents PicketWidth As TextBox
    Friend WithEvents Label20 As Label
    Friend WithEvents PicketThick As TextBox
    Friend WithEvents Label21 As Label
    Friend WithEvents Label22 As Label
    Friend WithEvents PicketHeight As TextBox
    Friend WithEvents TabControl2 As TabControl
    Friend WithEvents TabPage2 As TabPage
    Friend WithEvents TabPage3 As TabPage
    Friend WithEvents TabPage4 As TabPage
    Friend WithEvents DistanceToBottom As TextBox
    Friend WithEvents DFTDownSelect As Button
    Friend WithEvents DTBDownSelect As Button
    Friend WithEvents DistanceFromTop As TextBox
    Friend WithEvents DTBUpSelect As Button
    Friend WithEvents InBetweenDistance As TextBox
    Friend WithEvents RailHeightDownSelect As Button
    Friend WithEvents RailHeight As TextBox
    Friend WithEvents InBetweenDistanceUpSelect As Button
    Friend WithEvents InbetweenDistanceDownSelect As Button
    Friend WithEvents DFTUpSelect As Button
    Friend WithEvents RailHeightUpSelect As Button
    Friend WithEvents label99 As Label
    Friend WithEvents RailHeightIncrement As TextBox
    Friend WithEvents Label43 As Label
    Friend WithEvents DFTIncrement As TextBox
    Friend WithEvents Label44 As Label
    Friend WithEvents DTBIncrement As TextBox
    Friend WithEvents PicSpaceUpSelect As Button
    Friend WithEvents PicSpaceDownSelect As Button
    Friend WithEvents Label42 As Label
    Friend WithEvents DPSIncrement As TextBox
    Friend WithEvents DeckEdge As TextBox
    Friend WithEvents StepEdge As TextBox
    Friend WithEvents CheckBox2 As CheckBox
    Friend WithEvents GroupBox9 As GroupBox
    Friend WithEvents GroupBox12 As GroupBox
    Friend WithEvents StrRun As TextBox
    Friend WithEvents StrRise As TextBox
    Friend WithEvents GroupBox11 As GroupBox
    Friend WithEvents GroupBox10 As GroupBox
    Friend WithEvents GroupBox19 As GroupBox
    Friend WithEvents Post2FirstStepDownSel As Button
    Friend WithEvents Post2FirstStepUpSel As Button
    Friend WithEvents GroupBox18 As GroupBox
    Friend WithEvents DeckEdge2PostDownSel As Button
    Friend WithEvents DeckEdge2PostUpSel As Button
    Friend WithEvents GroupBox17 As GroupBox
    Friend WithEvents GroupBox16 As GroupBox
    Friend WithEvents Label1 As Label
    Friend WithEvents StepEdgeIncrement As TextBox
    Friend WithEvents Label12 As Label
    Friend WithEvents DeckEdgeIncrement As TextBox
    'Friend WithEvents RaLibTableAdapter2 As RailsDBDataSet5TableAdapters.RaLibTableAdapter
    Friend WithEvents AmtInGroundDownSel As Button
    Friend WithEvents AmtInGroundUpSel As Button
    Friend WithEvents GroupBox20 As GroupBox
    Friend WithEvents HoleClearanceDownSel As Button
    Friend WithEvents HoleClearanceUpSel As Button
    Friend WithEvents Label13 As Label
    Friend WithEvents AmtInGroundInc As TextBox
    Friend WithEvents Label24 As Label
    Friend WithEvents HoleClearanceInc As TextBox
    Friend WithEvents TabPage1 As TabPage
    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents Button1 As Button
    Friend WithEvents TopRailsDataSet As TopRailsDataSet
    Friend WithEvents TopRaLibBindingSource As BindingSource
    Friend WithEvents RaLibTableAdapter1 As TopRailsDataSetTableAdapters.RaLibTableAdapter
    Friend WithEvents PicketsDataSet As PicketsDataSet
    Friend WithEvents PicketLibBindingSource As BindingSource
    Friend WithEvents PicketLibTableAdapter As PicketsDataSetTableAdapters.PicketLibTableAdapter
    Friend WithEvents PostsDBDataSet1 As PostsDBDataSet1
    Friend WithEvents PoLibBindingSource As BindingSource
    Friend WithEvents PoLibTableAdapter1 As PostsDBDataSet1TableAdapters.PoLibTableAdapter
    Friend WithEvents BottomRailsDBDataSet As BottomRailsDBDataSet1
    Friend WithEvents BotRaLibBindingSource As BindingSource
    Friend WithEvents RaLibTableAdapter As BottomRailsDBDataSet1TableAdapters.RaLibTableAdapter
    Friend WithEvents GroupBox23 As GroupBox
    Friend WithEvents PostCutLength As Label
    Friend WithEvents BetweenHolesNoSlope As Label
    Friend WithEvents StanRailCutL As Label
    Friend WithEvents StanDistFirstHole As Label
    Friend WithEvents PicketSpaceNoSlope As Label
    Friend WithEvents PicketCutL As Label
    Friend WithEvents NumPicketHoles As Label
    Friend WithEvents TopPostFirstHole2 As Label
    Friend WithEvents TopPostCutLength As Label
    Friend WithEvents BotPostFirstHole2 As Label
    Friend WithEvents BotPostCutLength As Label
    Friend WithEvents PostFirstHole As Label
    Friend WithEvents PostSecondHole As Label
    Friend WithEvents BetweenHolesSlope As Label
    Friend WithEvents TopStrRailPicSpace As Label
    Friend WithEvents TopStrRailDisFirstHole As Label
    Friend WithEvents TopStrRailCutL As Label
    Friend WithEvents TopRailHole As Label
    Friend WithEvents BotStrRailPicSpace As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents BotRailHole As Label
    Friend WithEvents BotStrRailDisFirstHole As Label
    Friend WithEvents BotStrRailCutL As Label
    Friend WithEvents GroupBox4 As GroupBox
    Friend WithEvents GroupBox24 As GroupBox
    Friend WithEvents RunDownSel As Button
    Friend WithEvents RunUpSel As Button
    Friend WithEvents RiseDownSel As Button
    Friend WithEvents RiseUpSel As Button
    Friend WithEvents GroupBox26 As GroupBox
    Friend WithEvents GroupBox25 As GroupBox
    Friend WithEvents RadioButton1 As RadioButton
    Friend WithEvents RadioButton2 As RadioButton
    Friend WithEvents GroupBox27 As GroupBox
    Friend WithEvents GroupBox1 As GroupBox
End Class
