﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class RailLibrary
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(RailLibrary))
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.RaThick = New System.Windows.Forms.TextBox()
        Me.RaWidth = New System.Windows.Forms.TextBox()
        Me.RaHeight = New System.Windows.Forms.TextBox()
        Me.ExitNow = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Delete = New System.Windows.Forms.Button()
        Me.Updates = New System.Windows.Forms.Button()
        Me.Insert = New System.Windows.Forms.Button()
        Me.ShowRaLib = New System.Windows.Forms.Button()
        Me.RaID = New System.Windows.Forms.ComboBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.RaRad = New System.Windows.Forms.TextBox()
        Me.RailsLibraryDataSet1 = New FenceBuilderRootNmspc.RailsLibraryDataSet1()
        Me.RaLibBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.RaLibTableAdapter = New FenceBuilderRootNmspc.RailsLibraryDataSet1TableAdapters.RaLibTableAdapter()
        CType(Me.RailsLibraryDataSet1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.RaLibBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(30, 112)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(56, 13)
        Me.Label4.TabIndex = 20
        Me.Label4.Text = "Thickness"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(51, 85)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(35, 13)
        Me.Label3.TabIndex = 19
        Me.Label3.Text = "Width"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(48, 57)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(38, 13)
        Me.Label2.TabIndex = 17
        Me.Label2.Text = "Height"
        '
        'RaThick
        '
        Me.RaThick.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.RaThick.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.RaLibBindingSource, "Thickness", True))
        Me.RaThick.Location = New System.Drawing.Point(90, 109)
        Me.RaThick.Name = "RaThick"
        Me.RaThick.Size = New System.Drawing.Size(121, 20)
        Me.RaThick.TabIndex = 4
        '
        'RaWidth
        '
        Me.RaWidth.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.RaWidth.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.RaLibBindingSource, "Width", True))
        Me.RaWidth.Location = New System.Drawing.Point(90, 82)
        Me.RaWidth.Name = "RaWidth"
        Me.RaWidth.Size = New System.Drawing.Size(121, 20)
        Me.RaWidth.TabIndex = 3
        '
        'RaHeight
        '
        Me.RaHeight.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.RaHeight.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.RaLibBindingSource, "Height", True))
        Me.RaHeight.Location = New System.Drawing.Point(90, 54)
        Me.RaHeight.Name = "RaHeight"
        Me.RaHeight.Size = New System.Drawing.Size(121, 20)
        Me.RaHeight.TabIndex = 2
        '
        'ExitNow
        '
        Me.ExitNow.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.ExitNow.Location = New System.Drawing.Point(250, 170)
        Me.ExitNow.Name = "ExitNow"
        Me.ExitNow.Size = New System.Drawing.Size(75, 23)
        Me.ExitNow.TabIndex = 10
        Me.ExitNow.Text = "Exit"
        Me.ExitNow.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(15, 28)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(71, 13)
        Me.Label1.TabIndex = 9
        Me.Label1.Text = "Material Type"
        '
        'Delete
        '
        Me.Delete.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Delete.Location = New System.Drawing.Point(250, 61)
        Me.Delete.Name = "Delete"
        Me.Delete.Size = New System.Drawing.Size(75, 23)
        Me.Delete.TabIndex = 9
        Me.Delete.Text = "Delete"
        Me.Delete.UseVisualStyleBackColor = True
        '
        'Updates
        '
        Me.Updates.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Updates.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Updates.Location = New System.Drawing.Point(133, 170)
        Me.Updates.Name = "Updates"
        Me.Updates.Size = New System.Drawing.Size(75, 23)
        Me.Updates.TabIndex = 7
        Me.Updates.Text = "Update"
        Me.Updates.UseVisualStyleBackColor = True
        '
        'Insert
        '
        Me.Insert.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Insert.Location = New System.Drawing.Point(55, 170)
        Me.Insert.Name = "Insert"
        Me.Insert.Size = New System.Drawing.Size(75, 23)
        Me.Insert.TabIndex = 6
        Me.Insert.Text = "Insert"
        Me.Insert.UseVisualStyleBackColor = True
        '
        'ShowRaLib
        '
        Me.ShowRaLib.Location = New System.Drawing.Point(250, 24)
        Me.ShowRaLib.Name = "ShowRaLib"
        Me.ShowRaLib.Size = New System.Drawing.Size(75, 23)
        Me.ShowRaLib.TabIndex = 8
        Me.ShowRaLib.Text = "Show Data"
        Me.ShowRaLib.UseVisualStyleBackColor = True
        '
        'RaID
        '
        Me.RaID.DataSource = Me.RaLibBindingSource
        Me.RaID.DisplayMember = "ID"
        Me.RaID.FormattingEnabled = True
        Me.RaID.Location = New System.Drawing.Point(90, 24)
        Me.RaID.Name = "RaID"
        Me.RaID.Size = New System.Drawing.Size(121, 21)
        Me.RaID.TabIndex = 1
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(46, 140)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(40, 13)
        Me.Label5.TabIndex = 26
        Me.Label5.Text = "Radius"
        '
        'RaRad
        '
        Me.RaRad.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.RaRad.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.RaLibBindingSource, "Radius", True))
        Me.RaRad.Location = New System.Drawing.Point(90, 137)
        Me.RaRad.Name = "RaRad"
        Me.RaRad.Size = New System.Drawing.Size(121, 20)
        Me.RaRad.TabIndex = 5
        '
        'RailsLibraryDataSet1
        '
        Me.RailsLibraryDataSet1.DataSetName = "RailsLibraryDataSet1"
        Me.RailsLibraryDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'RaLibBindingSource
        '
        Me.RaLibBindingSource.DataMember = "RaLib"
        Me.RaLibBindingSource.DataSource = Me.RailsLibraryDataSet1
        '
        'RaLibTableAdapter
        '
        Me.RaLibTableAdapter.ClearBeforeFill = True
        '
        'RailLibrary
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(337, 200)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.RaRad)
        Me.Controls.Add(Me.RaID)
        Me.Controls.Add(Me.ShowRaLib)
        Me.Controls.Add(Me.Delete)
        Me.Controls.Add(Me.Updates)
        Me.Controls.Add(Me.Insert)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.RaThick)
        Me.Controls.Add(Me.RaWidth)
        Me.Controls.Add(Me.RaHeight)
        Me.Controls.Add(Me.ExitNow)
        Me.Controls.Add(Me.Label1)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "RailLibrary"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Rail Library"
        CType(Me.RailsLibraryDataSet1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.RaLibBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents RaThick As System.Windows.Forms.TextBox
    Friend WithEvents RaWidth As System.Windows.Forms.TextBox
    Friend WithEvents RaHeight As System.Windows.Forms.TextBox
    Friend WithEvents ExitNow As System.Windows.Forms.Button
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Delete As System.Windows.Forms.Button
    Friend WithEvents Updates As System.Windows.Forms.Button
    Friend WithEvents Insert As System.Windows.Forms.Button
    Friend WithEvents ShowRaLib As System.Windows.Forms.Button
    Friend WithEvents RaID As ComboBox
    Friend WithEvents Label5 As Label
    Friend WithEvents RaRad As TextBox
    Friend WithEvents RailsLibraryDataSet1 As RailsLibraryDataSet1
    Friend WithEvents RaLibBindingSource As BindingSource
    Friend WithEvents RaLibTableAdapter As RailsLibraryDataSet1TableAdapters.RaLibTableAdapter
    ' Friend WithEvents RaLibTableAdapter As RailsDBDataSet3TableAdapters.RaLibTableAdapter
End Class
