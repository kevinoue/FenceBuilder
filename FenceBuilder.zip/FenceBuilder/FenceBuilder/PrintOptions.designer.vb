﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class PrintOptions
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.BtnOK = New System.Windows.Forms.Button()
        Me.BtnCancel = New System.Windows.Forms.Button()
        Me.Chklst = New System.Windows.Forms.CheckedListBox()
        Me.ChkZoomFull = New System.Windows.Forms.CheckBox()
        Me.SuspendLayout()
        '
        'BtnOK
        '
        Me.BtnOK.Location = New System.Drawing.Point(382, 255)
        Me.BtnOK.Name = "BtnOK"
        Me.BtnOK.Size = New System.Drawing.Size(75, 23)
        Me.BtnOK.TabIndex = 0
        Me.BtnOK.Text = "OK"
        Me.BtnOK.UseVisualStyleBackColor = True
        '
        'BtnCancel
        '
        Me.BtnCancel.Location = New System.Drawing.Point(463, 255)
        Me.BtnCancel.Name = "BtnCancel"
        Me.BtnCancel.Size = New System.Drawing.Size(75, 23)
        Me.BtnCancel.TabIndex = 1
        Me.BtnCancel.Text = "Cancel"
        Me.BtnCancel.UseVisualStyleBackColor = True
        '
        'Chklst
        '
        Me.Chklst.FormattingEnabled = True
        Me.Chklst.Location = New System.Drawing.Point(13, 13)
        Me.Chklst.Name = "Chklst"
        Me.Chklst.Size = New System.Drawing.Size(180, 214)
        Me.Chklst.TabIndex = 2
        '
        'ChkZoomFull
        '
        Me.ChkZoomFull.AutoSize = True
        Me.ChkZoomFull.Location = New System.Drawing.Point(13, 297)
        Me.ChkZoomFull.Name = "ChkZoomFull"
        Me.ChkZoomFull.Size = New System.Drawing.Size(105, 17)
        Me.ChkZoomFull.TabIndex = 3
        Me.ChkZoomFull.Text = "Preview at 100%"
        Me.ChkZoomFull.UseVisualStyleBackColor = True
        '
        'PrintOptions
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(627, 422)
        Me.Controls.Add(Me.ChkZoomFull)
        Me.Controls.Add(Me.Chklst)
        Me.Controls.Add(Me.BtnCancel)
        Me.Controls.Add(Me.BtnOK)
        Me.Name = "PrintOptions"
        Me.Text = "PrintOptions"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents BtnOK As Button
    Friend WithEvents BtnCancel As Button
    Friend WithEvents Chklst As CheckedListBox
    Friend WithEvents ChkZoomFull As CheckBox
End Class
