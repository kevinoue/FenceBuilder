﻿Imports System.Data.OleDb


Public Class MainPage


    Public Sub MainPage_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Me.RaLibTableAdapter.Fill(Me.BottomRailsDBDataSet.RaLib)
        Me.PoLibTableAdapter1.Fill(Me.PostsDBDataSet1.PoLib)
        Me.PicketLibTableAdapter.Fill(Me.PicketsDataSet.PicketLib)
        Me.RaLibTableAdapter1.Fill(Me.TopRailsDataSet.RaLib)
        RadioButton2.Checked = True




        StrRise.Enabled = False

        StrRun.Enabled = False

        DeckEdge.Enabled = False
        StepEdge.Enabled = False
        Post2FirstStepUpSel.Enabled = False
        Post2FirstStepDownSel.Enabled = False
        DeckEdge2PostUpSel.Enabled = False
        DeckEdge2PostDownSel.Enabled = False

        GroupBox8.Hide()
        GroupBox2.Hide()
        GroupBox13.Hide()
        GroupBox22.Hide()
        GroupBox23.Hide()






        CheckBox2.Enabled = False
        AngleRef.Enabled = False
        ' AngleRef.Text = "-.-"


        RailHeight.Text = "36"
        InBetweenDistance.Text = "48"
        DistanceFromTop.Text = "3"
        DistanceToBottom.Text = "3.5"
        IBDIncrement.Text = "0.125"
        StepEdge.Text = "0"
        DeckEdge.Text = "3"


    End Sub

    Public Sub RiseDownSel_Click(sender As Object, e As EventArgs) Handles RiseDownSel.Click

        Me.StrRise.Text = Me.StrRise.Text - (Me.IBDIncrement.Text * 1)
    End Sub
    Public Sub RiseUpSel_Click(sender As Object, e As EventArgs) Handles RiseUpSel.Click

        Me.StrRise.Text = Me.StrRise.Text + (Me.IBDIncrement.Text * 1)
    End Sub

    Public Sub RunDownSel_Click(sender As Object, e As EventArgs) Handles RunDownSel.Click

        Me.StrRun.Text = Me.StrRun.Text - (Me.IBDIncrement.Text * 1)
    End Sub
    Public Sub RunUpSel_Click(sender As Object, e As EventArgs) Handles RunUpSel.Click

        Me.StrRun.Text = Me.StrRun.Text + (Me.IBDIncrement.Text * 1)
    End Sub




    Public Sub InbetweenDistanceUpSelect_Click(sender As Object, e As EventArgs) Handles InBetweenDistanceUpSelect.Click

        Me.InBetweenDistance.Text = Me.InBetweenDistance.Text + (Me.IBDIncrement.Text * 1)
    End Sub
    Public Sub InbetweenDistanceDownSelect_Click(sender As Object, e As EventArgs) Handles InbetweenDistanceDownSelect.Click
        Me.InBetweenDistance.Text = Me.InBetweenDistance.Text - (Me.IBDIncrement.Text * 1)
    End Sub
    Public Sub RailHeightUpSelect_Click(sender As Object, e As EventArgs) Handles RailHeightUpSelect.Click
        Me.RailHeight.Text = Me.RailHeight.Text + (Me.RailHeightIncrement.Text * 1)
    End Sub
    Public Sub RailheightDownSelect_Click(sender As Object, e As EventArgs) Handles RailHeightDownSelect.Click
        Me.RailHeight.Text = Me.RailHeight.Text - (Me.RailHeightIncrement.Text * 1)
    End Sub
    Public Sub DFTUpSelect_Click(sender As Object, e As EventArgs) Handles DFTUpSelect.Click
        Me.DistanceFromTop.Text = Me.DistanceFromTop.Text + (Me.DFTIncrement.Text * 1)
    End Sub
    Public Sub DFTDownSelect_Click(sender As Object, e As EventArgs) Handles DFTDownSelect.Click
        Me.DistanceFromTop.Text = Me.DistanceFromTop.Text - (Me.DFTIncrement.Text * 1)
    End Sub
    Public Sub DTBUpSelect_Click(sender As Object, e As EventArgs) Handles DTBUpSelect.Click
        Me.DistanceToBottom.Text = Me.DistanceToBottom.Text + (Me.DTBIncrement.Text * 1)
    End Sub
    Public Sub DTBDownSelect_Click(sender As Object, e As EventArgs) Handles DTBDownSelect.Click
        Me.DistanceToBottom.Text = Me.DistanceToBottom.Text - (Me.DTBIncrement.Text * 1)
    End Sub
    Public Sub PicSpaceDownSelect_Click(sender As Object, e As EventArgs) Handles PicSpaceDownSelect.Click
        Me.DesPicketSpc.Text = Me.DesPicketSpc.Text - (Me.DPSIncrement.Text * 1)
    End Sub
    Public Sub PicSpaceUpSelect_Click(sender As Object, e As EventArgs) Handles PicSpaceUpSelect.Click
        Me.DesPicketSpc.Text = Me.DesPicketSpc.Text + (Me.DPSIncrement.Text * 1)
    End Sub
    Public Sub Post2FirstStepDownSel_Click(sender As Object, e As EventArgs) Handles Post2FirstStepDownSel.Click
        Me.StepEdge.Text = Me.StepEdge.Text - (Me.StepEdgeIncrement.Text * 1)
    End Sub
    Public Sub Post2FirstStepUpSel_Click(sender As Object, e As EventArgs) Handles Post2FirstStepUpSel.Click
        Me.StepEdge.Text = Me.StepEdge.Text + (Me.StepEdgeIncrement.Text * 1)
    End Sub
    Public Sub DeckEdge2PostDownSel_Click(sender As Object, e As EventArgs) Handles DeckEdge2PostDownSel.Click
        Me.DeckEdge.Text = Me.DeckEdge.Text - (Me.DeckEdgeIncrement.Text * 1)
    End Sub
    Public Sub DeckEdge2PostUpSel_Click(sender As Object, e As EventArgs) Handles DeckEdge2PostUpSel.Click
        Me.DeckEdge.Text = Me.DeckEdge.Text + (Me.DeckEdgeIncrement.Text * 1)
    End Sub
    Public Sub AmtInGroundDownSel_Click(sender As Object, e As EventArgs) Handles AmtInGroundDownSel.Click
        Me.PostBelowGround.Text = Me.PostBelowGround.Text - (Me.AmtInGroundInc.Text * 1)
    End Sub
    Public Sub AmtInGroundUpSel_Click(sender As Object, e As EventArgs) Handles AmtInGroundUpSel.Click
        Me.PostBelowGround.Text = Me.PostBelowGround.Text + (Me.AmtInGroundInc.Text * 1)
    End Sub
    Public Sub HoleClearanceDownSel_Click(sender As Object, e As EventArgs) Handles HoleClearanceDownSel.Click
        Me.PostHoleClearance.Text = Me.PostHoleClearance.Text - (Me.HoleClearanceInc.Text * 1)
    End Sub
    Public Sub HoleClearanceUpSel_Click(sender As Object, e As EventArgs) Handles HoleClearanceUpSel.Click
        Me.PostHoleClearance.Text = Me.PostHoleClearance.Text + (Me.HoleClearanceInc.Text * 1)
    End Sub





    Public Sub Combobox3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboBox3.Click
        Me.PoLibTableAdapter1.Update(Me.PostsDBDataSet1.PoLib)
        Me.PoLibTableAdapter1.Fill(Me.PostsDBDataSet1.PoLib)
    End Sub

    Public Sub Combobox1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboBox1.Click
        Me.RaLibTableAdapter1.Update(Me.TopRailsDataSet.RaLib)
        Me.RaLibTableAdapter1.Fill(Me.TopRailsDataSet.RaLib)
        Me.RaLibTableAdapter.Update(Me.BottomRailsDBDataSet.RaLib)
        Me.RaLibTableAdapter.Fill(Me.BottomRailsDBDataSet.RaLib)
    End Sub

    Public Sub ComboBox2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboBox2.Click

        Me.RaLibTableAdapter.Update(Me.BottomRailsDBDataSet.RaLib)
        Me.RaLibTableAdapter.Fill(Me.BottomRailsDBDataSet.RaLib)
    End Sub

    Public Sub PicketComboBox_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PicketComboBox.Click
        Me.PicketLibTableAdapter.Update(Me.PicketsDataSet.PicketLib)
        Me.PicketLibTableAdapter.Fill(Me.PicketsDataSet.PicketLib)
    End Sub





    Private Sub radiobutton1_CheckedChange(sender As Object, e As EventArgs) Handles RadioButton1.CheckedChanged
        If RadioButton1.Checked = True Then
            RadioButton2.Checked = False
            GroupBox4.Hide()


            GroupBox8.Show()
            GroupBox2.Show()
            GroupBox13.Show()
            GroupBox22.Show()
            GroupBox23.Show()

            GroupBox24.Hide()
            CheckBox2.Text = "Aligned"
            StrRise.Enabled = True
            StrRise.Text = "7"
            StrRun.Enabled = True
            StrRun.Text = "11"
            DeckEdge.Enabled = True
            StepEdge.Enabled = True
            Post2FirstStepUpSel.Enabled = True
            Post2FirstStepDownSel.Enabled = True
            DeckEdge2PostUpSel.Enabled = True
            DeckEdge2PostDownSel.Enabled = True
            CheckBox2.Enabled = True
            AngleRef.Enabled = True
        Else
            If RadioButton2.Checked = True Then
                RadioButton1.Checked = False

            End If

            StrRise.Enabled = False
            StrRun.Enabled = False
            DeckEdge.Enabled = False
            StepEdge.Enabled = False
            CheckBox2.Enabled = False
            GroupBox4.Show()
            GroupBox24.Show()
            GroupBox8.Hide()
            GroupBox2.Hide()
            GroupBox13.Hide()
            GroupBox22.Hide()
            GroupBox23.Hide()

            CheckBox2.Text = "Linear"
        End If
    End Sub
    Public Sub StrRise_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles StrRise.TextChanged
        Const rad2deg = 57.2957795130823
        Const pi = 3.14159265359

        If String.IsNullOrEmpty(StrRise.Text) OrElse String.IsNullOrEmpty(StrRun.Text) Then Exit Sub
        If Not IsNumeric(StrRise.Text) OrElse Not IsNumeric(StrRun.Text) Then Exit Sub

        If RadioButton1.Checked = True Then

            AngleRef.Text = Math.Round((rad2deg * (((Math.Asin((Math.Sin((90 * pi / 180)) * StrRise.Text) / (Math.Sqrt(((StrRise.Text ^ 2) + StrRun.Text ^ 2)) - (2 * StrRise.Text * StrRun.Text) * (Math.Cos((90 * pi / 180))))))))), 1) & "°"

        End If

    End Sub
    Public Sub StrRun_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles StrRun.TextChanged
        Const rad2deg = 57.2957795130823
        Const pi = 3.14159265359

        If String.IsNullOrEmpty(StrRise.Text) OrElse String.IsNullOrEmpty(StrRun.Text) Then Exit Sub
        If Not IsNumeric(StrRise.Text) OrElse Not IsNumeric(StrRun.Text) Then Exit Sub

        If RadioButton1.Checked = True Then

            AngleRef.Text = Math.Round((rad2deg * (((Math.Asin((Math.Sin((90 * pi / 180)) * StrRise.Text) / (Math.Sqrt(((StrRise.Text ^ 2) + StrRun.Text ^ 2)) - (2 * StrRise.Text * StrRun.Text) * (Math.Cos((90 * pi / 180))))))))), 1) & "°"

        End If

    End Sub


    ''Calc Portion

    Public Sub StairCalc_Click(sender As Object, e As EventArgs) Handles StairCalc.Click

        Const pi = 3.14159265359
        Const rad2deg = 57.2957795130823
        Dim RoundValue As Integer = 3
        Dim Radians As Double
        Dim Degrees As Double
        Dim AltAngl As Double
        Dim ActPicSpc As Double
        Dim GapBase As Double
        Dim GapBaseZ As Double
        Dim TopRailHole As Double
        Dim BotRailHole As Double
        Dim InBetweenAligned As Double
        Dim DistanceFromTop As Double
        Dim DistanceToBottom As Double
        Dim TopRailHeight As Double
        Dim BotRailHeight As Double
        Dim RailHeight As Double
        Dim StrRise As Double
        Dim StrRun As Double
        Dim InBetweenDistance As Double
        Dim NumPicketHoles As Double
        Dim DesPicketSpc As Double
        Dim TopPostCutL As Double
        Dim PostThick As Double
        Dim TempCalc As Double
        Dim PicketHeight As Double
        Dim StanRailCutL As Double
        Dim PostBelowGround As Double
        Dim PostHoleClearance As Double
        Dim TopPostCutLength As Double



        DistanceFromTop = Val(Me.DistanceFromTop.Text)
        DistanceToBottom = Val(Me.DistanceToBottom.Text)
        TopRailHeight = Val(Me.TopRailHeight.Text)
        BotRailHeight = Val(Me.BotRailHeight.Text)
        RailHeight = Val(Me.RailHeight.Text)
        StrRise = Val(Me.StrRise.Text)
        StrRun = Val(Me.StrRun.Text)
        InBetweenDistance = Val(Me.InBetweenDistance.Text)
        NumPicketHoles = Val(Me.NumPicketHoles.Text)
        PostThick = Val(Me.PostThick.Text)
        PicketHeight = Val(Me.PicketHeight.Text)
        DistanceToBottom = Val(Me.DistanceToBottom.Text)
        DistanceFromTop = Val(Me.DistanceFromTop.Text)
        RailHeight = Val(Me.RailHeight.Text)
        PostBelowGround = Val(Me.PostBelowGround.Text)
        BotRailHeight = Val(Me.BotRailHeight.Text)
        PostHoleClearance = Val(Me.PostHoleClearance.Text)
        DistanceFromTop = Val(Me.DistanceFromTop.Text)
        DistanceToBottom = Val(Me.DistanceToBottom.Text)
        BotRailHeight = Val(Me.BotRailHeight.Text)
        RailHeight = Val(Me.RailHeight.Text)
        StrRise = Val(Me.StrRise.Text)
        StrRun = Val(Me.StrRun.Text)
        TopPostCutLength = Val(Me.TopPostCutLength.Text)
        PostThick = Val(Me.PostThick.Text)
        PicketHeight = Val(Me.PicketHeight.Text)





        If Not IsNumeric(Me.RailHeight.Text) Then
            MsgBox("Enter a numeric value for Railing Height.")
            Me.RailHeight.Select()
            Exit Sub

        End If
        If Me.RailHeight.Text < (TopRailHeight + BotRailHeight + DistanceFromTop + DistanceToBottom) Then
            TempCalc = (TopRailHeight + BotRailHeight + DistanceFromTop + DistanceToBottom)
            MsgBox("Railing Height must be greater than" & Space(1) & TempCalc)
            Me.RailHeight.Focus()
            Exit Sub
        End If
        If Not IsNumeric(Me.InBetweenDistance.Text) Then
            MsgBox("Enter a numeric value for In-between Distance.")
            Me.InBetweenDistance.Text = ""
            Me.InBetweenDistance.Focus()
            Exit Sub
        End If
        If Me.InBetweenDistance.Text < ((DesPicketSpc * 2) + PicketHeight) Then
            TempCalc = ((DesPicketSpc * 2) + PicketHeight)
            MsgBox("In-between distance must be greater than or equal to" & Space(1) & TempCalc)
            Me.InBetweenDistance.Text = ""
            Me.InBetweenDistance.Focus()
            Exit Sub
        End If
        If Not IsNumeric(Me.DistanceToBottom.Text) Then
            MsgBox("Enter a numeric value for Distance To Bottom.")
            Me.DistanceToBottom.Text = ""
            Me.DistanceToBottom.Focus()
        End If
        If Me.DistanceToBottom.Text = 0 Then
            MsgBox("Distance To Bottom must be greater than zero.")
            Me.DistanceToBottom.Text = ""
            Me.DistanceToBottom.Focus()
            Exit Sub
        End If
        If Not IsNumeric(Me.PicketHeight.Text) Then
            MsgBox("Enter a numeric value for Picket Size")
            Me.PicketHeight.Text = ""
            Me.PicketHeight.Focus()
        End If
        If Me.PicketHeight.Text = 0 Then
            MsgBox("Picket Size must be greater than zero.")
            Me.PicketHeight.Select()
            Exit Sub
        End If
        If Not IsNumeric(Me.InBetweenDistance.Text) Then
            MsgBox("Enter a numeric value for In-between Distance.")
            Me.InBetweenDistance.Text = ""
            Me.InBetweenDistance.Focus()
            Exit Sub
        End If
        If Me.InBetweenDistance.Text < ((DesPicketSpc * 2) + PicketHeight) Then
            TempCalc = ((DesPicketSpc * 2) + PicketHeight)
            MsgBox("In-between distance must be greater than or equal to" & Space(1) & TempCalc)
            Me.InBetweenDistance.Text = ""
            Me.InBetweenDistance.Focus()
            Exit Sub
        End If
        If Not IsNumeric(Me.PicketHeight.Text) Then
            MsgBox("Enter a value for Picket Size.")
            Me.PicketHeight.Text = ""
            Me.PicketHeight.Focus()
            Exit Sub
        End If
        If Me.PicketHeight.Text = "" Then
            MsgBox("Picket Size must be greater than Zero")
            Me.PicketHeight.Text = ""
            Me.PicketHeight.Focus()
            Exit Sub
        End If
        If Not IsNumeric(Me.DesPicketSpc.Text) Then
            MsgBox("Enter a numeric value for Picket Spacing.")
            Me.DesPicketSpc.Text = ""
            Exit Sub
        End If
        If Me.DesPicketSpc.Text = "0" Then
            MsgBox("Picket Spacing must be greater than Zero")
            Me.DesPicketSpc.Text = ""
            Me.DesPicketSpc.Focus()
            Exit Sub
        End If
        If Not IsNumeric(Me.RailHeight.Text) Then
            MsgBox("Enter a numeric value for Railing Height.")
            Me.RailHeight.Select()
            Exit Sub
        End If
        If Me.RailHeight.Text < (TopRailHeight + BotRailHeight + DistanceFromTop + DistanceToBottom) Then
            TempCalc = (TopRailHeight + BotRailHeight + DistanceFromTop + DistanceToBottom)
            MsgBox("Railing Height must be greater than" & Space(1) & TempCalc)
            Me.RailHeight.Focus()
            Exit Sub
        End If
        If Not IsNumeric(Me.PostBelowGround.Text) Then
            MsgBox("Enter a numeric value for Amount Below Ground.")
            Me.PostBelowGround.Text = ""
            Exit Sub
        End If
        If Not IsNumeric(Me.PostHoleClearance.Text) Then
            MsgBox("Enter a numeric value for Picket Spacing.")
            Me.PostHoleClearance.Text = ""
            Exit Sub
        End If
        If Not IsNumeric(Me.RailHeight.Text) Then
            MsgBox("Enter a numeric value for Railing Height.")
            Me.RailHeight.Select()
            Exit Sub

        End If
        If Me.RailHeight.Text < (TopRailHeight + BotRailHeight + DistanceFromTop + DistanceToBottom) Then
            TempCalc = (TopRailHeight + BotRailHeight + DistanceFromTop + DistanceToBottom)
            MsgBox("Railing Height must be greater than" & Space(1) & TempCalc)
            Me.RailHeight.Focus()
            Exit Sub
        End If
        If Not IsNumeric(Me.DistanceToBottom.Text) Then
            MsgBox("Enter a numeric value for Distance To Bottom.")
            Me.DistanceToBottom.Text = ""
            Me.DistanceToBottom.Focus()
        End If
        If Me.DistanceToBottom.Text = 0 Then
            MsgBox("Distance To Bottom must be greater than zero.")
            Me.DistanceToBottom.Text = ""
            Me.DistanceToBottom.Focus()
            Exit Sub
        End If
        If RadioButton1.Checked = True Then
            If Me.StrRise.Text = 0 Then
                MsgBox("Stair Rise cannot be zero.")
                Me.StrRise.Text = ""
                Me.StrRise.Focus()
                Exit Sub
            End If
            If Me.StrRun.Text = 0 Then
                MsgBox("Stair Run cannot be zero.")
                Me.StrRun.Text = ""
                Me.StrRun.Focus()
                Exit Sub
            End If
        End If




        If RadioButton1.Checked = True Then

            Radians = ((Math.Asin((Math.Sin((90 * pi / 180)) * StrRise) / (Math.Sqrt(((StrRise ^ 2) + StrRun ^ 2)) - (2 * StrRise * StrRun) * (Math.Cos((90 * pi / 180)))))))
            Degrees = (rad2deg * Radians)
            AltAngl = ((90 - Degrees) * (3.14159265359 / 180))
            TopPostCutL = Math.Round((TopPostCutL), RoundValue)
            GapBase = StrRun - DeckEdge.Text - StepEdge.Text
            GapBaseZ = GapBase * Math.Tan(Radians)
            TopRailHole = Math.Round((Me.PicketHeight.Text / (StrRun / (Math.Sqrt((StrRise ^ 2) + StrRun ^ 2)))) + (TopRailThick.Text * Math.Tan(Radians)), RoundValue)
            BotRailHole = Math.Round((Me.PicketHeight.Text / (StrRun / (Math.Sqrt((StrRise ^ 2) + StrRun ^ 2)))) + (BotRailThick.Text * Math.Tan(Radians)), RoundValue)
            DesPicketSpc = Math.Round((Me.DesPicketSpc.Text / (StrRun / (Math.Sqrt((StrRise ^ 2) + StrRun ^ 2)))), RoundValue)



            If RadioButton1.Checked = True Then
                InBetweenAligned = Me.InBetweenDistance.Text
                Label2.Text = Math.Round(InBetweenAligned * (Math.Cos(Radians)), RoundValue)
                GroupBox27.Text = "Actual IBD"
            Else
                InBetweenAligned = Me.InBetweenDistance.Text * (Math.Cos(Radians) ^ -1)
                Label2.Text = Math.Round(Me.InBetweenDistance.Text / (Math.Cos(Radians)), RoundValue)
                GroupBox27.Text = "Aligned IBD"
            End If





            Me.NumPicketHoles.Text = Fix(InBetweenAligned / (DesPicketSpc + TopRailHole))











            ActPicSpc = (InBetweenAligned * Math.Cos(Radians) - ((NumPicketHoles * (Me.PicketHeight.Text)) / (NumPicketHoles + 1)))
            TopStrRailCutL.Text = Math.Round(InBetweenAligned + ((BotRailThick.Text) * Math.Cos(((Degrees * 2 * pi) / 360)) ^ -1) + (((TopRailThick.Text) * Math.Cos(((Degrees * 2 * pi) / 360)) ^ -1)) + ((Me.TopRailHeight.Text * Math.Tan((Degrees * 2 * pi) / 360))) + (Me.ExtraEndMat.Text * 2), RoundValue)

            Me.TopRailHole.Text = TopRailHole
            TopStrRailPicSpace.Text = Math.Round(((InBetweenAligned - (Me.NumPicketHoles.Text * (TopRailHole))) / (Me.NumPicketHoles.Text + 1)), RoundValue)
            TopStrRailDisFirstHole.Text = Math.Round((((Me.TopRailHeight.Text * Math.Tan((Degrees * 2 * pi) / 360))) + TopStrRailPicSpace.Text + ((TopRailThick.Text) * Math.Cos(((Degrees * 2 * pi) / 360)) ^ -1) + ExtraEndMat.Text) - (PostThick * Math.Tan(Radians) / 2), RoundValue)

            BotStrRailCutL.Text = Math.Round(InBetweenAligned + ((BotRailThick.Text) * Math.Cos(((Degrees * 2 * pi) / 360)) ^ -1) + ((TopRailThick.Text) * Math.Cos(((Degrees * 2 * pi) / 360)) ^ -1) + ((Me.BotRailHeight.Text * Math.Tan((Degrees * 2 * pi) / 360))) + (ExtraEndMat.Text * 2), RoundValue)
            Me.BotRailHole.Text = BotRailHole
            BotStrRailPicSpace.Text = Math.Round((((InBetweenAligned - (Me.NumPicketHoles.Text * (BotRailHole)))) / (Me.NumPicketHoles.Text + 1)), RoundValue)
            BotStrRailDisFirstHole.Text = Math.Round((BotStrRailPicSpace.Text + ((BotRailThick.Text) * Math.Cos(((Degrees * 2 * pi) / 360)) ^ -1) + ExtraEndMat.Text) + (PostThick * Math.Tan(Radians) * 0.5), RoundValue) 'addeda half

            'ActPicketSpc.Text = Math.Round((TopStrRailPicSpace.Text * Math.Cos(Radians)) + (PostThick * Math.Tan(Radians)), RoundValue)
            PostFirstHole.Text = Math.Round(TopRailHeight / (StrRun / (Math.Sqrt((StrRise ^ 2) + (StrRun ^ 2)))) + (PostThick / Math.Tan(AltAngl)), RoundValue)
            PostSecondHole.Text = Math.Round(BotRailHeight / (StrRun / (Math.Sqrt((StrRise ^ 2) + (StrRun ^ 2)))) + (PostThick / Math.Tan(AltAngl)), RoundValue)
            TopPostFirstHole2.Text = Math.Round(DistanceFromTop - PostThick * Math.Tan(Radians), RoundValue)
            BotPostFirstHole2.Text = Math.Round((DistanceFromTop), RoundValue)

            BetweenHolesSlope.Text = Math.Round((RailHeight - PostFirstHole.Text - PostSecondHole.Text - DistanceToBottom) + (PostThick * Math.Tan(Radians)), RoundValue)
            PicketCutL.Text = Math.Round(BetweenHolesSlope.Text + (Convert.ToDecimal(PostFirstHole.Text) + PostSecondHole.Text) - Me.PostThick.Text * Math.Tan(Radians) - (Me.PicketHeight.Text * Math.Tan(Radians)) - (Me.TopRailThick.Text / Math.Cos(Radians)) - (Me.BotRailThick.Text / Math.Cos(Radians)) - Me.PicketClear.Text, RoundValue)
            Me.TopPostCutLength.Text = Math.Round((RailHeight + DistanceFromTop), RoundValue)

            BotPostCutLength.Text = Math.Round(((RailHeight + DistanceFromTop) + GapBaseZ), RoundValue)

        Else

            PicketCutL.Text = (Me.RailHeight.Text - Me.DistanceToBottom.Text - TopRailThick.Text - BotRailThick.Text - PicketClear.Text)
            DesPicketSpc = Val(Me.DesPicketSpc.Text)



            Me.TopStrRailCutL.Text = "0.000"
            Me.TopRailHole.Text = "0.000"
            Me.TopStrRailDisFirstHole.Text = "0.000"
            Me.TopStrRailPicSpace.Text = "0.000"
            Me.BotStrRailCutL.Text = "0.000"
            Me.BotRailHole.Text = "0.000"
            Me.BotStrRailDisFirstHole.Text = "0.000"
            Me.BotStrRailPicSpace.Text = "0.000"

            Me.NumPicketHoles.Text = "0.000"
            Me.Label2.Text = "0.000"



        End If

        StanRailCutL = Math.Round(Me.InBetweenDistance.Text + (ExtraEndMat.Text * 2), RoundValue)
        Me.StanRailCutL.Text = StanRailCutL



        Me.NumPicketHoles.Text = Fix(Me.InBetweenDistance.Text / (DesPicketSpc + PicketHeight))








        PostCutLength.Text = RailHeight + DistanceFromTop + PostBelowGround
        BetweenHolesNoSlope.Text = (Me.RailHeight.Text - Me.DistanceToBottom.Text - Me.TopRailHeight.Text - Me.BotRailHeight.Text - (Me.PostHoleClearance.Text * 2))
        Me.PicketSpaceNoSlope.Text = Math.Round(((Me.InBetweenDistance.Text - (Me.NumPicketHoles.Text * (PicketHeight))) / (Me.NumPicketHoles.Text + 1)), RoundValue)
        StanDistFirstHole.Text = ((StanRailCutL - Me.InBetweenDistance.Text) / 2) + Me.picketspacenoslope.Text

    End Sub











    ''' Reset Portion










    Private Sub Reset_Click(sender As Object, e As EventArgs) Handles StairReset.Click
        TopStrRailCutL.Text = "-.---"
        TopRailHole.Text = "-.---"
        TopStrRailDisFirstHole.Text = "-.---"
        TopStrRailPicSpace.Text = "-.---"
        NumPicketHoles.Text = "-.---"
        BotStrRailCutL.Text = "-.---"
        BotRailHole.Text = "-.---"
        BotStrRailDisFirstHole.Text = "-.---"
        BotStrRailPicSpace.Text = "-.---"
        PicketCutL.Text = "-.---"
        '  ActPicketSpc.Text = "-.---"
        AngleRef.Text = "-.---"
        RailHeight.Text = ""
        StrRise.Text = ""
        StrRun.Text = ""
        InBetweenDistance.Text = ""
        DistanceFromTop.Text = ""
        DistanceToBottom.Text = ""
        PostThick.Text = ""
        TopRailHeight.Text = ""
        BotRailHeight.Text = ""
        ExtraEndMat.Text = ""
        TopRailThick.Text = ""
        ExtraEndMat.Text = ""
        BotRailThick.Text = ""
        PicketHeight.Text = ""
        DesPicketSpc.Text = ""
        PicketClear.Text = ""
        'DeckEdge.Text = ""
        ' StepEdge.Text = ""
        RailHeight.Select()
    End Sub












    ''External porgrams














    Public Sub RailingDB_Click(sender As Object, e As EventArgs) Handles RailingDB.Click
        RailLibrary.Show()
    End Sub

    Public Sub PostDB_Click(sender As Object, e As EventArgs) Handles PostDB.Click
        PostLibrary.Show()
    End Sub

    Public Sub PicketsDB_Click(sender As Object, e As EventArgs) Handles PicketsDB.Click
        PicketLibrary.Show()




    End Sub

    Public Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        '  e.Graphics.FillRectangle(Brushes.Blue, New Rectangle(520, 70, 130, 25))
        If RadioButton1.Checked = True Then

        End If
        Dim dt As New DataTable


        dt.Columns.Add("Cut Length")
            dt.Columns.Add("# of Holes")
            dt.Columns.Add("Spacing")




        Dim row1 As DataRow = dt.NewRow
        row1.Item("Cut Length") = StanRailCutL.Text
        row1.Item("# of Holes") = Me.NumPicketHoles.Text
        If RadioButton1.Checked = True Then
            row1.Item("Spacing") = PicketSpaceNoSlope.Text
        Else


            row1.Item("Spacing") = PicketSpaceNoSlope.Text
        End If
        dt.Rows.Add(row1)
        DataGridView1.DataSource = dt
    End Sub



    ' the above code we have created a New SolidBrush drawing object using color blue And assigned it to variable blueBrush. The next step Is to use the brush to draw a shape 
    ' Private Sub MainPage_Paint(ByVal sender As Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles Me.Paint
    ' Dim blueBrush As New Drawing.SolidBrush(Color.Blue)
    'Dim ez As Single
    '    ez = ez + 1
    '  e.Graphics.FillRectangle(blueBrush, ez, ez, 100, 100)
    '  End Sub




End Class


' Cent2Cent.Text = PicketSpaceNoSlope + 3