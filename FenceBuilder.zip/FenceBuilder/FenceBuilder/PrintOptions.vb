﻿Imports System.Collections.Generic

Public Class PrintOptions
    Public Sub New(ByVal availableFields As List(Of String))

        InitializeComponent()

        For Each field As String In availableFields
            Chklst.Items.Add(field, True)
        Next
    End Sub

    Private Sub PrintOptions_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        'Initialize some controls

        ChkZoomFull.Checked = True

    End Sub

    Private Sub btnOK_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnOK.Click

        Me.DialogResult = Windows.Forms.DialogResult.OK

        Me.Close()

    End Sub
    Private Sub btnCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnCancel.Click
        Me.DialogResult = Windows.Forms.DialogResult.Cancel
        Me.Close()
    End Sub

    Public Function GetSelectedColumns() As List(Of String)
        Dim lst As New List(Of String)
        For Each item As Object In Chklst.CheckedItems
            lst.Add(item.ToString)
        Next
        Return lst
    End Function

    Public ReadOnly Property Zoom100() As Boolean
        Get
            Return ChkZoomFull.Checked

        End Get
    End Property

End Class



