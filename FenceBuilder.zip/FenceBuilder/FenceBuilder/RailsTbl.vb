﻿
Public Class RailsTbl
    ' To display the data in datagridview control
    Private Sub RailsTbl_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        DataGridView1.DataSource = RaDst.Tables(0)
    End Sub
    ' To close the current form and display main frame
    Private Sub RailsTableExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RailsTableExit.Click
        Me.Close()
        RailLibrary.Show()
    End Sub
End Class
