﻿
Imports System.Data.OleDb


Public Class RailLibrary
    Dim DataGridView1 As New DataGridView
    Private Sub RailLibrary_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        Me.RaLibTableAdapter.Fill(Me.RailsLibraryDataSet1.RaLib)
        Me.RaLibTableAdapter.Update(Me.RailsLibraryDataSet1.RaLib) 'must have this to load data in to the drop down menu.

        RaCurrentRow = 0
        RaCon.Open()
        RaDad = New OleDbDataAdapter("SELECT * FROM RaLib ORDER BY ID", RaCon)
        RaDad.Fill(RaDst, "RaLib")
        ShowData(RaCurrentRow)
        DataGridView1.DataSource = RaDst.Tables(0)
        RaCon.Close()
    End Sub

    Private Sub ShowData(ByVal CurrentRow)
        Try
            RaID.Text = RaDst.Tables("RaLib").Rows(CurrentRow)("ID")
            RaHeight.Text = RaDst.Tables("RaLib").Rows(CurrentRow)("Height")
            RaWidth.Text = RaDst.Tables("RaLib").Rows(CurrentRow)("Width")
            RaThick.Text = RaDst.Tables("RaLib").Rows(CurrentRow)("Thickness")
            RaRad.Text = RaDst.Tables("RaLib").Rows(CurrentRow)("Radius")
        Catch ex As Exception
        End Try
    End Sub





    ' To exit from application
    Private Sub ExitNow_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ExitNow.Click
        Me.RaLibTableAdapter.Update(Me.RailsLibraryDataSet1.RaLib)
        Me.RaLibTableAdapter.Fill(Me.RailsLibraryDataSet1.RaLib)
        DataGridView1.DataSource.clear
        Me.Close()
    End Sub


    ' To clear all fields : Id, First Name, Last Name, MaterialThickness, Salary
    Private Sub Clear()
        RaID.Text = ""
        RaHeight.Text = ""
        RaWidth.Text = ""
        RaThick.Text = ""
        RaRad.Text = ""
    End Sub





    ' To insert the record in database
    Private Sub Insert_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Insert.Click

        Dim Str As String

        If IfIdExist() = True Then
            MsgBox("Material already found in Database. Consider renaming you must.")
            Exit Sub
        ElseIf CheckMaterialHeight() = False Then
            MsgBox("Material Height : Only Numbers Allowed!!!")
            Exit Sub
        ElseIf CheckMaterialWidth() = False Then
            MsgBox("Material Width : Only Numbers Allowed!!!")
            Exit Sub
        ElseIf CheckMatThick() = False Then
            MsgBox("Material Thickness : Only Numbers Allowed!!!")
            Exit Sub
        ElseIf CheckMatRad() = False Then
            MsgBox("Material Radius : Only Numbers Allowed!!!")
            Exit Sub
        End If

        Try
            Str = "INSERT INTO RaLib VALUES("
            Str += """" & RaID.Text & """"
            Str += ","
            Str += RaHeight.Text
            Str += ","
            Str += RaWidth.Text
            Str += ","
            Str += RaThick.Text
            Str += ","
            Str += RaRad.Text
            Str += ")"
            RaCon.Open()
            RaCmd = New OleDbCommand(Str, RaCon)
            RaCmd.ExecuteNonQuery()
            RaDad = New OleDbDataAdapter("SELECT * FROM RaLib ORDER BY ID", RaCon)
            MsgBox("Record inserted successfully...")
            DataGridView1.DataSource.clear
            RaCon.Close()
        Catch ex As Exception
            MessageBox.Show("Incorrect Data Entered!!!")
            MsgBox(ex.Message & " -  " & ex.Source)
        End Try
        Me.Close()
        Me.RaLibTableAdapter.Update(Me.RailsLibraryDataSet1.RaLib)
        Me.RaLibTableAdapter.Fill(Me.RailsLibraryDataSet1.RaLib) 'must have this to loan data in the drop down menu.

    End Sub






    ' To delete the record from database
    Private Sub Delete_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Delete.Click

        If IfIdExist() = False Then
            MsgBox("Record not found.")
        Else


            Dim Str As String

            Try
                Str = "delete from RaLib where ID="
                Str += """" & RaID.Text & """"
                RaCon.Open()
                RaCmd = New OleDbCommand(Str, RaCon)
                RaCmd.ExecuteNonQuery()
                RaDst.clear()
                RaDad = New OleDbDataAdapter("SELECT * FROM RaLib ORDER BY ID", RaCon)
                RaDad.Fill(RaDst, "MaterialType")
                MsgBox("Record deleted successfully...")
                If RaCurrentRow > 0 Then
                    RaCurrentRow -= 1
                    ShowData(RaCurrentRow)
                End If
                RaDad.Fill(RaDst, "RaLib")
                Me.RaLibTableAdapter.Update(Me.RailsLibraryDataSet1.RaLib)
                Me.RaLibTableAdapter.Fill(Me.RailsLibraryDataSet1.RaLib) 'must have this to loan data in the drop down menu.
                RaCon.Close()
            Catch ex As Exception
                MessageBox.Show("Could Not delete Record!")
                MsgBox(ex.Message & " -  " & ex.Source)
            End Try
        End If
        Me.RaLibTableAdapter.Update(Me.RailsLibraryDataSet1.RaLib) 'must have this to load data in the drop down menu.
        Me.RaLibTableAdapter.Fill(Me.RailsLibraryDataSet1.RaLib) 'must have this to load data in the drop down menu.

    End Sub


    ' To update the records in database
    Private Sub Updates_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Updates.Click
        Dim Str As String
        If CheckMaterialHeight() = False Then
            MsgBox("Material Height : Only Numbers Allowed!!!")
            Exit Sub
        ElseIf CheckMaterialWidth() = False Then
            MsgBox("Material Width : Only Numbers Allowed!!!")
            Exit Sub
        ElseIf CheckMatThick() = False Then
            MsgBox("Material Thickness : Only Numbers Allowed!!!")
            Exit Sub
        ElseIf CheckMatRad() = False Then
            MsgBox("Material Radius : Only Numbers Allowed!!!")
            Exit Sub
        End If


        Try

            Str = "update RaLib set Height="
            Str += """" & RaHeight.Text & """"
            Str += " where ID="
            Str += """" & RaID.Text & """"
            RaCon.Open()
            RaCmd = New OleDbCommand(Str, RaCon)
            RaCmd.ExecuteNonQuery()
            RaCon.Close()
            RaCon.Open()
            Str = "update RaLib set Width="
            Str += """" & RaWidth.Text & """"
            Str += " where ID="
            Str += """" & RaID.Text & """"
            RaCmd = New OleDbCommand(Str, RaCon)
            RaCmd.ExecuteNonQuery()
            RaCon.Close()
            RaCon.Open()
            Str = "update RaLib set Thickness="
            Str += """" & RaThick.Text & """"
            Str += " where ID="
            Str += """" & RaID.Text & """"
            RaCmd = New OleDbCommand(Str, RaCon)
            RaCmd.ExecuteNonQuery()
            RaCon.Close()
            RaCon.Open()
            Str = "update RaLib set Radius="
            Str += """" & RaRad.Text & """"
            Str += " where ID="
            Str += """" & RaID.Text & """"
            RaCmd = New OleDbCommand(Str, RaCon)
            RaCmd.ExecuteNonQuery()
            RaCon.Close()

            RaDst.Clear()
            RaDad = New OleDbDataAdapter("SELECT * FROM RaLib ORDER BY ID", RaCon)
            RaDad.Fill(RaDst, "RaLib")
            MsgBox("Updated Successfully...")

        Catch ex As Exception
            MsgBox(ex.Message & "--" & ex.Source)
            RaCon.Close()

        End Try

        Me.RaLibTableAdapter.Update(Me.RailsLibraryDataSet1.RaLib)
        Me.RaLibTableAdapter.Fill(Me.RailsLibraryDataSet1.RaLib) 'must have this to loan data in the drop down menu.

    End Sub

    ' To check the data in Id field : whether numeric or not 
    Private Function CheckId()
        Try
            If IsNumeric(RaID.Text) = True Then
                ShowData(RaCurrentRow)
                RaID.Focus()
                Return False
            End If
        Catch ex As Exception
        End Try
        Return True
    End Function

    ' To check the data in First : whether a string or not
    Private Function CheckMaterialHeight()
        Try
            If IsNumeric(RaHeight.Text) = True Then
                'ShowData(RaCurrentRow)
                ' RaHeight.Focus()
                Return True
            End If
        Catch ex As Exception
        End Try
        Return False
    End Function

    ' To check the data in Second Field : whether a string or not
    Private Function CheckMaterialWidth()
        Try
            If IsNumeric(RaWidth.Text) = True Then
                ' ShowData(CurrentRow)
                ' MatWidth.Focus()
                Return True
            End If
        Catch ex As Exception
        End Try
        Return False
    End Function

    ' To check the data in Third Field : whether a string or not
    Private Function CheckMatThick()
        Try
            If IsNumeric(RaThick.Text) = True Then
                '  ShowData(CurrentRow)
                ' MatThick.Focus()
                Return True
            End If
        Catch ex As Exception
        End Try
        Return False
    End Function

    ' To check the data in Fourth Field : whether a string or not
    Private Function CheckMatRad()
        Try
            If IsNumeric(RaRad.Text) = True Then
                '  ShowData(CurrentRow)
                ' MatRad.Focus()
                Return True
            End If
        Catch ex As Exception
        End Try
        Return False
    End Function

    ' To check the string for numeric values
    Private Function ValidateString(ByVal Str)
        Dim i As Integer
        Dim ch As Char
        i = 0
        While i < Str.Length()
            ch = Str.Chars(i)
            If IsNumeric(ch) = True Then
                Return False
            End If
            i += 1
        End While
        Return True
    End Function

    ' To show the data in the datagridview
    Private Sub ShowRaLib_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ShowRaLib.Click
        Me.Hide()
        Me.RaLibTableAdapter.Update(Me.RailsLibraryDataSet1.RaLib) 'must have this to load data in to the drop down menu.
        RailsTbl.Show()
    End Sub




    ' To check whether Id exist in database
    Private Function IfIdExist()
        Dim Str, Str1 As String
        Dim i As Integer
        Str = RaID.Text
        i = 0
        While i <> RaDst.Tables("RaLib").rows.count
            Str1 = RaDst.Tables("RaLib").Rows(i)("ID")
            If Str = Str1 Then
                Return True
            End If
            i += 1
        End While
        Return False
    End Function

End Class