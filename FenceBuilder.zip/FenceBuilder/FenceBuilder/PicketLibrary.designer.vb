﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class PicketLibrary
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(PicketLibrary))
        Me.label10 = New System.Windows.Forms.Label()
        Me.PicketRad = New System.Windows.Forms.TextBox()
        Me.PicketID = New System.Windows.Forms.ComboBox()
        Me.ShowPicketLib = New System.Windows.Forms.Button()
        Me.DeletePicketLibrary = New System.Windows.Forms.Button()
        Me.PicketLibraryUpdate = New System.Windows.Forms.Button()
        Me.PicketLibraryInsert = New System.Windows.Forms.Button()
        Me.label9 = New System.Windows.Forms.Label()
        Me.label8 = New System.Windows.Forms.Label()
        Me.label7 = New System.Windows.Forms.Label()
        Me.PicketThick = New System.Windows.Forms.TextBox()
        Me.PicketWidth = New System.Windows.Forms.TextBox()
        Me.PicketHeight = New System.Windows.Forms.TextBox()
        Me.PicketLibraryExit = New System.Windows.Forms.Button()
        Me.label6 = New System.Windows.Forms.Label()
        Me.PicketsDBDataSet = New FenceBuilderRootNmspc.PicketsDBDataSet()
        Me.PicketLibBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.PicketLibTableAdapter = New FenceBuilderRootNmspc.PicketsDBDataSetTableAdapters.PicketLibTableAdapter()
        CType(Me.PicketsDBDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PicketLibBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'label10
        '
        Me.label10.AutoSize = True
        Me.label10.Location = New System.Drawing.Point(49, 130)
        Me.label10.Name = "label10"
        Me.label10.Size = New System.Drawing.Size(40, 13)
        Me.label10.TabIndex = 41
        Me.label10.Text = "Radius"
        '
        'PicketRad
        '
        Me.PicketRad.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.PicketRad.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.PicketLibBindingSource, "Radius", True))
        Me.PicketRad.Location = New System.Drawing.Point(93, 126)
        Me.PicketRad.Name = "PicketRad"
        Me.PicketRad.Size = New System.Drawing.Size(121, 20)
        Me.PicketRad.TabIndex = 5
        '
        'PicketID
        '
        Me.PicketID.DataSource = Me.PicketLibBindingSource
        Me.PicketID.DisplayMember = "ID"
        Me.PicketID.FormattingEnabled = True
        Me.PicketID.Location = New System.Drawing.Point(93, 13)
        Me.PicketID.Name = "PicketID"
        Me.PicketID.Size = New System.Drawing.Size(121, 21)
        Me.PicketID.TabIndex = 1
        '
        'ShowPicketLib
        '
        Me.ShowPicketLib.Location = New System.Drawing.Point(253, 13)
        Me.ShowPicketLib.Name = "ShowPicketLib"
        Me.ShowPicketLib.Size = New System.Drawing.Size(75, 23)
        Me.ShowPicketLib.TabIndex = 8
        Me.ShowPicketLib.Text = "Show Data"
        Me.ShowPicketLib.UseVisualStyleBackColor = True
        '
        'DeletePicketLibrary
        '
        Me.DeletePicketLibrary.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.DeletePicketLibrary.Location = New System.Drawing.Point(253, 50)
        Me.DeletePicketLibrary.Name = "DeletePicketLibrary"
        Me.DeletePicketLibrary.Size = New System.Drawing.Size(75, 23)
        Me.DeletePicketLibrary.TabIndex = 9
        Me.DeletePicketLibrary.Text = "Delete"
        Me.DeletePicketLibrary.UseVisualStyleBackColor = True
        '
        'PicketLibraryUpdate
        '
        Me.PicketLibraryUpdate.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.PicketLibraryUpdate.Location = New System.Drawing.Point(136, 159)
        Me.PicketLibraryUpdate.Name = "PicketLibraryUpdate"
        Me.PicketLibraryUpdate.Size = New System.Drawing.Size(75, 23)
        Me.PicketLibraryUpdate.TabIndex = 7
        Me.PicketLibraryUpdate.Text = "Update"
        Me.PicketLibraryUpdate.UseVisualStyleBackColor = True
        '
        'PicketLibraryInsert
        '
        Me.PicketLibraryInsert.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.PicketLibraryInsert.Location = New System.Drawing.Point(58, 159)
        Me.PicketLibraryInsert.Name = "PicketLibraryInsert"
        Me.PicketLibraryInsert.Size = New System.Drawing.Size(75, 23)
        Me.PicketLibraryInsert.TabIndex = 6
        Me.PicketLibraryInsert.Text = "Insert"
        Me.PicketLibraryInsert.UseVisualStyleBackColor = True
        '
        'label9
        '
        Me.label9.AutoSize = True
        Me.label9.Location = New System.Drawing.Point(33, 102)
        Me.label9.Name = "label9"
        Me.label9.Size = New System.Drawing.Size(56, 13)
        Me.label9.TabIndex = 37
        Me.label9.Text = "Thickness"
        '
        'label8
        '
        Me.label8.AutoSize = True
        Me.label8.Location = New System.Drawing.Point(54, 74)
        Me.label8.Name = "label8"
        Me.label8.Size = New System.Drawing.Size(35, 13)
        Me.label8.TabIndex = 36
        Me.label8.Text = "Width"
        '
        'label7
        '
        Me.label7.AutoSize = True
        Me.label7.Location = New System.Drawing.Point(51, 47)
        Me.label7.Name = "label7"
        Me.label7.Size = New System.Drawing.Size(38, 13)
        Me.label7.TabIndex = 35
        Me.label7.Text = "Height"
        '
        'PicketThick
        '
        Me.PicketThick.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.PicketThick.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.PicketLibBindingSource, "Thickness", True))
        Me.PicketThick.Location = New System.Drawing.Point(93, 98)
        Me.PicketThick.Name = "PicketThick"
        Me.PicketThick.Size = New System.Drawing.Size(121, 20)
        Me.PicketThick.TabIndex = 4
        '
        'PicketWidth
        '
        Me.PicketWidth.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.PicketWidth.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.PicketLibBindingSource, "Width", True))
        Me.PicketWidth.Location = New System.Drawing.Point(93, 71)
        Me.PicketWidth.Name = "PicketWidth"
        Me.PicketWidth.Size = New System.Drawing.Size(121, 20)
        Me.PicketWidth.TabIndex = 3
        '
        'PicketHeight
        '
        Me.PicketHeight.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.PicketHeight.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.PicketLibBindingSource, "Height", True))
        Me.PicketHeight.Location = New System.Drawing.Point(93, 43)
        Me.PicketHeight.Name = "PicketHeight"
        Me.PicketHeight.Size = New System.Drawing.Size(121, 20)
        Me.PicketHeight.TabIndex = 2
        '
        'PicketLibraryExit
        '
        Me.PicketLibraryExit.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.PicketLibraryExit.Location = New System.Drawing.Point(253, 159)
        Me.PicketLibraryExit.Name = "PicketLibraryExit"
        Me.PicketLibraryExit.Size = New System.Drawing.Size(75, 23)
        Me.PicketLibraryExit.TabIndex = 10
        Me.PicketLibraryExit.Text = "Exit"
        Me.PicketLibraryExit.UseVisualStyleBackColor = True
        '
        'label6
        '
        Me.label6.AutoSize = True
        Me.label6.Location = New System.Drawing.Point(18, 17)
        Me.label6.Name = "label6"
        Me.label6.Size = New System.Drawing.Size(71, 13)
        Me.label6.TabIndex = 33
        Me.label6.Text = "Material Type"
        '
        'PicketsDBDataSet
        '
        Me.PicketsDBDataSet.DataSetName = "PicketsDBDataSet"
        Me.PicketsDBDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'PicketLibBindingSource
        '
        Me.PicketLibBindingSource.DataMember = "PicketLib"
        Me.PicketLibBindingSource.DataSource = Me.PicketsDBDataSet
        '
        'PicketLibTableAdapter
        '
        Me.PicketLibTableAdapter.ClearBeforeFill = True
        '
        'PicketLibrary
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(345, 202)
        Me.Controls.Add(Me.label10)
        Me.Controls.Add(Me.PicketRad)
        Me.Controls.Add(Me.PicketID)
        Me.Controls.Add(Me.ShowPicketLib)
        Me.Controls.Add(Me.DeletePicketLibrary)
        Me.Controls.Add(Me.PicketLibraryUpdate)
        Me.Controls.Add(Me.PicketLibraryInsert)
        Me.Controls.Add(Me.label9)
        Me.Controls.Add(Me.label8)
        Me.Controls.Add(Me.label7)
        Me.Controls.Add(Me.PicketThick)
        Me.Controls.Add(Me.PicketWidth)
        Me.Controls.Add(Me.PicketHeight)
        Me.Controls.Add(Me.PicketLibraryExit)
        Me.Controls.Add(Me.label6)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "PicketLibrary"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Picket Library"
        CType(Me.PicketsDBDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PicketLibBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents label10 As Label
    Friend WithEvents PicketRad As TextBox
    Friend WithEvents PicketID As ComboBox
    Friend WithEvents ShowPicketLib As Button
    Friend WithEvents DeletePicketLibrary As Button
    Friend WithEvents PicketLibraryUpdate As Button
    Friend WithEvents PicketLibraryInsert As Button
    Friend WithEvents label9 As Label
    Friend WithEvents label8 As Label
    Friend WithEvents label7 As Label
    Friend WithEvents PicketThick As TextBox
    Friend WithEvents PicketWidth As TextBox
    Friend WithEvents PicketHeight As TextBox
    Friend WithEvents PicketLibraryExit As Button
    Friend WithEvents label6 As Label
    Friend WithEvents PicketsDBDataSet As PicketsDBDataSet
    Friend WithEvents PicketLibBindingSource As BindingSource
    Friend WithEvents PicketLibTableAdapter As PicketsDBDataSetTableAdapters.PicketLibTableAdapter
    '  Friend WithEvents PicketLibTableAdapter As PicketsDBDataSetTableAdapters.PicketLibTableAdapter
End Class
